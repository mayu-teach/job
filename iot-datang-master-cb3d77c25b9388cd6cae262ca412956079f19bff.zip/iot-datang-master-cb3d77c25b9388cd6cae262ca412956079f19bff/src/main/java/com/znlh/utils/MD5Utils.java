package com.znlh.utils;

import org.apache.commons.codec.digest.DigestUtils;

import java.math.BigInteger;
import java.security.MessageDigest;

/**
 * MD5加密
 */
public class MD5Utils {

    public static String md5Digest(String key) {
        String md5Str = "";
        try {
//            MessageDigest md5 = MessageDigest.getInstance("md5");
//            byte [] bts = md5.digest(key.getBytes("utf-8"));
//            md5Str = new BigInteger(1, bts).toString(16).toUpperCase();

            md5Str = DigestUtils.md5Hex(key).toUpperCase();

            return md5Str;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return md5Str;
    }

    public static void main(String[] args) {
        System.out.println(md5Digest("getAlarmMessageFailTimeDA1A8CD9558799122632A8BA73F02BE7"));
    }

}
