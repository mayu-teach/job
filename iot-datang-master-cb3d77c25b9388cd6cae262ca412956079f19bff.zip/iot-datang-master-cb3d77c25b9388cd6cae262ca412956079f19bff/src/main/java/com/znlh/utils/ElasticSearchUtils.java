package com.znlh.utils;

import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

/**
 * ES工具类
 */
public class ElasticSearchUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(ElasticSearchUtils.class);

    /**
     * 创建ES client
     * @return
     */
    public static TransportClient open () {
        Settings settings = Settings.builder().put("cluster.name", "iot").build();
        TransportClient client = null;
        try {
            client = new PreBuiltTransportClient(settings).addTransportAddresses(
                    new TransportAddress(InetAddress.getByName("192.168.2.132"), 9400)
                    ,new TransportAddress(InetAddress.getByName("192.168.2.133"), 9400)
                    ,new TransportAddress(InetAddress.getByName("192.168.2.134"), 9400)
            );
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        return client;
    }

    /**
     * 批量插入
     * @param lst  iot_datang_fence_202005
     * @param client
     */
    public static void batchInsert (List<Map> lst, TransportClient client, String indexName) {

        BulkRequestBuilder bulkRequestBuilder = client.prepareBulk();
        for (Map m : lst) {
            bulkRequestBuilder.add(client.prepareIndex(indexName, "_doc").setSource(m));
        }
        BulkResponse bulkItemResponses = bulkRequestBuilder.execute().actionGet();
        if (null == bulkItemResponses || bulkItemResponses.hasFailures()) {
            LOGGER.error("batch error..............");
        }

    }

    /**
     * 关闭ES client
     * @param client
     */
    public static void close (TransportClient client) {
        if (null != client) {
            client.close();
            LOGGER.error("TransportClient is closed..............");
        }
    }

}
