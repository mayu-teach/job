package com.znlh.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 时间工具类
 */
public class DateUtils {

    private static final String DATE_FORMATTER = "yyyy-MM-dd HH:mm:ss";

    /**
     * 获取某一个日期的下一天
     * @param str
     * @return
     */
    public static String getNextDateStr (String str) {

        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMATTER);
        long addTime=1;   //以1为乘以的基数
        addTime*=1;   //1天以后   （如果是30天以后，则这里是30）
        addTime*=24;   //1天24小时
        addTime*=60;   //1小时60分钟
        addTime*=60;   //1分钟60秒
        addTime*=1000;   //1秒=1000毫秒

        Date date = null;
        try {
            date = sdf.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return sdf.format(new Date(date.getTime()+addTime));
    }

    public static boolean compareDate (String date1, String date2) {

        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMATTER);
        Date d1 = null;
        Date d2 = null;
        try {
            d1 = sdf.parse(date1);
            d2 = sdf.parse(date2);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return d1.getTime() > d2.getTime();
    }

    public static void main(String[] args) {
        System.out.println(compareDate("2020-01-03 12:00:00", "2020-01-03 12:00:00"));
    }

}
