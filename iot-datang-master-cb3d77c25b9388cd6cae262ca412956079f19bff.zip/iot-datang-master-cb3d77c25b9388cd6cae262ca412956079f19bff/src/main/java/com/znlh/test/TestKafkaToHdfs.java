package com.znlh.test;

import com.alibaba.fastjson.JSONObject;
import com.znlh.service.LogBucketAssigner;
import com.znlh.service.LogBulkWriterFactory;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.BulkWriter;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.core.fs.FSDataOutputStream;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.internals.KafkaTopicPartition;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Kafka-to-Hdfs
 */
public class TestKafkaToHdfs implements Serializable {
    private static final long serialVersionUID = -8597647768977189401L;

    public static void main(String[] args) {
        System.setProperty("HADOOP_USER_NAME", "hive");
        // 1-获取flink执行环境
        StreamExecutionEnvironment env =StreamExecutionEnvironment.getExecutionEnvironment();
        // 2-设置Properties
        Properties prop = new Properties();
        prop.setProperty("bootstrap.servers", "192.168.2.130:6667,192.168.2.131:6667,192.168.2.132:6667,192.168.2.133:6667,192.168.2.134:6667");
        prop.setProperty("group.id", "test1");

        env.enableCheckpointing(5 * 1000L);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);

        FlinkKafkaConsumer011<String> kafkaConsumer011 =
                new FlinkKafkaConsumer011<>("iot_request_login_message",
                        new SimpleStringSchema(), prop);

        Map<KafkaTopicPartition, Long> offsets = new HashMap<>();
        offsets.put(new KafkaTopicPartition("iot_request_login_message", 2), 61085L);

        kafkaConsumer011.setStartFromSpecificOffsets(offsets);
        DataStream<String> text = env.addSource(kafkaConsumer011);

        DataStream<LogTest> workInfo = text.map(new MapFunction<String, LogTest>() {
            @Override
            public LogTest map(String s) throws Exception {
                s = s.replace("\\", "").replace("\"{", "{").replace("}\"", "}");
                return JSONObject.parseObject(s, LogTest.class);
            }
        });

        // StreamingFileSink
//        DefaultRollingPolicy rollingPolicy = DefaultRollingPolicy
//                .create()
//                .withMaxPartSize(120 *1024 * 1024) // 设置每个文件最大大小为120M
//                .withRolloverInterval(Long.MAX_VALUE) // 滚动写入新文件的时间，默认60s。这里设置为无限大
//                .withInactivityInterval(3 * 60 * 1000) // 60s空闲，转为正式文件
//                .build();

        // hdfs上路径 1-BucketingSink已弃用
//        BucketingSink<String> bucketingSink = new BucketingSink<>("hdfs://192.168.2.200:8020/test/input");
////
////        bucketingSink.setWriter(new StringWriter<>())
////                .setBatchSize(1024 * 1024)
////                .setBatchRolloverInterval(60 * 1000L);

        // 2-StreamingFileSink，必须开启checkpoint，只能在Checkpoint成功后正确关闭PartFile；如果没有开启Checkpoint，则会导致PartFile永远处于in-progress或pendiing状态，不能被下游系统安全读取
//        StreamingFileSink<LogTest> sink = StreamingFileSink
//                .forRowFormat(new Path("D:/包万里/test/"), new SimpleStringEncoder<LogTest>("UTF-8"))
//                .withRollingPolicy(rollingPolicy) // 设置滚动策略
//                .withBucketAssigner(new LogBucketAssigner()) // 自定义输出桶格式
//                .withBucketCheckInterval(1 * 60 * 1000) // 桶检查间隔，这里设置为5m
//                .build();


        // Path需要指定hdfs路径，否则默认找本地 hdfs:///hive/ods/ods_kafka_lingong_info_test/
        StreamingFileSink sink = StreamingFileSink.forBulkFormat(new Path("hdfs:///hive/ods/ods_kafka_lingong_info_test/"), new LogBulkWriterFactory())
                .withBucketAssigner(new LogBucketAssigner())
                .withBucketCheckInterval(2 * 60 * 1000)
                .build();

        workInfo.addSink(sink).setParallelism(1);

        try {
            env.execute(TestKafkaToHdfs.class.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
