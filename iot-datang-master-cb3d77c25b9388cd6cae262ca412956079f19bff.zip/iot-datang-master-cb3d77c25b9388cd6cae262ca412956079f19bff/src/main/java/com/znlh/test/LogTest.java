package com.znlh.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogTest {

    private String iccId;
    private String loginTime;
    private String snId;
    private String commandNo;
    private String id;
    private String loginData;
    private String serialNo;
    private String userCode;
    private String dt;

    public String getIccId() {
        return iccId;
    }

    public void setIccId(String iccId) {
        this.iccId = iccId;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }

    public String getSnId() {
        return snId;
    }

    public void setSnId(String snId) {
        this.snId = snId;
    }

    public String getCommandNo() {
        return commandNo;
    }

    public void setCommandNo(String commandNo) {
        this.commandNo = commandNo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLoginData() {
        return loginData;
    }

    public void setLoginData(String loginData) {
        this.loginData = loginData;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getDt() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date date = null;
        try {
            date = sdf.parse(getLoginTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sdf.format(date);
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    @Override
    public String toString() {
//        return "\001" + iccId + "\001" + loginTime + "\001" + snId + "\001" + commandNo + "\001" + id + "\001" + loginData + "\001" + serialNo + "\001" + getDt() + "\001";
        return iccId + "\t" + loginTime + "\t" + snId + "\t" + commandNo + "\t" + id + "\t" + loginData + "\t" + serialNo + "\t" + getDt();
    }
}
