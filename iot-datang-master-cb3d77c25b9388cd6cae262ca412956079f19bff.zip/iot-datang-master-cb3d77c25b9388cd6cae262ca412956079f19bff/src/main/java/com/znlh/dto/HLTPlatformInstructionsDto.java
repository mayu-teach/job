package com.znlh.dto;

import java.io.Serializable;

/**
 * Haulott平台动作指示
 */
public class HLTPlatformInstructionsDto implements Serializable {
    private static final long serialVersionUID = -4359016342971129176L;

    private String devCode;
    private String instruction;
    private String instructionValue;
    private Long offset;
    private String dataGenerateTime;

    public String getDevCode() {
        return devCode;
    }

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public String getInstruction() {
        return instruction;
    }

    public void setInstruction(String instruction) {
        this.instruction = instruction;
    }

    public String getInstructionValue() {
        return instructionValue;
    }

    public void setInstructionValue(String instructionValue) {
        this.instructionValue = instructionValue;
    }

    public Long getOffset() {
        return offset;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }

    public String getDataGenerateTime() {
        return dataGenerateTime;
    }

    public void setDataGenerateTime(String dataGenerateTime) {
        this.dataGenerateTime = dataGenerateTime;
    }

    @Override
    public String toString() {
        return devCode +
                "\t" + instruction +
                "\t" + instructionValue +
                "\t" + offset +
                "\t" + dataGenerateTime;
    }
}
