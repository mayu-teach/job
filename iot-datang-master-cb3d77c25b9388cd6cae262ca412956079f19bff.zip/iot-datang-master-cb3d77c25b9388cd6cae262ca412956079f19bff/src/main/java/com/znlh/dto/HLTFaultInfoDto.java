package com.znlh.dto;

import java.io.Serializable;

/**
 * Haulott故障信息
 */
public class HLTFaultInfoDto implements Serializable {
    private static final long serialVersionUID = 82585596381653490L;

    private String devCode;
    private String faultTime;
    private String faultCode;
    private Integer faultState;
    private Integer faultCount;
    private String key;
    private Long offset;
    private String dataGenerateTime;

    public String getDevCode() {
        return devCode;
    }

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public String getFaultTime() {
        return faultTime;
    }

    public void setFaultTime(String faultTime) {
        this.faultTime = faultTime;
    }

    public String getFaultCode() {
        return faultCode;
    }

    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }

    public Integer getFaultState() {
        return faultState;
    }

    public void setFaultState(Integer faultState) {
        this.faultState = faultState;
    }

    public Integer getFaultCount() {
        return faultCount;
    }

    public void setFaultCount(Integer faultCount) {
        this.faultCount = faultCount;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Long getOffset() {
        return offset;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }

    public String getDataGenerateTime() {
        return dataGenerateTime;
    }

    public void setDataGenerateTime(String dataGenerateTime) {
        this.dataGenerateTime = dataGenerateTime;
    }

    @Override
    public String toString() {
        return devCode +
                "\t" + faultTime +
                "\t" + faultCode +
                "\t" + faultState +
                "\t" + faultCount +
                "\t" + key +
                "\t" + offset +
                "\t" + dataGenerateTime;
    }
}
