package com.znlh.dto;

import java.io.Serializable;

/**
 * Haulott操作时间
 */
public class HLTOperateHoursDto implements Serializable {
    private static final long serialVersionUID = 7870278300078180759L;

    private String devCode;
    private Integer operateType;
    private String operateTypeValue;
    private Double operateHour;
    private String key;
    private Long offset;
    private String dataGenerateTime;

    public String getDevCode() {
        return devCode;
    }

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public Integer getOperateType() {
        return operateType;
    }

    public void setOperateType(Integer operateType) {
        this.operateType = operateType;
    }

    public String getOperateTypeValue() {
        return operateTypeValue;
    }

    public void setOperateTypeValue(String operateTypeValue) {
        this.operateTypeValue = operateTypeValue;
    }

    public Double getOperateHour() {
        return operateHour;
    }

    public void setOperateHour(Double operateHour) {
        this.operateHour = operateHour;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Long getOffset() {
        return offset;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }

    public String getDataGenerateTime() {
        return dataGenerateTime;
    }

    public void setDataGenerateTime(String dataGenerateTime) {
        this.dataGenerateTime = dataGenerateTime;
    }

    @Override
    public String toString() {
        return devCode +
                "\t" + operateType +
                "\t" + operateTypeValue +
                "\t" + operateHour +
                "\t" + key +
                "\t" + offset +
                "\t" + dataGenerateTime;
    }
}
