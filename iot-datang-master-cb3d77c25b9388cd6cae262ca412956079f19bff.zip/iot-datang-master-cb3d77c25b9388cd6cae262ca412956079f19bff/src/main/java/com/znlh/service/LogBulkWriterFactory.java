package com.znlh.service;

import com.znlh.dto.BGDZWorkInfoDto;
import org.apache.flink.api.common.serialization.BulkWriter;
import org.apache.flink.core.fs.FSDataOutputStream;

import java.io.IOException;

public class LogBulkWriterFactory implements BulkWriter.Factory<BGDZWorkInfoDto> {
    @Override
    public BulkWriter<BGDZWorkInfoDto> create(FSDataOutputStream fsDataOutputStream) throws IOException {
        return new LogBulkWriter(fsDataOutputStream);
    }
}
