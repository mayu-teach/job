package com.znlh.service;

import com.znlh.constant.Constants;
import com.znlh.dto.BGDZWorkInfoDto;
import org.apache.flink.api.common.serialization.BulkWriter;
import org.apache.flink.core.fs.FSDataOutputStream;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class LogBulkWriter implements BulkWriter<BGDZWorkInfoDto> {

    private Charset charset = StandardCharsets.UTF_8;

    private FSDataOutputStream fsDataOutputStream;

    public LogBulkWriter(FSDataOutputStream fsDataOutputStream) {
        this.fsDataOutputStream = fsDataOutputStream;
    }

    @Override
    public void addElement(BGDZWorkInfoDto workInfo) throws IOException {
        BGDZWorkInfoDto dto = replaceNull(workInfo);
        this.fsDataOutputStream.write(dto.toString().getBytes(charset));
        this.fsDataOutputStream.write("\n".getBytes(charset));
    }

    /**
     * 替换"null"
     * @param workInfo
     * @return
     */
    private BGDZWorkInfoDto replaceNull (BGDZWorkInfoDto workInfo) {
        BGDZWorkInfoDto dto = new BGDZWorkInfoDto();

        dto.setLicenseId(null != workInfo.getLicenseId() && !workInfo.getLicenseId().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLicenseId() : "");
        dto.setMachineType(null != workInfo.getMachineType() && !workInfo.getMachineType().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getMachineType() : "");
        dto.setLatestAlarmInfo(null != workInfo.getLatestAlarmInfo() && !workInfo.getLatestAlarmInfo().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLatestAlarmInfo() : "");
        dto.setLocateStatus(null != workInfo.getLocateStatus() && !workInfo.getLocateStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLocateStatus() : "");
        dto.setLatitudeNum(null != workInfo.getLatitudeNum() && !workInfo.getLatitudeNum().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLatitudeNum() : "");
        dto.setLongitudeNum(null != workInfo.getLongitudeNum() && !workInfo.getLongitudeNum().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLongitudeNum() : "");
        dto.setAddress(null != workInfo.getAddress() && !workInfo.getAddress().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getAddress() : "");
        dto.setGpssignalStrength(null != workInfo.getGpssignalStrength() && !workInfo.getGpssignalStrength().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpssignalStrength() : "");
        dto.setGprssignalStrength(null != workInfo.getGprssignalStrength() && !workInfo.getGprssignalStrength().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGprssignalStrength() : "");
        dto.setLockerStatus(null != workInfo.getLockerStatus() && !workInfo.getLockerStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLockerStatus() : "");
        dto.setGpsSoftVersion(null != workInfo.getGpsSoftVersion() && !workInfo.getGpsSoftVersion().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsSoftVersion() : "");
        dto.setGpsHardVersion(null != workInfo.getGpsHardVersion() && !workInfo.getGpsHardVersion().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsHardVersion() : "");
        dto.setPhoneNumber(null != workInfo.getPhoneNumber() && !workInfo.getPhoneNumber().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPhoneNumber() : "");
        dto.setLocateDateTime(null != workInfo.getLocateDateTime() && !workInfo.getLocateDateTime().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLocateDateTime() : "");
        dto.setRecordTime(null != workInfo.getRecordTime() && !workInfo.getRecordTime().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getRecordTime() : "");
        dto.setCommStatus(null != workInfo.getCommStatus() && !workInfo.getCommStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getCommStatus() : "");
        dto.setWireStatus(null != workInfo.getWireStatus() && !workInfo.getWireStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getWireStatus() : "");
        dto.setGprsSignal(null != workInfo.getGprsSignal() && !workInfo.getGprsSignal().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGprsSignal() : "");
        dto.setGpsLocateFeatures(null != workInfo.getGpsLocateFeatures() && !workInfo.getGpsLocateFeatures().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsLocateFeatures() : "");
        dto.setAgpsFeatures(null != workInfo.getAgpsFeatures() && !workInfo.getAgpsFeatures().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getAgpsFeatures() : "");
        dto.setWarningCode(null != workInfo.getWarningCode() && !workInfo.getWarningCode().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getWarningCode() : "");
        dto.setGsmRxl(null != workInfo.getGsmRxl() && !workInfo.getGsmRxl().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGsmRxl() : "");
        dto.setGpsLocalDate(null != workInfo.getGpsLocalDate() && !workInfo.getGpsLocalDate().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsLocalDate() : "");
        dto.setChassisUp(null != workInfo.getChassisUp() && !workInfo.getChassisUp().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getChassisUp() : "");
        dto.setChassisDown(null != workInfo.getChassisDown() && !workInfo.getChassisDown().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getChassisDown() : "");
        dto.setPothole(null != workInfo.getPothole() && !workInfo.getPothole().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPothole() : "");
        dto.setUpLimit(null != workInfo.getUpLimit() && !workInfo.getUpLimit().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getUpLimit() : "");
        dto.setDownLimit(null != workInfo.getDownLimit() && !workInfo.getDownLimit().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getDownLimit() : "");
        dto.setFetForward(null != workInfo.getFetForward() && !workInfo.getFetForward().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetForward() : "");
        dto.setFetReverse(null != workInfo.getFetReverse() && !workInfo.getFetReverse().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetReverse() : "");
        dto.setFetLeft(null != workInfo.getFetLeft() && !workInfo.getFetLeft().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetLeft() : "");
        dto.setFetRigth(null != workInfo.getFetRigth() && !workInfo.getFetRigth().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetRigth() : "");
        dto.setFetUp(null != workInfo.getFetUp() && !workInfo.getFetUp().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetUp() : "");
        dto.setFetDown(null != workInfo.getFetDown() && !workInfo.getFetDown().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetDown() : "");
        dto.setFetHorn(null != workInfo.getFetHorn() && !workInfo.getFetHorn().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetHorn() : "");
        dto.setFetAlarm(null != workInfo.getFetAlarm() && !workInfo.getFetAlarm().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetAlarm() : "");
        dto.setGpsPowerStatus(null != workInfo.getGpsPowerStatus() && !workInfo.getGpsPowerStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsPowerStatus() : "");
        dto.setTilt(null != workInfo.getTilt() && !workInfo.getTilt().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getTilt() : "");
        dto.setHighSpeedPercent(null != workInfo.getHighSpeedPercent() && !workInfo.getHighSpeedPercent().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getHighSpeedPercent() : "");
        dto.setLowSpeedPercent(null != workInfo.getLowSpeedPercent() && !workInfo.getLowSpeedPercent().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLowSpeedPercent() : "");
        dto.setMaxUpSpeedPercent(null != workInfo.getMaxUpSpeedPercent() && !workInfo.getMaxUpSpeedPercent().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getMaxUpSpeedPercent() : "");
        dto.setMaxStandSpeedPercent(null != workInfo.getMaxStandSpeedPercent() && !workInfo.getMaxStandSpeedPercent().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getMaxStandSpeedPercent() : "");
        dto.setCalibrationStatus(null != workInfo.getCalibrationStatus() && !workInfo.getCalibrationStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getCalibrationStatus() : "");
        dto.setFetMCE(null != workInfo.getFetMCE() && !workInfo.getFetMCE().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetMCE() : "");
        dto.setEngineRPM(null != workInfo.getEngineRPM() && !workInfo.getEngineRPM().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEngineRPM() : "");
        dto.setFetParallel(null != workInfo.getFetParallel() && !workInfo.getFetParallel().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetParallel() : "");
        dto.setOilPressure(null != workInfo.getOilPressure() && !workInfo.getOilPressure().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getOilPressure() : "");
        dto.setLockState(null != workInfo.getLockState() && !workInfo.getLockState().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLockState() : "");
        dto.setLimitUpStatus(null != workInfo.getLimitUpStatus() && !workInfo.getLimitUpStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLimitUpStatus() : "");
        dto.setEcuSearchingStatus(null != workInfo.getEcuSearchingStatus() && !workInfo.getEcuSearchingStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEcuSearchingStatus() : "");
        dto.setPcuStatus(null != workInfo.getPcuStatus() && !workInfo.getPcuStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPcuStatus() : "");
        dto.setHandleAnalog(null != workInfo.getHandleAnalog() && !workInfo.getHandleAnalog().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getHandleAnalog() : "");
        dto.setPcuStatusDesc(null != workInfo.getPcuStatusDesc() && !workInfo.getPcuStatusDesc().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPcuStatusDesc() : "");
        dto.setLbsFeatures(null != workInfo.getLbsFeatures() && !workInfo.getLbsFeatures().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLbsFeatures() : "");
        dto.setEcuID(null != workInfo.getEcuID() && !workInfo.getEcuID().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEcuID() : "");
        dto.setEcuSoftVersion(null != workInfo.getEcuSoftVersion() && !workInfo.getEcuSoftVersion().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEcuSoftVersion() : "");
        dto.setPcuSoftVersion(null != workInfo.getPcuSoftVersion() && !workInfo.getPcuSoftVersion().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPcuSoftVersion() : "");
        dto.setEcuStatus(null != workInfo.getEcuStatus() && !workInfo.getEcuStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEcuStatus() : "");
        dto.setVersionNum(null != workInfo.getVersionNum() && !workInfo.getVersionNum().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getVersionNum() : "");
        dto.setFunctionCode(null != workInfo.getFunctionCode() && !workInfo.getFunctionCode().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFunctionCode() : "");
        dto.setMachineStatus(workInfo.getMachineStatus());
        dto.setWorkDuration(workInfo.getWorkDuration());
        dto.setTotalDuration(workInfo.getTotalDuration());
        dto.setFenceStatus(workInfo.getFenceStatus());
        dto.setWarningTime(workInfo.getWarningTime());
        dto.setKey(workInfo.getKey());
        dto.setBuiltInVoltage(workInfo.getBuiltInVoltage());
        dto.setLocateDuration(workInfo.getLocateDuration());
        dto.setBind(workInfo.getBind());
        dto.setDeviceNum(workInfo.getDeviceNum());
        dto.setHostHeight(workInfo.getHostHeight());
        dto.setLoadWeight(workInfo.getLoadWeight());
        dto.setOverloadAlarm(workInfo.getOverloadAlarm());
        dto.setRunTotalTime(workInfo.getRunTotalTime());
        dto.setUpTotalTime(workInfo.getUpTotalTime());
        dto.setDataGenerateTime(workInfo.getDataGenerateTime());

        return dto;
    }

    @Override
    public void flush() throws IOException {
        this.fsDataOutputStream.flush();
    }

    @Override
    public void finish() throws IOException {
        this.flush();
    }
}
