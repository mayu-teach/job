package com.znlh.service;

import com.znlh.dto.BGDZWorkInfoDto;
import org.apache.flink.core.io.SimpleVersionedSerializer;
import org.apache.flink.streaming.api.functions.sink.filesystem.BucketAssigner;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.SimpleVersionedStringSerializer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 自定义分桶
 */
public class LogBucketAssigner implements BucketAssigner<BGDZWorkInfoDto, String> {

    private static final DateFormat DF = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    private static final SimpleDateFormat DF1 = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.UK);

    private static final DateFormat DF2 = new SimpleDateFormat("yyyyMMdd");

    @Override
    public String getBucketId(BGDZWorkInfoDto workInfo, Context context) {
        Date dataGenerateTime = null;
        try {
            Date date = DF.parse(workInfo.getDataGenerateTime());
            dataGenerateTime = DF1.parse(date.toString());
        } catch (Exception e) {
            return "dt=" + DF2.format(new Date());
        }
        return "dt=" + DF2.format(dataGenerateTime);
    }

    @Override
    public SimpleVersionedSerializer<String> getSerializer() {
        return SimpleVersionedStringSerializer.INSTANCE;
    }
}
