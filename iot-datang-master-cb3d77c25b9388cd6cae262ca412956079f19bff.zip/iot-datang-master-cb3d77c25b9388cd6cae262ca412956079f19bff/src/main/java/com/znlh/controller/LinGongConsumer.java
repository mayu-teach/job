package com.znlh.controller;

import com.alibaba.fastjson.JSONObject;
import com.znlh.constant.Constants;
import com.znlh.dto.BGDZWorkInfoDto;
import com.znlh.service.LogBucketAssigner;
import com.znlh.service.LogBulkWriterFactory;
import com.znlh.utils.PropertiesUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.core.fs.Path;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Properties;

/**
 * LinGong-kafka报文落hdfs
 */
public class LinGongConsumer implements Serializable {
    private static final long serialVersionUID = -2686764043957303788L;

    private static final Logger LOGGER = LoggerFactory.getLogger(LinGongConsumer.class);

    private static final String HDFS_DIR = "hdfs:///hive/ods/ods_kafka_lingong_info/";

    public static void main(String[] args) {

        LOGGER.error("LinGongConsumer is starting......");
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        env.enableCheckpointing(60 * 1000);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
//        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(1000);
//        env.getCheckpointConfig().setCheckpointTimeout(10 * 60 * 1000);
//        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);

//        env.setStateBackend(new MemoryStateBackend());
//        env.setStateBackend(new FsStateBackend("hdfs:///flink/checkpoints"));

        Properties prop = new Properties();
        prop.put("bootstrap.servers", PropertiesUtil.getPropertyValue(Constants.BOOTSTRAP_SERVERS_LINGONG_PRD));
        prop.put("group.id", PropertiesUtil.getPropertyValue(Constants.KAFKA_GROUP_ID_LINGONG_HDFS));
        prop.put("auto.offset.reset", PropertiesUtil.getPropertyValue(Constants.AUTO_OFFSET_RESET));

        FlinkKafkaConsumer011<String> kafkaConsumer011 =
                new FlinkKafkaConsumer011<>(PropertiesUtil.getPropertyValue(Constants.KAFKA_TOPICS_LINGONG),
                        new SimpleStringSchema(), prop);

        kafkaConsumer011.setStartFromGroupOffsets();

        DataStream<String> text = env.addSource(kafkaConsumer011);

        DataStream<BGDZWorkInfoDto> workInfo = text.map(new MapFunction<String, BGDZWorkInfoDto>() {
            @Override
            public BGDZWorkInfoDto map(String s) throws Exception {
                s = s.replace("\\", "").replace("\"{", "{").replace("}\"", "}");
                // 替换"null"
                return replaceNull(JSONObject.parseObject(s, BGDZWorkInfoDto.class));
            }
        }).filter(new FilterFunction<BGDZWorkInfoDto>() {
            @Override
            public boolean filter(BGDZWorkInfoDto value) throws Exception {
                return StringUtils.isNotEmpty(value.getDataGenerateTime());
            }
        });

        // 无法设置滚动文件大小
//        StreamingFileSink sink = StreamingFileSink.forBulkFormat(new Path(HDFS_DIR), new LogBulkWriterFactory())
//                .withBucketAssigner(new LogBucketAssigner())
//                .withBucketCheckInterval(5 * 60 * 1000)
//                .build();

        DefaultRollingPolicy rollingPolicy = DefaultRollingPolicy
                .create()
                .withMaxPartSize(120 *1024 * 1024) // 设置每个文件最大大小为120M
                .withRolloverInterval(30 * 60 * 1000) // 滚动写入新文件的时间，默认60s。这里设置为30m
                .withInactivityInterval(10 * 60 * 1000) // 10m空闲，转为正式文件
                .build();

        StreamingFileSink<BGDZWorkInfoDto> sink = StreamingFileSink
                .forRowFormat(new Path(HDFS_DIR), new SimpleStringEncoder<BGDZWorkInfoDto>("UTF-8"))
                .withRollingPolicy(rollingPolicy) // 设置滚动策略
                .withBucketAssigner(new LogBucketAssigner()) // 自定义输出桶格式
                .withBucketCheckInterval(10 * 60 * 1000) // 桶检查间隔，这里设置为10m
                .build();

        workInfo.addSink(sink).setParallelism(1);

        try {
            env.execute(LinGongConsumer.class.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 替换"null"
     * @param workInfo
     * @return
     */
    private static BGDZWorkInfoDto replaceNull (BGDZWorkInfoDto workInfo) {
        BGDZWorkInfoDto dto = new BGDZWorkInfoDto();

        dto.setLicenseId(null != workInfo.getLicenseId() && !workInfo.getLicenseId().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLicenseId() : "");
        dto.setMachineType(null != workInfo.getMachineType() && !workInfo.getMachineType().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getMachineType() : "");
        dto.setLatestAlarmInfo(null != workInfo.getLatestAlarmInfo() && !workInfo.getLatestAlarmInfo().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLatestAlarmInfo() : "");
        dto.setLocateStatus(null != workInfo.getLocateStatus() && !workInfo.getLocateStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLocateStatus() : "");
        dto.setLatitudeNum(null != workInfo.getLatitudeNum() && !workInfo.getLatitudeNum().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLatitudeNum() : "");
        dto.setLongitudeNum(null != workInfo.getLongitudeNum() && !workInfo.getLongitudeNum().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLongitudeNum() : "");
        dto.setAddress(null != workInfo.getAddress() && !workInfo.getAddress().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getAddress() : "");
        dto.setGpssignalStrength(null != workInfo.getGpssignalStrength() && !workInfo.getGpssignalStrength().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpssignalStrength() : "");
        dto.setGprssignalStrength(null != workInfo.getGprssignalStrength() && !workInfo.getGprssignalStrength().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGprssignalStrength() : "");
        dto.setLockerStatus(null != workInfo.getLockerStatus() && !workInfo.getLockerStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLockerStatus() : "");
        dto.setGpsSoftVersion(null != workInfo.getGpsSoftVersion() && !workInfo.getGpsSoftVersion().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsSoftVersion() : "");
        dto.setGpsHardVersion(null != workInfo.getGpsHardVersion() && !workInfo.getGpsHardVersion().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsHardVersion() : "");
        dto.setPhoneNumber(null != workInfo.getPhoneNumber() && !workInfo.getPhoneNumber().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPhoneNumber() : "");
        dto.setLocateDateTime(null != workInfo.getLocateDateTime() && !workInfo.getLocateDateTime().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLocateDateTime() : "");
        dto.setRecordTime(null != workInfo.getRecordTime() && !workInfo.getRecordTime().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getRecordTime() : "");
        dto.setCommStatus(null != workInfo.getCommStatus() && !workInfo.getCommStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getCommStatus() : "");
        dto.setWireStatus(null != workInfo.getWireStatus() && !workInfo.getWireStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getWireStatus() : "");
        dto.setGprsSignal(null != workInfo.getGprsSignal() && !workInfo.getGprsSignal().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGprsSignal() : "");
        dto.setGpsLocateFeatures(null != workInfo.getGpsLocateFeatures() && !workInfo.getGpsLocateFeatures().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsLocateFeatures() : "");
        dto.setAgpsFeatures(null != workInfo.getAgpsFeatures() && !workInfo.getAgpsFeatures().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getAgpsFeatures() : "");
        dto.setWarningCode(null != workInfo.getWarningCode() && !workInfo.getWarningCode().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getWarningCode() : "");
        dto.setGsmRxl(null != workInfo.getGsmRxl() && !workInfo.getGsmRxl().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGsmRxl() : "");
        dto.setGpsLocalDate(null != workInfo.getGpsLocalDate() && !workInfo.getGpsLocalDate().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsLocalDate() : "");
        dto.setChassisUp(null != workInfo.getChassisUp() && !workInfo.getChassisUp().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getChassisUp() : "");
        dto.setChassisDown(null != workInfo.getChassisDown() && !workInfo.getChassisDown().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getChassisDown() : "");
        dto.setPothole(null != workInfo.getPothole() && !workInfo.getPothole().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPothole() : "");
        dto.setUpLimit(null != workInfo.getUpLimit() && !workInfo.getUpLimit().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getUpLimit() : "");
        dto.setDownLimit(null != workInfo.getDownLimit() && !workInfo.getDownLimit().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getDownLimit() : "");
        dto.setFetForward(null != workInfo.getFetForward() && !workInfo.getFetForward().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetForward() : "");
        dto.setFetReverse(null != workInfo.getFetReverse() && !workInfo.getFetReverse().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetReverse() : "");
        dto.setFetLeft(null != workInfo.getFetLeft() && !workInfo.getFetLeft().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetLeft() : "");
        dto.setFetRigth(null != workInfo.getFetRigth() && !workInfo.getFetRigth().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetRigth() : "");
        dto.setFetUp(null != workInfo.getFetUp() && !workInfo.getFetUp().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetUp() : "");
        dto.setFetDown(null != workInfo.getFetDown() && !workInfo.getFetDown().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetDown() : "");
        dto.setFetHorn(null != workInfo.getFetHorn() && !workInfo.getFetHorn().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetHorn() : "");
        dto.setFetAlarm(null != workInfo.getFetAlarm() && !workInfo.getFetAlarm().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetAlarm() : "");
        dto.setGpsPowerStatus(null != workInfo.getGpsPowerStatus() && !workInfo.getGpsPowerStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getGpsPowerStatus() : "");
        dto.setTilt(null != workInfo.getTilt() && !workInfo.getTilt().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getTilt() : "");
        dto.setHighSpeedPercent(null != workInfo.getHighSpeedPercent() && !workInfo.getHighSpeedPercent().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getHighSpeedPercent() : "");
        dto.setLowSpeedPercent(null != workInfo.getLowSpeedPercent() && !workInfo.getLowSpeedPercent().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLowSpeedPercent() : "");
        dto.setMaxUpSpeedPercent(null != workInfo.getMaxUpSpeedPercent() && !workInfo.getMaxUpSpeedPercent().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getMaxUpSpeedPercent() : "");
        dto.setMaxStandSpeedPercent(null != workInfo.getMaxStandSpeedPercent() && !workInfo.getMaxStandSpeedPercent().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getMaxStandSpeedPercent() : "");
        dto.setCalibrationStatus(null != workInfo.getCalibrationStatus() && !workInfo.getCalibrationStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getCalibrationStatus() : "");
        dto.setFetMCE(null != workInfo.getFetMCE() && !workInfo.getFetMCE().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetMCE() : "");
        dto.setEngineRPM(null != workInfo.getEngineRPM() && !workInfo.getEngineRPM().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEngineRPM() : "");
        dto.setFetParallel(null != workInfo.getFetParallel() && !workInfo.getFetParallel().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFetParallel() : "");
        dto.setOilPressure(null != workInfo.getOilPressure() && !workInfo.getOilPressure().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getOilPressure() : "");
        dto.setLockState(null != workInfo.getLockState() && !workInfo.getLockState().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLockState() : "");
        dto.setLimitUpStatus(null != workInfo.getLimitUpStatus() && !workInfo.getLimitUpStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLimitUpStatus() : "");
        dto.setEcuSearchingStatus(null != workInfo.getEcuSearchingStatus() && !workInfo.getEcuSearchingStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEcuSearchingStatus() : "");
        dto.setPcuStatus(null != workInfo.getPcuStatus() && !workInfo.getPcuStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPcuStatus() : "");
        dto.setHandleAnalog(null != workInfo.getHandleAnalog() && !workInfo.getHandleAnalog().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getHandleAnalog() : "");
        dto.setPcuStatusDesc(null != workInfo.getPcuStatusDesc() && !workInfo.getPcuStatusDesc().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPcuStatusDesc() : "");
        dto.setLbsFeatures(null != workInfo.getLbsFeatures() && !workInfo.getLbsFeatures().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getLbsFeatures() : "");
        dto.setEcuID(null != workInfo.getEcuID() && !workInfo.getEcuID().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEcuID() : "");
        dto.setEcuSoftVersion(null != workInfo.getEcuSoftVersion() && !workInfo.getEcuSoftVersion().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEcuSoftVersion() : "");
        dto.setPcuSoftVersion(null != workInfo.getPcuSoftVersion() && !workInfo.getPcuSoftVersion().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getPcuSoftVersion() : "");
        dto.setEcuStatus(null != workInfo.getEcuStatus() && !workInfo.getEcuStatus().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getEcuStatus() : "");
        dto.setVersionNum(null != workInfo.getVersionNum() && !workInfo.getVersionNum().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getVersionNum() : "");
        dto.setFunctionCode(null != workInfo.getFunctionCode() && !workInfo.getFunctionCode().equalsIgnoreCase(Constants.IS_STRING_NULL) ? workInfo.getFunctionCode() : "");
        dto.setMachineStatus(workInfo.getMachineStatus());
        dto.setWorkDuration(workInfo.getWorkDuration());
        dto.setTotalDuration(workInfo.getTotalDuration());
        dto.setFenceStatus(workInfo.getFenceStatus());
        dto.setWarningTime(workInfo.getWarningTime());
        dto.setKey(workInfo.getKey());
        dto.setBuiltInVoltage(workInfo.getBuiltInVoltage());
        dto.setLocateDuration(workInfo.getLocateDuration());
        dto.setBind(workInfo.getBind());
        dto.setDeviceNum(workInfo.getDeviceNum());
        dto.setHostHeight(workInfo.getHostHeight());
        dto.setLoadWeight(workInfo.getLoadWeight());
        dto.setOverloadAlarm(workInfo.getOverloadAlarm());
        dto.setRunTotalTime(workInfo.getRunTotalTime());
        dto.setUpTotalTime(workInfo.getUpTotalTime());
        dto.setDataGenerateTime(workInfo.getDataGenerateTime());

        return dto;
    }

}
