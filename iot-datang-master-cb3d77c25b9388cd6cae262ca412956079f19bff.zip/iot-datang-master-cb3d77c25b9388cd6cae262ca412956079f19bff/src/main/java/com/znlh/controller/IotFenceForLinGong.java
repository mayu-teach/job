package com.znlh.controller;

import com.alibaba.fastjson.JSONObject;
import com.znlh.constant.Constants;
import com.znlh.utils.PropertiesUtil;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch7.ElasticsearchSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.internals.KafkaTopicPartition;
import org.apache.http.HttpHost;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.*;

/**
 * 临工-电子围栏信息
 */
public class IotFenceForLinGong implements Serializable {

    private static final Logger LOGGER = LoggerFactory.getLogger(IotFenceForLinGong.class);
    private static final long serialVersionUID = -3261742390992807723L;
    private static final String [] fenceArr = {"deviceNum", "latitudeNum", "longitudeNum", "locateDateTime"};

    public static void main(String[] args) {

        LOGGER.error("IotFenceForLinGong is starting......");

        List<String> fenceList = Arrays.asList(fenceArr);

        // 1-获取Flink运行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // 2-开启checkpoint机制
//        env.enableCheckpointing(5000);
        // eventTime和processTime区分
        /**
         * 一般来说eventTime是从原始的消息中提取过来的,processTime是Flink自己提供的，Flink中一个亮点就是可以基于eventTime计算，
         * 这个功能很有用，因为实时数据可能会经过比较长的链路，多少会有延时，并且有很大的不确定性，
         * 对于一些需要精确体现事件变化趋势的场景中，单纯使用processTime显然是不合理的。
         * 以下：数据流的时间特征-基于eventTime处理数据
         */
//        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        // 一旦flink程序呗cancel后，会保存checkpoint数据，以便根据实际需要恢复到指定的checkpoint
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
        // 设置statebackend，将检查点保存在hdfs上，默认保存在内存中。测试保存在本地
//        env.setStateBackend(new FsStateBackend("file:///Users/temp/cp/"));

//        env.enableCheckpointing(1000 * 5);
//        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
//        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(1000);
//        env.getCheckpointConfig().setCheckpointTimeout(60000);
//        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
//
//        env.setStateBackend(new MemoryStateBackend());
//        env.setStateBackend(new FsStateBackend("hdfs:///flink/checkpoints"));

        env.enableCheckpointing(1 * 60 * 1000);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);

        // 3-配置kafka信息
        Properties prop = new Properties();

        prop.put("bootstrap.servers", PropertiesUtil.getPropertyValue(Constants.BOOTSTRAP_SERVERS_LINGONG_PRD));
        prop.put("group.id", PropertiesUtil.getPropertyValue(Constants.KAFKA_GROUP_ID_LINGONG));
        prop.put("auto.offset.reset", PropertiesUtil.getPropertyValue(Constants.AUTO_OFFSET_RESET));

        // 4-构建KafkaConsumer
        FlinkKafkaConsumer011<String> kafkaConsumer011 =
                new FlinkKafkaConsumer011<>(PropertiesUtil.getPropertyValue(Constants.KAFKA_TOPICS_LINGONG),
                        new SimpleStringSchema(), prop);
        // 增加水位设置类
//        kafkaConsumer011.assignTimestampsAndWatermarks(new WordCountWatermarkEmitter());

        //设置默认消费策略 Flink从topic中指定的group上次消费的位置开始消费，所以必须配置group.id参数
        /**
         * 如果从Kafka brokers或者Zookeeper中找不到这个consumer group对应的partition的offset，
         * 那么auto.offset.reset这个配置就会被启用。auto.offset.reset默认读的是largest offset
         */
        kafkaConsumer011.setStartFromGroupOffsets();
        // 默认为true
//        kafkaConsumer011.setCommitOffsetsOnCheckpoints(true);
        // 从头开始读
//        kafkaConsumer011.setStartFromEarliest();
        // 从最新开始读
//        kafkaConsumer011.setStartFromLatest();
//        Map<KafkaTopicPartition, Long> offsets = new HashMap<>();
//        offsets.put(new KafkaTopicPartition(PropertiesUtil.getPropertyValue(Constants.KAFKA_TOPICS_LINGONG), 0), 6000L);
//
//        kafkaConsumer011.setStartFromSpecificOffsets(offsets);
        // 5-将自定义Kafka Source加入到数据源
        DataStream<String> text = env.addSource(kafkaConsumer011);
        // 6-打印到控制台
//        text.print().setParallelism(1);

        // 写es
        List<HttpHost> esHttpHost = new ArrayList<>();
        esHttpHost.add(new HttpHost(PropertiesUtil.getPropertyValue(Constants.ES_HOSTNAME_132),
                Integer.valueOf(PropertiesUtil.getPropertyValue(Constants.ES_PORT)),
                    PropertiesUtil.getPropertyValue(Constants.ES_SCHEMA)));
        esHttpHost.add(new HttpHost(PropertiesUtil.getPropertyValue(Constants.ES_HOSTNAME_133),
                Integer.valueOf(PropertiesUtil.getPropertyValue(Constants.ES_PORT)),
                PropertiesUtil.getPropertyValue(Constants.ES_SCHEMA)));
        esHttpHost.add(new HttpHost(PropertiesUtil.getPropertyValue(Constants.ES_HOSTNAME_134),
                Integer.valueOf(PropertiesUtil.getPropertyValue(Constants.ES_PORT)),
                PropertiesUtil.getPropertyValue(Constants.ES_SCHEMA)));

        DataStream<Map> message = text.map(new MapFunction<String, Map>() {
            Map map = null;
            @Override
            public Map map(String s) throws Exception {
                if (StringUtils.isNotEmpty(s)) {
                    s = s.replace("\\", "").replace("\"{", "{").replace("}\"", "}");
                    map = JSONObject.parseObject(s, Map.class);
                }
                return map;
            }
        }).filter(new FilterFunction<Map>() {
            @Override
            public boolean filter(Map map) throws Exception {
                return StringUtils.isNotEmpty(MapUtils.getString(map, "locateDateTime"))
                        && StringUtils.isNotEmpty(MapUtils.getString(map, "latitudeNum"))
                        && StringUtils.isNotEmpty(MapUtils.getString(map, "longitudeNum"));
            }
        });

        ElasticsearchSink.Builder<Map> esSinkBuilder = new ElasticsearchSink.Builder<>(
                esHttpHost, new ElasticsearchSinkFunction<Map>() {

            public IndexRequest createIndexRequest(Map element) {
                Map<String, String> json = new HashMap<>();

                Set<Map.Entry> set = element.entrySet();
                for (Map.Entry e : set) {
                    try {
                        if (fenceList.contains(e.getKey()) && null != e.getValue()) {
                            json.put(e.getKey().toString(), e.getValue().toString());
                        }
                    } catch (Exception e1) {
                        LOGGER.error("IotFenceForLinGong is error......");
                        continue;
                    }
                }

                return Requests.indexRequest()
                        .index(PropertiesUtil.getPropertyValue(Constants.ES_INDEX_LINGONG))
                        .type("_doc")
                        .source(json);
            }

            @Override
            public void process(Map element, RuntimeContext runtimeContext, RequestIndexer requestIndexer) {
                requestIndexer.add(createIndexRequest(element));
            }
        }
        );

        esSinkBuilder.setBulkFlushBackoff(true);
        esSinkBuilder.setBulkFlushBackoffRetries(2);
        esSinkBuilder.setBulkFlushBackoffDelay(1000);
        esSinkBuilder.setBulkFlushMaxSizeMb(10);
        // TODO 生产上需要修改
        esSinkBuilder.setBulkFlushMaxActions(2000);

        message.addSink(esSinkBuilder.build()).setParallelism(2);

        // 7-执行
        try {
            env.execute(IotFenceForLinGong.class.getName());
        } catch (Exception e) {
            LOGGER.error("IotFenceForLinGong submit error......");
            e.printStackTrace();
        }

    }

}
