package com.znlh.dto;

import java.io.Serializable;

/**
 * Haulott操作日志
 */
public class HLTOperateLogDto implements Serializable {
    private static final long serialVersionUID = -729122490772813152L;

    private String devCode;
    private Integer operateType;
    private String operateTypeValue;
    private Integer operateResult;
    private Long offset;
    private String dataGenerateTime;

    public String getDevCode() {
        return devCode;
    }

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public Integer getOperateType() {
        return operateType;
    }

    public void setOperateType(Integer operateType) {
        this.operateType = operateType;
    }

    public String getOperateTypeValue() {
        return operateTypeValue;
    }

    public void setOperateTypeValue(String operateTypeValue) {
        this.operateTypeValue = operateTypeValue;
    }

    public Integer getOperateResult() {
        return operateResult;
    }

    public void setOperateResult(Integer operateResult) {
        this.operateResult = operateResult;
    }

    public Long getOffset() {
        return offset;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }

    public String getDataGenerateTime() {
        return dataGenerateTime;
    }

    public void setDataGenerateTime(String dataGenerateTime) {
        this.dataGenerateTime = dataGenerateTime;
    }

    @Override
    public String toString() {
        return devCode +
                "\t" + operateType +
                "\t" + operateTypeValue +
                "\t" + operateResult +
                "\t" + offset +
                "\t" + dataGenerateTime;
    }
}
