package com.znlh.dto;

import java.io.Serializable;

/**
 * iot同步状态实体类
 */
public class IotTransferStatus implements Serializable {

    private static final long serialVersionUID = -2518635658920764255L;

    private String beginDate;

    private String endDate;

    private String status;

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
