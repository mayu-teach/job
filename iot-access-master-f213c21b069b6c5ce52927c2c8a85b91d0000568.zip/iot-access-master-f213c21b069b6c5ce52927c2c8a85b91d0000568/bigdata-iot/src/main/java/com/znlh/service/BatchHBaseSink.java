package com.znlh.service;

import com.znlh.util.HBaseUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;

import java.util.List;

/**
 * 批量写hbase
 */
public class BatchHBaseSink extends RichSinkFunction<List<Put>> {

    private String tableFullName;

    public BatchHBaseSink(String tableFullName) {
        this.tableFullName = tableFullName;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        HBaseUtils.getHBaseConnection();
    }

    @Override
    public void close() throws Exception {
        super.close();
        HBaseUtils.closeHBaseConnection();
    }

    @Override
    public void invoke(List<Put> puts, Context context) throws Exception {
        Table table = HBaseUtils.getTable(tableFullName);
        table.put(puts);
    }
}
