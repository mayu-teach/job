package com.znlh.controller;

import com.alibaba.fastjson.JSONObject;
import com.znlh.constant.Constants;
import com.znlh.dto.IotNormalMessage;
import com.znlh.service.BatchHBaseSink;
import com.znlh.util.GenerateRowKeyUtil;
import com.znlh.util.KafkaUtil;
import com.znlh.util.PropertiesUtil;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.AllWindowFunction;
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * iot基本信息实时数据接入hbase
 */
public class IotNormalMessageController implements Serializable {

    private static final long serialVersionUID = -3012665626312027184L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IotNormalMessageController.class);

    public static void main(String[] args) {

        LOGGER.error("IotNormalMessageController is starting......");

        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//        env.enableCheckpointing(1000 * 60);
        env.enableCheckpointing(1 * 60 * 1000);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
//        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(1000);
//        env.getCheckpointConfig().setCheckpointTimeout(60000);
//        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
//
//        env.setStateBackend(new MemoryStateBackend());
//        env.setStateBackend(new FsStateBackend("hdfs:///flink/checkpoints"));

        FlinkKafkaConsumer011<String> consumer =
                new FlinkKafkaConsumer011<String>(PropertiesUtil.getPropertyValue(Constants.NORMAL_KAFKA_TOPICS),
                        new SimpleStringSchema(), KafkaUtil.getKafkaConfig(PropertiesUtil.getPropertyValue(Constants.NORMAL_GROUP_ID)));

        consumer.setStartFromGroupOffsets();

        DataStreamSource<String> text = env.addSource(consumer);

        DataStream<IotNormalMessage> message = text.map(new MapFunction<String, IotNormalMessage>(){
            public IotNormalMessage map(String raw) throws Exception {
                IotNormalMessage iotNormalMessage = null;
                if(null != raw) {
                    iotNormalMessage = JSONObject.parseObject(raw, IotNormalMessage.class);
                }
                return iotNormalMessage;
            }
        });

        DataStream<List<Put>> puts = message.countWindowAll(500).apply(new AllWindowFunction<IotNormalMessage, List<Put>, GlobalWindow>() {
            private static final long serialVersionUID = -4183576896758909677L;

            @Override
            public void apply(GlobalWindow globalWindow, Iterable<IotNormalMessage> iterable, Collector<List<Put>> out) throws Exception {
                List<Put> puts = new ArrayList<Put>();
                iterable.forEach(iotNormalMessage -> {
                    Put put = new Put(Bytes.toBytes(generateRowKey(iotNormalMessage)));

                    List<Field> fields = getDeclaredAndNotStaticFields(IotNormalMessage.class);
                    fields.forEach(field -> {
                        try {
                            field.setAccessible(true);
                            put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_NORMAL_COLUMNFAMILY)), Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(iotNormalMessage) == null ? "" : field.get(iotNormalMessage).toString()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });

                    puts.add(put);
                });

                out.collect(puts);
            }

        }).setParallelism(1);

        puts.addSink(new BatchHBaseSink(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_NORMAL_TABLE))).setParallelism(1);

        try {
            env.execute(IotNormalMessageController.class.getName());
        } catch (Exception e) {
            LOGGER.error("IotNormalMessageController submit error......");
        }

    }

    /**
     * 获取对象有效属性
     * @param clazz
     * @return
     */
    private static List<Field> getDeclaredAndNotStaticFields(Class clazz) {
        List<Field> fieldList = new ArrayList<Field>();
        Field[] fields = clazz.getDeclaredFields();
        for(Field field : fields) {
            if(!Modifier.isStatic(field.getModifiers())) {
                fieldList.add(field);
            }
        }

        return fieldList;
    }

    /**
     * 生成rowkey
     * @param iotNormalMessage
     * @return
     */
    private static String generateRowKey(IotNormalMessage iotNormalMessage) {
        String rowkey = null;
        String reportTime = iotNormalMessage.getReportTime();
        Date createTime = iotNormalMessage.getCreateTime();
        SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_PATTERN_MODE_ONE);

        if(null != reportTime) {
            try {
                rowkey = GenerateRowKeyUtil.generateRowKey(iotNormalMessage.getSnId(), Long.toString(sdf.parse(reportTime).getTime()));
            } catch (ParseException e) {
                LOGGER.error("时间格式转换错误");
            }
        } else if (null != createTime) {
            rowkey = GenerateRowKeyUtil.generateRowKey(iotNormalMessage.getSnId(), Long.toString(createTime.getTime()));
        } else {
            rowkey = GenerateRowKeyUtil.generateRowKey(iotNormalMessage.getSnId(), Long.toString(new Date().getTime()));
        }

        return rowkey;
    }

}
