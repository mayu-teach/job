package com.znlh.util;

/**
 * 生成hbase rowkey
 */
public class GenerateRowKeyUtil {

    public static String generateRowKey(String snId, String time) {

        return snId + "-" + time;
    }

    public static String generateRowKey(String date, String snId, String time) {

        return date + snId + time;
    }

}
