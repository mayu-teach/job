package com.znlh.service;

import com.znlh.util.HBaseUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Haulott信息落入hbase
 */
public class HaulottHBaseSink extends RichSinkFunction<Map<String, List<Put>>> {

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        HBaseUtils.getHBaseConnection();
    }

    @Override
    public void close() throws Exception {
        super.close();
        HBaseUtils.closeHBaseConnection();
    }

    @Override
    public void invoke(Map<String, List<Put>> value, Context context) throws Exception {

        Set<Map.Entry<String, List<Put>>> entries = value.entrySet();
        for (Map.Entry<String, List<Put>> map : entries) {
            Table table = HBaseUtils.getTable(map.getKey());
            table.put(map.getValue());
        }

    }
}
