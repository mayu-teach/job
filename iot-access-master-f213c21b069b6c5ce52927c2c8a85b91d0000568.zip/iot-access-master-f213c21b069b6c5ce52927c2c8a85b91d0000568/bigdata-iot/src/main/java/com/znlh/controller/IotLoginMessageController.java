package com.znlh.controller;

import com.alibaba.fastjson.JSONObject;
import com.znlh.constant.Constants;
import com.znlh.dto.IotLoginMessage;
import com.znlh.service.BatchHBaseSink;
import com.znlh.util.GenerateRowKeyUtil;
import com.znlh.util.KafkaUtil;
import com.znlh.util.PropertiesUtil;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.AllWindowFunction;
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * iot登录信息实时数据接入hbase
 */
public class IotLoginMessageController implements Serializable {

    private static final long serialVersionUID = -3012665626312027184L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IotLoginMessageController.class);

    public static void main(String[] args) {

        LOGGER.error("IotLoginMessageController is starting......");

        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//        env.enableCheckpointing(1000 * 60);
        env.enableCheckpointing(1 * 60 * 1000);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
//        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(1000);
//        env.getCheckpointConfig().setCheckpointTimeout(60000);
//        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
//
//        env.setStateBackend(new MemoryStateBackend());
//        env.setStateBackend(new FsStateBackend("hdfs:///flink/checkpoints"));

        FlinkKafkaConsumer011<String> consumer =
                new FlinkKafkaConsumer011<String>(PropertiesUtil.getPropertyValue(Constants.LOGIN_KAFKA_TOPICS),
                        new SimpleStringSchema(), KafkaUtil.getKafkaConfig(PropertiesUtil.getPropertyValue(Constants.LOGIN_GROUP_ID)));

        consumer.setStartFromGroupOffsets();

        DataStreamSource<String> text = env.addSource(consumer);

        DataStream<IotLoginMessage> message = text.map(new MapFunction<String, IotLoginMessage>(){
            public IotLoginMessage map(String raw) throws Exception {
                IotLoginMessage iotLoginMessage = null;
                if(null != raw) {
                    iotLoginMessage = JSONObject.parseObject(raw, IotLoginMessage.class);
                }
                return iotLoginMessage;
            }
        });

        DataStream<List<Put>> puts = message.countWindowAll(500).apply(new AllWindowFunction<IotLoginMessage, List<Put>, GlobalWindow>() {
            private static final long serialVersionUID = -4183576896758909677L;

            @Override
            public void apply(GlobalWindow globalWindow, Iterable<IotLoginMessage> iterable, Collector<List<Put>> out) throws Exception {
                List<Put> puts = new ArrayList<Put>();
                iterable.forEach(iotLoginMessage -> {
                    Put put = new Put(Bytes.toBytes(generateRowKey(iotLoginMessage)));

                    List<Field> fields = getDeclaredAndNotStaticFields(IotLoginMessage.class);
                    fields.forEach(field -> {
                        try {
                            field.setAccessible(true);
                            put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_LOGIN_COLUMNFAMILY)), Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(iotLoginMessage) == null ? "" : field.get(iotLoginMessage).toString()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });

                    puts.add(put);
                });

                out.collect(puts);
            }

        }).setParallelism(1);

        puts.addSink(new BatchHBaseSink(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_LOGIN_TABLE))).setParallelism(1);

        try {
            env.execute(IotLoginMessageController.class.getName());
        } catch (Exception e) {
            LOGGER.error("IotLoginMessageController submit error......");
        }

    }

    /**
     * 获取对象有效属性
     * @param clazz
     * @return
     */
    private static List<Field> getDeclaredAndNotStaticFields(Class clazz) {
        List<Field> fieldList = new ArrayList<Field>();
        Field[] fields = clazz.getDeclaredFields();
        for(Field field : fields) {
            if(!Modifier.isStatic(field.getModifiers())) {
                fieldList.add(field);
            }
        }

        return fieldList;
    }

    /**
     * 生成rowkey
     * @param iotLoginMessage
     * @return
     */
    private static String generateRowKey(IotLoginMessage iotLoginMessage) {
        String rowkey = null;
        String loginTime = iotLoginMessage.getLoginTime();
        Date createTime = iotLoginMessage.getCreateTime();
        SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_PATTERN_MODE_ONE);

        if(null != loginTime) {
            try {
                rowkey = GenerateRowKeyUtil.generateRowKey(iotLoginMessage.getSnId(), Long.toString(sdf.parse(loginTime).getTime()));
            } catch (ParseException e) {
                LOGGER.error("时间格式转换错误");
            }
        } else if (null != createTime) {
            rowkey = GenerateRowKeyUtil.generateRowKey(iotLoginMessage.getSnId(), Long.toString(createTime.getTime()));
        } else {
            rowkey = GenerateRowKeyUtil.generateRowKey(iotLoginMessage.getSnId(), Long.toString(new Date().getTime()));
        }

        return rowkey;
    }

}
