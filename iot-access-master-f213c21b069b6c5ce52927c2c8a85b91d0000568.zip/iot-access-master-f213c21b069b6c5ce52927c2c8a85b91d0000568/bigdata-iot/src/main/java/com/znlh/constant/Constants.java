package com.znlh.constant;

/**
 * 常量类
 */
public class Constants {

    // kafka broker配置
    public static final String BOOTSTRAP_SERVERS = "bootstrap.servers";
    public static final String BOOTSTRAP_SERVERS_TEST = "bootstrap.servers.test";
    public static final String BOOTSTRAP_SERVERS_LINGONG_PRD = "bootstrap.servers.lingong.prd";
    public static final String BOOTSTRAP_SERVERS_HAULOTT_PRD = "bootstrap.servers.haulott.prd";
    // kafka外网映射配置
    public static final String BOOTSTRAP_SERVERS_MAPPING = "bootstrap.servers.mapping";
    // kafka topic
    public static final String LOGIN_KAFKA_TOPICS = "login.kafka.topics";
    public static final String BUS_KAFKA_TOPICS = "bus.kafka.topics";
    public static final String NORMAL_KAFKA_TOPICS = "normal.kafka.topics";
    public static final String KAFKA_TOPICS_LINGONG = "kafka.topics.lingong";
    public static final String KAFKA_TOPICS_HAULOTT = "kafka.topics.haulott";
    // kafka consumer
    public static final String LOGIN_GROUP_ID = "login.group.id";
    public static final String BUS_GROUP_ID = "bus.group.id";
    public static final String NORMAL_GROUP_ID = "normal.group.id";
    public static final String KAFKA_GROUP_ID_LINGONG_HBASE = "kafka.group.id.lingong.hbase";
    public static final String KAFKA_GROUP_ID_HAULOTT_HBASE = "kafka.group.id.haulott.hbase";
    // zookeeper
    public static final String ZOOKEEPER_SERVERS = "zookeeper.servers";
    // auto.offset.reset
    public static final String AUTO_OFFSET_RESET = "auto.offset.reset";
    public static final String AUTO_OFFSET_LATEST = "auto.offset.latest";
    // hbase.zookeeper.quorum
    public static final String HBASE_ZOOKEEPER_QUORUM = "hbase.zookeeper.quorum";
    public static final String HBASE_ZOOKEEPER_QUORUM_TEST = "hbase.zookeeper.quorum.test";
    // hbase.zookeeper.clientPort
    public static final String HBASE_ZOOKEEPER_CLIENTPORT = "hbase.zookeeper.clientPort";
    // zookeeper.znode.parent
    public static final String ZOOKEEPER_ZNODE_PARENT = "zookeeper.znode.parent";
    // hadoop.user.name
    public static final String HADOOP_USER_NAME = "hadoop.user.name";
    // hbase table & cf
    public static final String HBASE_IOT_LOGIN_TABLE = "hbase.iot.login.table";
    public static final String HBASE_IOT_LOGIN_ALL_TABLE = "hbase.iot.login.all.table";
    public static final String HBASE_IOT_LOGIN_SIMPLE_TABLE = "hbase.iot.login.simple.table";
    public static final String HBASE_IOT_LOGIN_COLUMNFAMILY = "hbase.iot.login.columnfamily";
    public static final String HBASE_IOT_LOGIN_ALL_COLUMNFAMILY = "hbase.iot.login.all.columnfamily";
    public static final String HBASE_IOT_BUS_TABLE = "hbase.iot.bus.table";
    public static final String HBASE_IOT_LINGONG_TABLE = "hbase.iot.lingong.table";
    public static final String HBASE_IOT_HAULOTT_ALARM_TABLE = "hbase.iot.haulott.alarm.table";
    public static final String HBASE_IOT_HAULOTT_BATTERY_TABLE = "hbase.iot.haulott.battery.table";
    public static final String HBASE_IOT_HAULOTT_POSITION_TABLE = "hbase.iot.haulott.position.table";
    public static final String HBASE_IOT_HAULOTT_EXT_TABLE = "hbase.iot.haulott.ext.table";
    public static final String HBASE_IOT_HAULOTT_FAULT_TABLE = "hbase.iot.haulott.fault.table";
    public static final String HBASE_IOT_HAULOTT_HOURS_TABLE = "hbase.iot.haulott.hours.table";
    public static final String HBASE_IOT_HAULOTT_LOG_TABLE = "hbase.iot.haulott.log.table";
    public static final String HBASE_IOT_HAULOTT_INSTRUCTION_TABLE = "hbase.iot.haulott.instruction.table";
    public static final String HBASE_IOT_BUS_ALL_TABLE = "hbase.iot.bus.all.table";
    public static final String HBASE_IOT_BUS_SIMPLE_TABLE = "hbase.iot.bus.simple.table";
    public static final String HBASE_IOT_BUS_COLUMNFAMILY = "hbase.iot.bus.columnfamily";
    public static final String HBASE_IOT_LINGONG_COLUMNFAMILY = "hbase.iot.lingong.columnfamily";
    public static final String HBASE_IOT_HAULOTT_ALARM_COLUMNFAMILY = "hbase.iot.haulott.alarm.columnfamily";
    public static final String HBASE_IOT_HAULOTT_BATTERY_COLUMNFAMILY = "hbase.iot.haulott.battery.columnfamily";
    public static final String HBASE_IOT_HAULOTT_POSITION_COLUMNFAMILY = "hbase.iot.haulott.position.columnfamily";
    public static final String HBASE_IOT_HAULOTT_EXT_COLUMNFAMILY = "hbase.iot.haulott.ext.columnfamily";
    public static final String HBASE_IOT_HAULOTT_FAULT_COLUMNFAMILY = "hbase.iot.haulott.fault.columnfamily";
    public static final String HBASE_IOT_HAULOTT_HOURS_COLUMNFAMILY = "hbase.iot.haulott.hours.columnfamily";
    public static final String HBASE_IOT_HAULOTT_LOG_COLUMNFAMILY = "hbase.iot.haulott.log.columnfamily";
    public static final String HBASE_IOT_HAULOTT_INSTRUCTION_COLUMNFAMILY = "hbase.iot.haulott.instruction.columnfamily";
    public static final String HBASE_IOT_BUS_ALL_COLUMNFAMILY = "hbase.iot.bus.all.columnfamily";
    public static final String HBASE_IOT_NORMAL_TABLE = "hbase.iot.normal.table";
    public static final String HBASE_IOT_NORMAL_ALL_TABLE = "hbase.iot.normal.all.table";
    public static final String HBASE_IOT_NORMAL_SIMPLE_TABLE = "hbase.iot.normal.simple.table";
    public static final String HBASE_IOT_NORMAL_COLUMNFAMILY = "hbase.iot.normal.columnfamily";
    public static final String HBASE_IOT_NORMAL_ALL_COLUMNFAMILY = "hbase.iot.normal.all.columnfamily";
    public static final String HBASE_IOT_TRANSFER_STATUS_TABLE = "hbase.iot.transfer.status.table";
    public static final String HBASE_IOT_TRANSFER_STATUS_COLUMNFAMILY = "hbase.iot.transfer.status.columnfamily";

    public static final String IOT_SYNC_IN_PROGRESS_STATUS = "0";
    public static final String IOT_SYNC_SUCCESS_STATUS = "1";
    public static final String IOT_SYNC_FAIL_STATUS = "2";

    public static final String DATE_FORMAT_PATTERN_MODE_ONE = "yy-MM-dd HH:mm:ss";

    public static final String DATE_FORMATTER = "yyyy-MM-dd HH:mm:ss";

    public static final int BATCH_SIZE = 500;

    public static final String IS_STRING_NULL = "null";

}
