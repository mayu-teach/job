package com.znlh.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * iot基本信息实体类
 */
public class IotNormalMessage implements Serializable {


    private static final long serialVersionUID = 5790395241170344489L;
    // 主键
    private String id;
    // 消息流水号
    private String serialNo;
    // 命令号
    private String commandNo;
    // 终端id
    private String snId;
    // 上报时间
    private String reportTime;
    // 上报类型
    private String reportType;
    // 经度
    private double longitude;
    // 纬度
    private double latitude;
    // 速度
    private double speed;
    // 方向角
    private int direction;
    // 定位
    private String location;
    // 北纬或者南纬
    private String northOrSouth;
    // 东经或者西经
    private String westOrEast;
    // gps收到的星数
    private String starNum;
    // gps模块是否正常
    private String gpsNormal;
    // 信号强度
    private String signalStrength;
    // 4G是否正常
    private String fourGNormal;
    // 位置信息码
    private long locationInfoNo;
    // 小区信息码
    private long villageInfoNo;
    // 内部锂电池电压
    private double innerVoltage;
    // 动力电池电压
    private double barrierVoltage;
    // 气压
    private long pressure;
    // 终端内部温度
    private double innerTemperature;
    // 工作小时
    private double workHour;
    // 里程
    private long mileage;
    // acc状态
    private String accStatus;
    // 保修开关状态
    private String repairStatus;
    // 小时计开关状态
    private String hourDetail;
    // 开盒状态
    private String openBoxStatus;
    // 继电器状态
    private String relayStatus;
    // can通讯
    private String canCommunication;
    // 485通讯
    private String fourEightFiveCommunication;
    // 232通讯
    private String twoThreeTwoCommunication;
    // 供电状态
    private String provideElectricStatus;
    // 外电继电器报警
    private String outElectricAlarm;
    // 动力电池电压低状态
    private String barrierVoltageStatus;
    // 内部锂电池充电状态
    private String innerBarrierChargeStatus;
    // 内部锂电池电压低状态
    private String innerBarrierVoltageStatus;
    // 工作模式
    private String gpsWorkModel;
    // 版本号
    private String gpsVersion;
    // 原始数据
    private String normalMessageData;
    // 入库时间
    private Date createTime;

    private int theoryCount;
    private Date theoryCountDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getCommandNo() {
        return commandNo;
    }

    public void setCommandNo(String commandNo) {
        this.commandNo = commandNo;
    }

    public String getSnId() {
        return snId;
    }

    public void setSnId(String snId) {
        this.snId = snId;
    }

    public String getReportTime() {
        return reportTime;
    }

    public void setReportTime(String reportTime) {
        this.reportTime = reportTime;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNorthOrSouth() {
        return northOrSouth;
    }

    public void setNorthOrSouth(String northOrSouth) {
        this.northOrSouth = northOrSouth;
    }

    public String getWestOrEast() {
        return westOrEast;
    }

    public void setWestOrEast(String westOrEast) {
        this.westOrEast = westOrEast;
    }

    public String getStarNum() {
        return starNum;
    }

    public void setStarNum(String starNum) {
        this.starNum = starNum;
    }

    public String getGpsNormal() {
        return gpsNormal;
    }

    public void setGpsNormal(String gpsNormal) {
        this.gpsNormal = gpsNormal;
    }

    public String getSignalStrength() {
        return signalStrength;
    }

    public void setSignalStrength(String signalStrength) {
        this.signalStrength = signalStrength;
    }

    public String getFourGNormal() {
        return fourGNormal;
    }

    public void setFourGNormal(String fourGNormal) {
        this.fourGNormal = fourGNormal;
    }

    public long getLocationInfoNo() {
        return locationInfoNo;
    }

    public void setLocationInfoNo(long locationInfoNo) {
        this.locationInfoNo = locationInfoNo;
    }

    public long getVillageInfoNo() {
        return villageInfoNo;
    }

    public void setVillageInfoNo(long villageInfoNo) {
        this.villageInfoNo = villageInfoNo;
    }

    public double getInnerVoltage() {
        return innerVoltage;
    }

    public void setInnerVoltage(double innerVoltage) {
        this.innerVoltage = innerVoltage;
    }

    public double getBarrierVoltage() {
        return barrierVoltage;
    }

    public void setBarrierVoltage(double barrierVoltage) {
        this.barrierVoltage = barrierVoltage;
    }

    public long getPressure() {
        return pressure;
    }

    public void setPressure(long pressure) {
        this.pressure = pressure;
    }

    public double getInnerTemperature() {
        return innerTemperature;
    }

    public void setInnerTemperature(double innerTemperature) {
        this.innerTemperature = innerTemperature;
    }

    public double getWorkHour() {
        return workHour;
    }

    public void setWorkHour(double workHour) {
        this.workHour = workHour;
    }

    public long getMileage() {
        return mileage;
    }

    public void setMileage(long mileage) {
        this.mileage = mileage;
    }

    public String getAccStatus() {
        return accStatus;
    }

    public void setAccStatus(String accStatus) {
        this.accStatus = accStatus;
    }

    public String getRepairStatus() {
        return repairStatus;
    }

    public void setRepairStatus(String repairStatus) {
        this.repairStatus = repairStatus;
    }

    public String getHourDetail() {
        return hourDetail;
    }

    public void setHourDetail(String hourDetail) {
        this.hourDetail = hourDetail;
    }

    public String getOpenBoxStatus() {
        return openBoxStatus;
    }

    public void setOpenBoxStatus(String openBoxStatus) {
        this.openBoxStatus = openBoxStatus;
    }

    public String getRelayStatus() {
        return relayStatus;
    }

    public void setRelayStatus(String relayStatus) {
        this.relayStatus = relayStatus;
    }

    public String getCanCommunication() {
        return canCommunication;
    }

    public void setCanCommunication(String canCommunication) {
        this.canCommunication = canCommunication;
    }

    public String getFourEightFiveCommunication() {
        return fourEightFiveCommunication;
    }

    public void setFourEightFiveCommunication(String fourEightFiveCommunication) {
        this.fourEightFiveCommunication = fourEightFiveCommunication;
    }

    public String getTwoThreeTwoCommunication() {
        return twoThreeTwoCommunication;
    }

    public void setTwoThreeTwoCommunication(String twoThreeTwoCommunication) {
        this.twoThreeTwoCommunication = twoThreeTwoCommunication;
    }

    public String getProvideElectricStatus() {
        return provideElectricStatus;
    }

    public void setProvideElectricStatus(String provideElectricStatus) {
        this.provideElectricStatus = provideElectricStatus;
    }

    public String getOutElectricAlarm() {
        return outElectricAlarm;
    }

    public void setOutElectricAlarm(String outElectricAlarm) {
        this.outElectricAlarm = outElectricAlarm;
    }

    public String getBarrierVoltageStatus() {
        return barrierVoltageStatus;
    }

    public void setBarrierVoltageStatus(String barrierVoltageStatus) {
        this.barrierVoltageStatus = barrierVoltageStatus;
    }

    public String getInnerBarrierChargeStatus() {
        return innerBarrierChargeStatus;
    }

    public void setInnerBarrierChargeStatus(String innerBarrierChargeStatus) {
        this.innerBarrierChargeStatus = innerBarrierChargeStatus;
    }

    public String getInnerBarrierVoltageStatus() {
        return innerBarrierVoltageStatus;
    }

    public void setInnerBarrierVoltageStatus(String innerBarrierVoltageStatus) {
        this.innerBarrierVoltageStatus = innerBarrierVoltageStatus;
    }

    public String getGpsWorkModel() {
        return gpsWorkModel;
    }

    public void setGpsWorkModel(String gpsWorkModel) {
        this.gpsWorkModel = gpsWorkModel;
    }

    public String getGpsVersion() {
        return gpsVersion;
    }

    public void setGpsVersion(String gpsVersion) {
        this.gpsVersion = gpsVersion;
    }

    public String getNormalMessageData() {
        return normalMessageData;
    }

    public void setNormalMessageData(String normalMessageData) {
        this.normalMessageData = normalMessageData;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public int getTheoryCount() {
        return theoryCount;
    }

    public void setTheoryCount(int theoryCount) {
        this.theoryCount = theoryCount;
    }

    public Date getTheoryCountDate() {
        return theoryCountDate;
    }

    public void setTheoryCountDate(Date theoryCountDate) {
        this.theoryCountDate = theoryCountDate;
    }

    @Override
    public String toString() {
        return "IotNormalMessage{" +
                "id='" + id + '\'' +
                ", serialNo='" + serialNo + '\'' +
                ", commandNo='" + commandNo + '\'' +
                ", snId='" + snId + '\'' +
                ", reportTime='" + reportTime + '\'' +
                ", reportType='" + reportType + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", speed=" + speed +
                ", direction=" + direction +
                ", location='" + location + '\'' +
                ", northOrSouth='" + northOrSouth + '\'' +
                ", westOrEast='" + westOrEast + '\'' +
                ", starNum='" + starNum + '\'' +
                ", gpsNormal='" + gpsNormal + '\'' +
                ", signalStrength='" + signalStrength + '\'' +
                ", fourGNormal='" + fourGNormal + '\'' +
                ", locationInfoNo=" + locationInfoNo +
                ", villageInfoNo=" + villageInfoNo +
                ", innerVoltage=" + innerVoltage +
                ", barrierVoltage=" + barrierVoltage +
                ", pressure=" + pressure +
                ", innerTemperature=" + innerTemperature +
                ", workHour=" + workHour +
                ", mileage=" + mileage +
                ", accStatus='" + accStatus + '\'' +
                ", repairStatus='" + repairStatus + '\'' +
                ", hourDetail='" + hourDetail + '\'' +
                ", openBoxStatus='" + openBoxStatus + '\'' +
                ", relayStatus='" + relayStatus + '\'' +
                ", canCommunication='" + canCommunication + '\'' +
                ", fourEightFiveCommunication='" + fourEightFiveCommunication + '\'' +
                ", twoThreeTwoCommunication='" + twoThreeTwoCommunication + '\'' +
                ", provideElectricStatus='" + provideElectricStatus + '\'' +
                ", outElectricAlarm='" + outElectricAlarm + '\'' +
                ", barrierVoltageStatus='" + barrierVoltageStatus + '\'' +
                ", innerBarrierChargeStatus='" + innerBarrierChargeStatus + '\'' +
                ", innerBarrierVoltageStatus='" + innerBarrierVoltageStatus + '\'' +
                ", gpsWorkModel='" + gpsWorkModel + '\'' +
                ", gpsVersion='" + gpsVersion + '\'' +
                ", normalMessageData='" + normalMessageData + '\'' +
                ", createTime=" + createTime + '\'' +
                ", theoryCount=" + theoryCount + '\'' +
                ", theoryCountDate=" + theoryCountDate +
                '}';
    }
}
