package com.znlh.util;

import com.znlh.constant.Constants;

import java.util.Properties;

/**
 * kafka工具类
 */
public class KafkaUtil {

    public static Properties getKafkaConfig(String groupId) {
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", PropertiesUtil.getPropertyValue(Constants.BOOTSTRAP_SERVERS));
//        props.put("zookeeper.connect", PropertiesUtil.getPropertyValue(Constants.ZOOKEEPER_SERVERS));
        props.setProperty("group.id", groupId);
        props.setProperty("auto.offset.reset", PropertiesUtil.getPropertyValue(Constants.AUTO_OFFSET_RESET));

        return props;
    }

}
