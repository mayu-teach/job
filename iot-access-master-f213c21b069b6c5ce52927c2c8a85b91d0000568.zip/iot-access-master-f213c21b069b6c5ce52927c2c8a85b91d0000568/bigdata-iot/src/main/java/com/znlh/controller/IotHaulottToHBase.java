package com.znlh.controller;

import com.alibaba.fastjson.JSONObject;
import com.znlh.constant.Constants;
import com.znlh.dto.*;
import com.znlh.service.HaulottHBaseSink;
import com.znlh.util.GenerateRowKeyUtil;
import com.znlh.util.PropertiesUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.AllWindowFunction;
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Haulott->HBase
 */
public class IotHaulottToHBase implements Serializable {
    private static final long serialVersionUID = 3094933671042611074L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IotHaulottToHBase.class);

    private static final DateFormat DF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] args) {

        LOGGER.info("IotHaulottToHBase is starting......");

        // 1-获取Flink执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.enableCheckpointing(1 * 60 * 1000);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);

        // 2-设置数据源
        Properties prop = new Properties();
        prop.put("bootstrap.servers", PropertiesUtil.getPropertyValue(Constants.BOOTSTRAP_SERVERS_HAULOTT_PRD));
        prop.put("group.id", PropertiesUtil.getPropertyValue(Constants.KAFKA_GROUP_ID_HAULOTT_HBASE));
        prop.put("auto.offset.reset", PropertiesUtil.getPropertyValue(Constants.AUTO_OFFSET_RESET));

        FlinkKafkaConsumer011<String> kafkaConsumer011 =
                new FlinkKafkaConsumer011<>(PropertiesUtil.getPropertyValue(Constants.KAFKA_TOPICS_HAULOTT),
                        new SimpleStringSchema(), prop);

        kafkaConsumer011.setStartFromGroupOffsets();

        DataStream<String> text = env.addSource(kafkaConsumer011);

        // 3-处理
        DataStream<HLTInfoDto> hltInfo = text.map(new MapFunction<String, HLTInfoDto>() {
            @Override
            public HLTInfoDto map(String s) throws Exception {
                s = s.replace("\\", "").replace("\"{", "{").replace("}\"", "}");
                return JSONObject.parseObject(s, HLTInfoDto.class);
            }
        });

        DataStream<Map<String, List<Put>>> dataMap = hltInfo
                .countWindowAll(100)
                .apply(new AllWindowFunction<HLTInfoDto, Map<String, List<Put>>, GlobalWindow>() {

            @Override
            public void apply(GlobalWindow globalWindow, Iterable<HLTInfoDto> iterable, Collector<Map<String, List<Put>>> out) throws Exception {
                Map<String, List<Put>> map = new HashMap<>();

                List<Put> alarmPuts = new ArrayList<>();
                List<Put> batteryPuts = new ArrayList<>();
                List<Put> positionPuts = new ArrayList<>();
                List<Put> extPuts = new ArrayList<>();
                List<Put> faultPuts = new ArrayList<>();
                List<Put> hoursPuts = new ArrayList<>();
                List<Put> logPuts = new ArrayList<>();
                List<Put> instructionPuts = new ArrayList<>();

                for (HLTInfoDto info : iterable) {
                    // 报警信息
                    if (CollectionUtils.isNotEmpty(info.getHltAlarmInfoList())) {
                        for (HLTAlarmInfoDto hltAlarmInfo : info.getHltAlarmInfoList()) {
                            Put put = new Put(Bytes.toBytes(generateRowKey(hltAlarmInfo.getDataGenerateTime(), hltAlarmInfo.getDevCode())));
                            List<Field> fields = getDeclaredAndNotStaticFields(HLTAlarmInfoDto.class);
                            fields.forEach(field -> {
                                try {
                                    field.setAccessible(true);
                                    if (null != field.get(hltAlarmInfo)) {
                                        put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_ALARM_COLUMNFAMILY)),
                                                Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(hltAlarmInfo).toString()));
                                    }
                                } catch (Exception e) {
                                    LOGGER.error(hltAlarmInfo.toString() + "反射获取属性报错......");
                                }
                            });

                            alarmPuts.add(put);
                        }

                        map.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_ALARM_TABLE), alarmPuts);
                    }
                    // 电池信息
                    if (CollectionUtils.isNotEmpty(info.getHltBatteryRelaList())) {
                        for (HLTBatteryRelaDto hltBatteryRela : info.getHltBatteryRelaList()) {
                            Put put = new Put(Bytes.toBytes(generateRowKey(hltBatteryRela.getDataGenerateTime(), hltBatteryRela.getDevCode())));
                            List<Field> fields = getDeclaredAndNotStaticFields(HLTBatteryRelaDto.class);
                            fields.forEach(field -> {
                                try {
                                    field.setAccessible(true);
                                    if (null != field.get(hltBatteryRela)) {
                                        put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_BATTERY_COLUMNFAMILY)),
                                                Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(hltBatteryRela).toString()));
                                    }
                                } catch (Exception e) {
                                    LOGGER.error(hltBatteryRela.toString() + "反射获取属性报错......");
                                }
                            });

                            batteryPuts.add(put);
                        }

                        map.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_BATTERY_TABLE), batteryPuts);
                    }
                    // 位置信息
                    if (CollectionUtils.isNotEmpty(info.getHltDevPositionInfoList())) {
                        for (HLTDevPositionInfoDto hltDevPositionInfo : info.getHltDevPositionInfoList()) {
                            Put put = new Put(Bytes.toBytes(generateRowKey(hltDevPositionInfo.getDataGenerateTime(), hltDevPositionInfo.getDevCode())));
                            List<Field> fields = getDeclaredAndNotStaticFields(HLTDevPositionInfoDto.class);
                            fields.forEach(field -> {
                                try {
                                    field.setAccessible(true);
                                    if (null != field.get(hltDevPositionInfo)) {
                                        put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_POSITION_COLUMNFAMILY)),
                                                Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(hltDevPositionInfo).toString()));
                                    }
                                } catch (Exception e) {
                                    LOGGER.error(hltDevPositionInfo.toString() + "反射获取属性报错......");
                                }
                            });

                            positionPuts.add(put);
                        }

                        map.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_POSITION_TABLE), positionPuts);
                    }
                    // 其他信息
                    if (CollectionUtils.isNotEmpty(info.getHltExtInfoList())) {
                        for (HLTExtInfoDto hltExtInfo : info.getHltExtInfoList()) {
                            Put put = new Put(Bytes.toBytes(generateRowKey(hltExtInfo.getDataGenerateTime(), hltExtInfo.getDevCode())));
                            List<Field> fields = getDeclaredAndNotStaticFields(HLTExtInfoDto.class);
                            fields.forEach(field -> {
                                try {
                                    field.setAccessible(true);
                                    if (null != field.get(hltExtInfo)) {
                                        put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_EXT_COLUMNFAMILY)),
                                                Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(hltExtInfo).toString()));
                                    }
                                } catch (Exception e) {
                                    LOGGER.error(hltExtInfo.toString() + "反射获取属性报错......");
                                }
                            });

                            extPuts.add(put);
                        }

                        map.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_EXT_TABLE), extPuts);
                    }
                    // 报错信息
                    if (CollectionUtils.isNotEmpty(info.getHltFaultInfoList())) {
                        for (HLTFaultInfoDto hltFaultInfo : info.getHltFaultInfoList()) {
                            Put put = new Put(Bytes.toBytes(generateRowKey(hltFaultInfo.getDataGenerateTime(), hltFaultInfo.getDevCode())));
                            List<Field> fields = getDeclaredAndNotStaticFields(HLTFaultInfoDto.class);
                            fields.forEach(field -> {
                                try {
                                    field.setAccessible(true);
                                    if (null != field.get(hltFaultInfo)) {
                                        put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_FAULT_COLUMNFAMILY)),
                                                Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(hltFaultInfo).toString()));
                                    }
                                } catch (Exception e) {
                                    LOGGER.error(hltFaultInfo.toString() + "反射获取属性报错......");
                                }
                            });

                            faultPuts.add(put);
                        }

                        map.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_FAULT_TABLE), faultPuts);
                    }
                    // 操作时间信息
                    if (CollectionUtils.isNotEmpty(info.getHltOperateHoursList())) {
                        for (HLTOperateHoursDto hltOperateHours : info.getHltOperateHoursList()) {
                            Put put = new Put(Bytes.toBytes(generateRowKey(hltOperateHours.getDataGenerateTime(), hltOperateHours.getDevCode())));
                            List<Field> fields = getDeclaredAndNotStaticFields(HLTOperateHoursDto.class);
                            fields.forEach(field -> {
                                try {
                                    field.setAccessible(true);
                                    if (null != field.get(hltOperateHours)) {
                                        put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_HOURS_COLUMNFAMILY)),
                                                Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(hltOperateHours).toString()));
                                    }
                                } catch (Exception e) {
                                    LOGGER.error(hltOperateHours.toString() + "反射获取属性报错......");
                                }
                            });

                            hoursPuts.add(put);
                        }

                        map.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_HOURS_TABLE), hoursPuts);
                    }
                    // 操作日志信息
                    if (CollectionUtils.isNotEmpty(info.getHltOperateLogList())) {
                        for (HLTOperateLogDto hltOperateLog : info.getHltOperateLogList()) {
                            Put put = new Put(Bytes.toBytes(generateRowKey(hltOperateLog.getDataGenerateTime(), hltOperateLog.getDevCode())));
                            List<Field> fields = getDeclaredAndNotStaticFields(HLTOperateLogDto.class);
                            fields.forEach(field -> {
                                try {
                                    field.setAccessible(true);
                                    if (null != field.get(hltOperateLog)) {
                                        put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_LOG_COLUMNFAMILY)),
                                                Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(hltOperateLog).toString()));
                                    }
                                } catch (Exception e) {
                                    LOGGER.error(hltOperateLog.toString() + "反射获取属性报错......");
                                }
                            });

                            logPuts.add(put);
                        }

                        map.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_LOG_TABLE), logPuts);
                    }
                    // 平台动作信息
                    if (CollectionUtils.isNotEmpty(info.getHltPlatformInstructionsList())) {
                        for (HLTPlatformInstructionsDto hltPlatformInstructions : info.getHltPlatformInstructionsList()) {
                            Put put = new Put(Bytes.toBytes(generateRowKey(hltPlatformInstructions.getDataGenerateTime(),
                                    hltPlatformInstructions.getDevCode())));
                            List<Field> fields = getDeclaredAndNotStaticFields(HLTPlatformInstructionsDto.class);
                            fields.forEach(field -> {
                                try {
                                    field.setAccessible(true);
                                    if (null != field.get(hltPlatformInstructions)) {
                                        put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_INSTRUCTION_COLUMNFAMILY)),
                                                Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(hltPlatformInstructions).toString()));
                                    }
                                } catch (Exception e) {
                                    LOGGER.error(hltPlatformInstructions.toString() + "反射获取属性报错......");
                                }
                            });

                            instructionPuts.add(put);
                        }

                        map.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_HAULOTT_INSTRUCTION_TABLE), instructionPuts);
                    }

                }

                out.collect(map);
            }

        }).setParallelism(1);

        dataMap.addSink(new HaulottHBaseSink()).setParallelism(1);

        try {
            env.execute(IotHaulottToHBase.class.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 获取对象有效属性
     * @param clazz
     * @return
     */
    private static List<Field> getDeclaredAndNotStaticFields(Class clazz) {
        List<Field> fieldList = new ArrayList<Field>();
        Field[] fields = clazz.getDeclaredFields();
        for(Field field : fields) {
            if(!Modifier.isStatic(field.getModifiers())) {
                fieldList.add(field);
            }
        }

        return fieldList;
    }

    /**
     * 生成rowkey
     * @param dataGenerateTime
     * @param devCode
     * @return
     */
    private static String generateRowKey(String dataGenerateTime, String devCode) {
        String rowkey = null;

        if(StringUtils.isNotEmpty(dataGenerateTime)) {
            try {
                rowkey = GenerateRowKeyUtil.generateRowKey(devCode, Long.toString(DF.parse(dataGenerateTime).getTime()));
            } catch (ParseException e) {
                LOGGER.error("时间格式转换错误");
            }
        } else {
            rowkey = GenerateRowKeyUtil.generateRowKey(devCode, Long.toString(new Date().getTime()));
        }

        return rowkey;
    }

}
