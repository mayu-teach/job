package com.znlh.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 时间工具类
 */
public class DateUtils {

    private static final String DATE_FORMATTER = "yyyy-MM-dd HH:mm:ss";

    /**
     * 获取当天00:00:00
     * @return
     */
    public static Date getBeginOfDay() {
        Calendar cal = Calendar.getInstance();
        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), 0, 0, 0);
        Date endOfDate = cal.getTime();

        return endOfDate;
    }

    public static String getBeginOfDayStr() {
        Date endOfDate = getBeginOfDay();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMATTER);
        return sdf.format(endOfDate);
    }

    /**
     * 获取后一天00:00:00
     * @return
     */
    public static Date getBeginOfNextDay() {
        Calendar cal = Calendar.getInstance();
        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH) + 1, 0, 0, 0);
        Date beginOfDate = cal.getTime();

        return beginOfDate;
    }

    public static String getBeginOfNextDayStr() {
        Date beginOfDate = getBeginOfNextDay();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMATTER);
        return sdf.format(beginOfDate);
    }

}
