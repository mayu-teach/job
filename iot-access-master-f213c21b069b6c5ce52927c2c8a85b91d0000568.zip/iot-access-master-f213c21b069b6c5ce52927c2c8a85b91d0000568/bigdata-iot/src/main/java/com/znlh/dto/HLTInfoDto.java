package com.znlh.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Haulott信息
 */
public class HLTInfoDto implements Serializable {
    private static final long serialVersionUID = -739568594946670508L;

    private List<HLTAlarmInfoDto> hltAlarmInfoList;
    private List<HLTBatteryRelaDto> hltBatteryRelaList;
    private List<HLTDevPositionInfoDto> hltDevPositionInfoList;
    private List<HLTExtInfoDto> hltExtInfoList;
    private List<HLTFaultInfoDto> hltFaultInfoList;
    private List<HLTOperateHoursDto> hltOperateHoursList;
    private List<HLTOperateLogDto> hltOperateLogList;
    private List<HLTPlatformInstructionsDto> hltPlatformInstructionsList;

    public List<HLTAlarmInfoDto> getHltAlarmInfoList() {
        return hltAlarmInfoList;
    }

    public void setHltAlarmInfoList(List<HLTAlarmInfoDto> hltAlarmInfoList) {
        this.hltAlarmInfoList = hltAlarmInfoList;
    }

    public List<HLTBatteryRelaDto> getHltBatteryRelaList() {
        return hltBatteryRelaList;
    }

    public void setHltBatteryRelaList(List<HLTBatteryRelaDto> hltBatteryRelaList) {
        this.hltBatteryRelaList = hltBatteryRelaList;
    }

    public List<HLTDevPositionInfoDto> getHltDevPositionInfoList() {
        return hltDevPositionInfoList;
    }

    public void setHltDevPositionInfoList(List<HLTDevPositionInfoDto> hltDevPositionInfoList) {
        this.hltDevPositionInfoList = hltDevPositionInfoList;
    }

    public List<HLTExtInfoDto> getHltExtInfoList() {
        return hltExtInfoList;
    }

    public void setHltExtInfoList(List<HLTExtInfoDto> hltExtInfoList) {
        this.hltExtInfoList = hltExtInfoList;
    }

    public List<HLTFaultInfoDto> getHltFaultInfoList() {
        return hltFaultInfoList;
    }

    public void setHltFaultInfoList(List<HLTFaultInfoDto> hltFaultInfoList) {
        this.hltFaultInfoList = hltFaultInfoList;
    }

    public List<HLTOperateHoursDto> getHltOperateHoursList() {
        return hltOperateHoursList;
    }

    public void setHltOperateHoursList(List<HLTOperateHoursDto> hltOperateHoursList) {
        this.hltOperateHoursList = hltOperateHoursList;
    }

    public List<HLTOperateLogDto> getHltOperateLogList() {
        return hltOperateLogList;
    }

    public void setHltOperateLogList(List<HLTOperateLogDto> hltOperateLogList) {
        this.hltOperateLogList = hltOperateLogList;
    }

    public List<HLTPlatformInstructionsDto> getHltPlatformInstructionsList() {
        return hltPlatformInstructionsList;
    }

    public void setHltPlatformInstructionsList(List<HLTPlatformInstructionsDto> hltPlatformInstructionsList) {
        this.hltPlatformInstructionsList = hltPlatformInstructionsList;
    }
}
