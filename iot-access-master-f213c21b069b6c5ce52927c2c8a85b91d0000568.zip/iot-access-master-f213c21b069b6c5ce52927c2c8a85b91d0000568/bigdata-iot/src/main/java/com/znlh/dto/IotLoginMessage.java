package com.znlh.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * iot登录信息实体类
 */
public class IotLoginMessage implements Serializable {


    private static final long serialVersionUID = -8587119046148253684L;

    // 主键
    private String id;
    // 流水号
    private String serialNo;
    // 命令号
    private String commandNo;
    // 终端id
    private String snId;
    // 登录时间
    private String loginTime;
    // iccid
    private String iccId;
    // 请求原始数据
    private String loginData;
    // 入库时间
    private Date createTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getCommandNo() {
        return commandNo;
    }

    public void setCommandNo(String commandNo) {
        this.commandNo = commandNo;
    }

    public String getSnId() {
        return snId;
    }

    public void setSnId(String snId) {
        this.snId = snId;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }

    public String getIccId() {
        return iccId;
    }

    public void setIccId(String iccId) {
        this.iccId = iccId;
    }

    public String getLoginData() {
        return loginData;
    }

    public void setLoginData(String loginData) {
        this.loginData = loginData;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "IotLoginMessage{" +
                "id='" + id + '\'' +
                ", serialNo='" + serialNo + '\'' +
                ", commandNo='" + commandNo + '\'' +
                ", snId='" + snId + '\'' +
                ", loginTime='" + loginTime + '\'' +
                ", iccId='" + iccId + '\'' +
                ", loginData='" + loginData + '\'' +
                ", createTime=" + createTime +
                '}';
    }
}
