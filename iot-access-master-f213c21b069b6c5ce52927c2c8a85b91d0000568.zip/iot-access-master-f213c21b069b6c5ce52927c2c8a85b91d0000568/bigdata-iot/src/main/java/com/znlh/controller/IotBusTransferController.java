package com.znlh.controller;

import com.znlh.constant.Constants;
import com.znlh.dto.IotBusMessage;
import com.znlh.dto.IotTransferStatus;
import com.znlh.util.DateUtils;
import com.znlh.util.HBaseUtils;
import com.znlh.util.PropertiesUtil;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * iot总线信息写入hbase全量表（每天跑增量）
 */
public class IotBusTransferController implements Serializable {

    private static final long serialVersionUID = 5007313144720508902L;

    private static final Logger LOGGER = LoggerFactory.getLogger(IotBusTransferController.class);

    public static void main(String[] args) {

        long minStamp = 0L;
        long maxStamp = 0L;
        String beginDate = "";
        String endDate = "";

        LOGGER.error("IotBusTransferController is starting......");

        // 从hbase获取更新开始结束时间
        HBaseUtils.getHBaseConnection();

        try {
            Result result = HBaseUtils.get(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_TRANSFER_STATUS_TABLE),
                    PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_TRANSFER_STATUS_COLUMNFAMILY),
                    PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_SIMPLE_TABLE));
            if(null != result) {
                for(Cell cell : result.listCells()) {
                    if("beginDate".equals(Bytes.toString(cell.getQualifierArray(), cell.getQualifierOffset(), cell.getQualifierLength()))) {
                        beginDate = Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength());
                    }
                    if("endDate".equals(Bytes.toString(cell.getQualifierArray(), cell.getQualifierOffset(), cell.getQualifierLength()))) {
                        endDate = Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength());
                    }
                }
            }
        } catch (Exception e) {
            HBaseUtils.closeHBaseConnection();
            throw new RuntimeException("IotBusTransferController 查询iot更新状态表出错");
        }

        SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMATTER);
        try {
            minStamp = sdf.parse(beginDate).getTime();
            maxStamp = sdf.parse(endDate).getTime();
        } catch (Exception e) {
            HBaseUtils.closeHBaseConnection();
            throw new RuntimeException("IotBusTransferController 格式化时间出错");
        }

        // 根据时间戳范围批量查询hbase数据
        ResultScanner resultScanner = HBaseUtils.scanByTimeRange(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_TABLE),
                PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_COLUMNFAMILY), minStamp, maxStamp);

        IotTransferStatus iotTransferStatus = new IotTransferStatus();
        if(null != resultScanner) {
            try {
                iotTransferStatus.setBeginDate(beginDate);
                iotTransferStatus.setEndDate(endDate);
                iotTransferStatus.setStatus(Constants.IOT_SYNC_IN_PROGRESS_STATUS);
                HBaseUtils.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_TRANSFER_STATUS_TABLE),
                        PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_SIMPLE_TABLE),
                        PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_TRANSFER_STATUS_COLUMNFAMILY),
                        iotTransferStatus);

                // 批量插入hbase
                getIotBusMessages(resultScanner);

                iotTransferStatus.setBeginDate(DateUtils.getBeginOfDayStr());
                iotTransferStatus.setEndDate(DateUtils.getBeginOfNextDayStr());
                iotTransferStatus.setStatus(Constants.IOT_SYNC_SUCCESS_STATUS);
                HBaseUtils.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_TRANSFER_STATUS_TABLE),
                        PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_SIMPLE_TABLE),
                        PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_TRANSFER_STATUS_COLUMNFAMILY),
                        iotTransferStatus);

                LOGGER.error("IotBusTransferController end......");
            } catch (Exception e) {
                iotTransferStatus.setBeginDate(beginDate);
                iotTransferStatus.setEndDate(endDate);
                iotTransferStatus.setStatus(Constants.IOT_SYNC_FAIL_STATUS);
                HBaseUtils.put(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_TRANSFER_STATUS_TABLE),
                        PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_SIMPLE_TABLE),
                        PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_TRANSFER_STATUS_COLUMNFAMILY),
                        iotTransferStatus);
                LOGGER.error("IotBusTransferController 批量插入hbase出错");
            } finally {
                HBaseUtils.closeHBaseConnection();
            }
        }

    }

    /**
     * 获取实时表数据
     * @param resultScanner
     * @return
     */
    private static void getIotBusMessages(ResultScanner resultScanner) {

        List<Put> puts = new ArrayList<Put>();
        Put put = null;
        List<Field> fields = HBaseUtils.getDeclaredAndNotStaticFields(IotBusMessage.class);

        Iterator<Result> its = resultScanner.iterator();
        while(its.hasNext()) {
            Result result = its.next();
            if(!result.isEmpty()) {
                put = new Put(result.getRow());
                for(Field field : fields) {
                    put.addColumn(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_ALL_COLUMNFAMILY)),
                            Bytes.toBytes(field.getName()),
                            result.getValue(Bytes.toBytes(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_COLUMNFAMILY)), Bytes.toBytes(field.getName())
                            )
                    );
                }

                puts.add(put);
                if(puts.size() == Constants.BATCH_SIZE) {
                    HBaseUtils.puts(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_ALL_TABLE), puts);
                    puts.clear();
                }
            }
        }

        if(!puts.isEmpty()) {
            HBaseUtils.puts(PropertiesUtil.getPropertyValue(Constants.HBASE_IOT_BUS_ALL_TABLE), puts);
        }
    }

}
