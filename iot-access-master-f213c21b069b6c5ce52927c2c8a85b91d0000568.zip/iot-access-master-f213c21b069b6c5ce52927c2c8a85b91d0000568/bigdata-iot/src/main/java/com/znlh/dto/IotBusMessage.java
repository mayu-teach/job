package com.znlh.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * iot总线信息实体类
 */
public class IotBusMessage implements Serializable {

    private static final long serialVersionUID = -4202213009776600030L;
    // 主键
    private String id;
    // 流水号
    private String serialNo;
    // 命令号
    private String commandNo;
    // 终端id
    private String snId;
    // 上报时间
    private String reportTime;
    // 数据类型
    private String dataType;
    // can解析后的json格式
    private String canDataJson;
    // can数据
    private String canData;
    // 485数据
    private String fourEightFiveData;
    // 232数据
    private String twoThreeTwoData;
    // 原始数据
    private String busMessageData;
    // 入库时间
    private Date createTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getCommandNo() {
        return commandNo;
    }

    public void setCommandNo(String commandNo) {
        this.commandNo = commandNo;
    }

    public String getSnId() {
        return snId;
    }

    public void setSnId(String snId) {
        this.snId = snId;
    }

    public String getReportTime() {
        return reportTime;
    }

    public void setReportTime(String reportTime) {
        this.reportTime = reportTime;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getCanDataJson() {
        return canDataJson;
    }

    public void setCanDataJson(String canDataJson) {
        this.canDataJson = canDataJson;
    }

    public String getCanData() {
        return canData;
    }

    public void setCanData(String canData) {
        this.canData = canData;
    }

    public String getFourEightFiveData() {
        return fourEightFiveData;
    }

    public void setFourEightFiveData(String fourEightFiveData) {
        this.fourEightFiveData = fourEightFiveData;
    }

    public String getTwoThreeTwoData() {
        return twoThreeTwoData;
    }

    public void setTwoThreeTwoData(String twoThreeTwoData) {
        this.twoThreeTwoData = twoThreeTwoData;
    }

    public String getBusMessageData() {
        return busMessageData;
    }

    public void setBusMessageData(String busMessageData) {
        this.busMessageData = busMessageData;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "IotBusMessage{" +
                "id='" + id + '\'' +
                ", serialNo='" + serialNo + '\'' +
                ", commandNo='" + commandNo + '\'' +
                ", snId='" + snId + '\'' +
                ", reportTime='" + reportTime + '\'' +
                ", dataType='" + dataType + '\'' +
                ", canDataJson='" + canDataJson + '\'' +
                ", canData='" + canData + '\'' +
                ", fourEightFiveData='" + fourEightFiveData + '\'' +
                ", twoThreeTwoData='" + twoThreeTwoData + '\'' +
                ", busMessageData='" + busMessageData + '\'' +
                ", createTime=" + createTime +
                '}';
    }
}
