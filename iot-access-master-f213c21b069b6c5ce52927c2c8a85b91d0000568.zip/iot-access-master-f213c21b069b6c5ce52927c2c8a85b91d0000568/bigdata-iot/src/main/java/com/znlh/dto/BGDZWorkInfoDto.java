package com.znlh.dto;

import java.io.Serializable;
import java.util.Date;

public class BGDZWorkInfoDto implements Serializable {

    private static final long serialVersionUID = -5094516898119727063L;

    /**
     * 车号
     */
    private String licenseId;
    /**
     * 车辆类型
     */
    private String machineType;

    /**
     * 车辆运行状态
     * 1: 工作
     * !=1 不工作
     */
    private Integer machineStatus;
    /**
     * 总工作小时数
     *
     */
    private Double workDuration;
    /**
     * (非高机用)设备总工作小时数
     *
     */
    private Double totalDuration;

    /**
     * 围栏状态设置
     * false："已设置,位置异常",
     * true："已设置,位置正常",
     */
    private Boolean fenceStatus;

    /**
     * 最新报警时间
     */
    private Date warningTime;

    /**
     * 最新报警信息
     * warningCode==0 无报警
     * warningCode!=0 有报警
     */
    private String latestAlarmInfo;

    /**
     * 定位状态
     */
    private String locateStatus;

    /**
     * GPS内置电池电压
     */
    private Double builtInVoltage;

    /**
     * 定位时长
     */
    private Long locateDuration;

    /**
     * 经度
     */
    private String latitudeNum;

    /**
     * 纬度
     */
    private String longitudeNum;

    /**
     * 定位位置-由经纬度换算出来的地理位置(高德逆编码)
     */
    private String address;

    /**
     * 终端编号
     */
    private String deviceNum;

    /**
     * 是否绑定
     */
    private Boolean isBind;
    /**
     * GPS可见卫星数
     */
    private String gpssignalStrength;

    /**
     * GPS可用卫星数
     */
    private String gprssignalStrength;

    /**
     * 开盖状态
     */
    private String lockerStatus;

    /**
     * gps软件版本
     */
    private String gpsSoftVersion;

    /**
     * gps硬件版本
     */
    private String gpsHardVersion;

    /**
     * SIM卡号
     */
    private String phoneNumber;

    /**
     * 定位时间(如果是定位数据不为空，如果是告警数据或者充电数据不会上传)
     */
    private String locateDateTime;

    /**
     * 数据接收时间
     */
    private String recordTime;

    /**
     * CAN通信状态
     */
    private String commStatus;

    /**
     * GPS天线
     */
    private String wireStatus;

    /**
     * GPS状态
     */
    private String gprsSignal;

    /**
     * GPS功能
     */
    private String gpsLocateFeatures;

    /**
     * AGPS功能
     */
    private String agpsFeatures;

    /**
     * 故障码
     */
    private String warningCode;

    /**
     * 高度百分比
     */
    private Integer hostHeight;
    /**
     * 负载百分比
     */
    private Integer loadWeight;

    /**
     * 是否超载
     */
    private Integer overloadAlarm;

    /**
     * 接收信号质量
     */
    private String gsmRxl;

    /**
     * GPS最新指令时间戳
     */
    private String gpsLocalDate;

    /**
     * 上升操作开关
     * 1：打开  !=1 关闭
     */
    private String chassisUp;

    /**
     * 下降操作开关
     * 1：打开  0: 关闭
     */
    private String chassisDown;

    /**
     * 坑洞保护板
     * 0:关闭 1：打开
     */
    private String pothole;

    /**
     * 平台控制 (0：下控/1：上控/null:电源关闭)
     */
    private String key;

    /**
     * 上限位开关
     * 1:未升到顶  0:已升到顶
     */
    private String upLimit;

    /**
     * 下限位开关
     * 1:收起  0:起升
     */
    private String downLimit;

    /**
     * 车辆运动
     * 1:前进
     */
    private String fetForward;

    /**
     * 车辆运动
     * 1:后退
     */
    private String fetReverse;

    /**
     * 车辆转向
     * 1:左转
     */
    private String fetLeft;

    /**
     * 车辆转向
     * 1:右转
     */
    private String fetRigth;

    /**
     * 车辆举升
     * 1:上升
     */
    private String fetUp;

    /**
     * 车辆举升
     * 1:下降
     */
    private String fetDown;

    /**
     * 喇叭
     * 1:开 0：关闭
     */
    private String fetHorn;

    /**
     * 蜂鸣器（开、关）
     * 1:开 0：关闭
     */
    private String fetAlarm;

    /**
     * 供电方式
     * 01:内电
     * 00：外电
     * !=00&01 :其他
     */
    private String gpsPowerStatus;

    /**
     * 倾斜状态
     * 0:倾斜
     * 1：水平
     */
    private String tilt;

    /**
     * 最大快速行走速度
     */
    private String highSpeedPercent;

    /**
     * 最大慢速行走速度
     */
    private String lowSpeedPercent;

    /**
     * 最大上升速度
     */
    private String maxUpSpeedPercent;

    /**
     * 起升后最大行走速度
     */
    private String maxStandSpeedPercent;

    /**
     * 称重标定状态
     */
    private String calibrationStatus;

    /**
     * 泵使能
     * 1：是
     * 0：否
     */
    private String fetMCE;

    /**
     * 泵电机转速
     */
    private String engineRPM;

    /**
     * 速度阀/电驱使能2
     * 1：是  0：否
     */
    private String fetParallel;

    /**
     * 油缸压力
     */
    private String oilPressure;

    /**
     * 锁车状态
     * 1：已锁车
     * 0：未锁车
     */
    private String lockState;

    /**
     * 限升状态
     * 1：限制举升
     * 0：不限制
     */
    private String limitUpStatus;

    /**
     * 车辆寻找状态
     */
    private String ecuSearchingStatus;

    /**
     * 龟速：截取第0位，0：弹起，1：按下
     * 当前模式（行走/举升）：截取第1位，0：行走，1：举升
     * 喇叭：截取第2位，0：弹起，1：按下
     * 使能：截取第3位，0：未使能，1：已使能
     * 手柄中位：截取第6位，0：否 ，1：是
     * 手柄模拟量：截取第7位，0：handleAnalog-127 1：handleAnalog
     */
    private String pcuStatus;

    /**
     * 手柄模拟量
     */
    private String handleAnalog;

    /**
     * 当前动作 （上升、下降/前进、后退/无）
     */
    private String pcuStatusDesc;

    /**
     * GPS基站定位
     * 1:已开启
     * 0:已关闭
     */
    private String lbsFeatures;

    /**
     * ECU ID
     * 如果=FFFFFFFF，可显示--
     */
    private String ecuID;

    /**
     * ECU软件版本
     */
    private String ecuSoftVersion;

    /**
     * PCU软件版本
     */
    private String pcuSoftVersion;

    /**
     * 行走时间
     */
    private Long runTotalTime;

    /**
     * 举升时间
     */
    private Long upTotalTime;

    /**
     * ECU状态
     * 0：初始化
     * 1：等待链接
     * 2：NVM初始化
     * 3：等待平台初始化
     * 4：协议初始化
     * 5：工作状态
     * 6：预留状态
     * 7：速度调节
     * 8：保存TRIP ANGLE状态
     * 9：限制操作状态
     * 10：Break Lease
     */
    private String ecuStatus;

    /**
     * 数据采集时间（不为空）
     */
    private String dataGenerateTime;

    /**
     * 协议号(A001、11、13)
     */
    private String versionNum;

    /**
     * A001协议的functionCode为消息类型:1002-工况信息，1001-定位信息，1003、2003-报警信息
     * 其他协议目前为MQTT
     */
    private String functionCode;

    public String getLicenseId() {
        return licenseId;
    }

    public void setLicenseId(String licenseId) {
        this.licenseId = licenseId;
    }

    public String getMachineType() {
        return machineType;
    }

    public void setMachineType(String machineType) {
        this.machineType = machineType;
    }

    public Integer getMachineStatus() {
        return machineStatus;
    }

    public void setMachineStatus(Integer machineStatus) {
        this.machineStatus = machineStatus;
    }

    public Double getWorkDuration() {
        return workDuration;
    }

    public void setWorkDuration(Double workDuration) {
        this.workDuration = workDuration;
    }

    public Double getTotalDuration() {
        return totalDuration;
    }

    public void setTotalDuration(Double totalDuration) {
        this.totalDuration = totalDuration;
    }

    public Boolean getFenceStatus() {
        return fenceStatus;
    }

    public void setFenceStatus(Boolean fenceStatus) {
        this.fenceStatus = fenceStatus;
    }

    public Date getWarningTime() {
        return warningTime;
    }

    public void setWarningTime(Date warningTime) {
        this.warningTime = warningTime;
    }

    public String getLatestAlarmInfo() {
        return latestAlarmInfo;
    }

    public void setLatestAlarmInfo(String latestAlarmInfo) {
        this.latestAlarmInfo = latestAlarmInfo;
    }

    public String getLocateStatus() {
        return locateStatus;
    }

    public void setLocateStatus(String locateStatus) {
        this.locateStatus = locateStatus;
    }

    public Double getBuiltInVoltage() {
        return builtInVoltage;
    }

    public void setBuiltInVoltage(Double builtInVoltage) {
        this.builtInVoltage = builtInVoltage;
    }

    public Long getLocateDuration() {
        return locateDuration;
    }

    public void setLocateDuration(Long locateDuration) {
        this.locateDuration = locateDuration;
    }

    public String getLatitudeNum() {
        return latitudeNum;
    }

    public void setLatitudeNum(String latitudeNum) {
        this.latitudeNum = latitudeNum;
    }

    public String getLongitudeNum() {
        return longitudeNum;
    }

    public void setLongitudeNum(String longitudeNum) {
        this.longitudeNum = longitudeNum;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDeviceNum() {
        return deviceNum;
    }

    public void setDeviceNum(String deviceNum) {
        this.deviceNum = deviceNum;
    }

    public Boolean getBind() {
        return isBind;
    }

    public void setBind(Boolean bind) {
        isBind = bind;
    }

    public String getGpssignalStrength() {
        return gpssignalStrength;
    }

    public void setGpssignalStrength(String gpssignalStrength) {
        this.gpssignalStrength = gpssignalStrength;
    }

    public String getGprssignalStrength() {
        return gprssignalStrength;
    }

    public void setGprssignalStrength(String gprssignalStrength) {
        this.gprssignalStrength = gprssignalStrength;
    }

    public String getLockerStatus() {
        return lockerStatus;
    }

    public void setLockerStatus(String lockerStatus) {
        this.lockerStatus = lockerStatus;
    }

    public String getGpsSoftVersion() {
        return gpsSoftVersion;
    }

    public void setGpsSoftVersion(String gpsSoftVersion) {
        this.gpsSoftVersion = gpsSoftVersion;
    }

    public String getGpsHardVersion() {
        return gpsHardVersion;
    }

    public void setGpsHardVersion(String gpsHardVersion) {
        this.gpsHardVersion = gpsHardVersion;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getLocateDateTime() {
        return locateDateTime;
    }

    public void setLocateDateTime(String locateDateTime) {
        this.locateDateTime = locateDateTime;
    }

    public String getRecordTime() {
        return recordTime;
    }

    public void setRecordTime(String recordTime) {
        this.recordTime = recordTime;
    }

    public String getCommStatus() {
        return commStatus;
    }

    public void setCommStatus(String commStatus) {
        this.commStatus = commStatus;
    }

    public String getWireStatus() {
        return wireStatus;
    }

    public void setWireStatus(String wireStatus) {
        this.wireStatus = wireStatus;
    }

    public String getGprsSignal() {
        return gprsSignal;
    }

    public void setGprsSignal(String gprsSignal) {
        this.gprsSignal = gprsSignal;
    }

    public String getGpsLocateFeatures() {
        return gpsLocateFeatures;
    }

    public void setGpsLocateFeatures(String gpsLocateFeatures) {
        this.gpsLocateFeatures = gpsLocateFeatures;
    }

    public String getAgpsFeatures() {
        return agpsFeatures;
    }

    public void setAgpsFeatures(String agpsFeatures) {
        this.agpsFeatures = agpsFeatures;
    }

    public String getWarningCode() {
        return warningCode;
    }

    public void setWarningCode(String warningCode) {
        this.warningCode = warningCode;
    }

    public Integer getHostHeight() {
        return hostHeight;
    }

    public void setHostHeight(Integer hostHeight) {
        this.hostHeight = hostHeight;
    }

    public Integer getLoadWeight() {
        return loadWeight;
    }

    public void setLoadWeight(Integer loadWeight) {
        this.loadWeight = loadWeight;
    }

    public Integer getOverloadAlarm() {
        return overloadAlarm;
    }

    public void setOverloadAlarm(Integer overloadAlarm) {
        this.overloadAlarm = overloadAlarm;
    }

    public String getGsmRxl() {
        return gsmRxl;
    }

    public void setGsmRxl(String gsmRxl) {
        this.gsmRxl = gsmRxl;
    }

    public String getGpsLocalDate() {
        return gpsLocalDate;
    }

    public void setGpsLocalDate(String gpsLocalDate) {
        this.gpsLocalDate = gpsLocalDate;
    }

    public String getChassisUp() {
        return chassisUp;
    }

    public void setChassisUp(String chassisUp) {
        this.chassisUp = chassisUp;
    }

    public String getChassisDown() {
        return chassisDown;
    }

    public void setChassisDown(String chassisDown) {
        this.chassisDown = chassisDown;
    }

    public String getPothole() {
        return pothole;
    }

    public void setPothole(String pothole) {
        this.pothole = pothole;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getUpLimit() {
        return upLimit;
    }

    public void setUpLimit(String upLimit) {
        this.upLimit = upLimit;
    }

    public String getDownLimit() {
        return downLimit;
    }

    public void setDownLimit(String downLimit) {
        this.downLimit = downLimit;
    }

    public String getFetForward() {
        return fetForward;
    }

    public void setFetForward(String fetForward) {
        this.fetForward = fetForward;
    }

    public String getFetReverse() {
        return fetReverse;
    }

    public void setFetReverse(String fetReverse) {
        this.fetReverse = fetReverse;
    }

    public String getFetLeft() {
        return fetLeft;
    }

    public void setFetLeft(String fetLeft) {
        this.fetLeft = fetLeft;
    }

    public String getFetRigth() {
        return fetRigth;
    }

    public void setFetRigth(String fetRigth) {
        this.fetRigth = fetRigth;
    }

    public String getFetUp() {
        return fetUp;
    }

    public void setFetUp(String fetUp) {
        this.fetUp = fetUp;
    }

    public String getFetDown() {
        return fetDown;
    }

    public void setFetDown(String fetDown) {
        this.fetDown = fetDown;
    }

    public String getFetHorn() {
        return fetHorn;
    }

    public void setFetHorn(String fetHorn) {
        this.fetHorn = fetHorn;
    }

    public String getFetAlarm() {
        return fetAlarm;
    }

    public void setFetAlarm(String fetAlarm) {
        this.fetAlarm = fetAlarm;
    }

    public String getGpsPowerStatus() {
        return gpsPowerStatus;
    }

    public void setGpsPowerStatus(String gpsPowerStatus) {
        this.gpsPowerStatus = gpsPowerStatus;
    }

    public String getTilt() {
        return tilt;
    }

    public void setTilt(String tilt) {
        this.tilt = tilt;
    }

    public String getHighSpeedPercent() {
        return highSpeedPercent;
    }

    public void setHighSpeedPercent(String highSpeedPercent) {
        this.highSpeedPercent = highSpeedPercent;
    }

    public String getLowSpeedPercent() {
        return lowSpeedPercent;
    }

    public void setLowSpeedPercent(String lowSpeedPercent) {
        this.lowSpeedPercent = lowSpeedPercent;
    }

    public String getMaxUpSpeedPercent() {
        return maxUpSpeedPercent;
    }

    public void setMaxUpSpeedPercent(String maxUpSpeedPercent) {
        this.maxUpSpeedPercent = maxUpSpeedPercent;
    }

    public String getMaxStandSpeedPercent() {
        return maxStandSpeedPercent;
    }

    public void setMaxStandSpeedPercent(String maxStandSpeedPercent) {
        this.maxStandSpeedPercent = maxStandSpeedPercent;
    }

    public String getCalibrationStatus() {
        return calibrationStatus;
    }

    public void setCalibrationStatus(String calibrationStatus) {
        this.calibrationStatus = calibrationStatus;
    }

    public String getFetMCE() {
        return fetMCE;
    }

    public void setFetMCE(String fetMCE) {
        this.fetMCE = fetMCE;
    }

    public String getEngineRPM() {
        return engineRPM;
    }

    public void setEngineRPM(String engineRPM) {
        this.engineRPM = engineRPM;
    }

    public String getFetParallel() {
        return fetParallel;
    }

    public void setFetParallel(String fetParallel) {
        this.fetParallel = fetParallel;
    }

    public String getOilPressure() {
        return oilPressure;
    }

    public void setOilPressure(String oilPressure) {
        this.oilPressure = oilPressure;
    }

    public String getLockState() {
        return lockState;
    }

    public void setLockState(String lockState) {
        this.lockState = lockState;
    }

    public String getLimitUpStatus() {
        return limitUpStatus;
    }

    public void setLimitUpStatus(String limitUpStatus) {
        this.limitUpStatus = limitUpStatus;
    }

    public String getEcuSearchingStatus() {
        return ecuSearchingStatus;
    }

    public void setEcuSearchingStatus(String ecuSearchingStatus) {
        this.ecuSearchingStatus = ecuSearchingStatus;
    }

    public String getPcuStatus() {
        return pcuStatus;
    }

    public void setPcuStatus(String pcuStatus) {
        this.pcuStatus = pcuStatus;
    }

    public String getHandleAnalog() {
        return handleAnalog;
    }

    public void setHandleAnalog(String handleAnalog) {
        this.handleAnalog = handleAnalog;
    }

    public String getPcuStatusDesc() {
        return pcuStatusDesc;
    }

    public void setPcuStatusDesc(String pcuStatusDesc) {
        this.pcuStatusDesc = pcuStatusDesc;
    }

    public String getLbsFeatures() {
        return lbsFeatures;
    }

    public void setLbsFeatures(String lbsFeatures) {
        this.lbsFeatures = lbsFeatures;
    }

    public String getEcuID() {
        return ecuID;
    }

    public void setEcuID(String ecuID) {
        this.ecuID = ecuID;
    }

    public String getEcuSoftVersion() {
        return ecuSoftVersion;
    }

    public void setEcuSoftVersion(String ecuSoftVersion) {
        this.ecuSoftVersion = ecuSoftVersion;
    }

    public String getPcuSoftVersion() {
        return pcuSoftVersion;
    }

    public void setPcuSoftVersion(String pcuSoftVersion) {
        this.pcuSoftVersion = pcuSoftVersion;
    }

    public Long getRunTotalTime() {
        return runTotalTime;
    }

    public void setRunTotalTime(Long runTotalTime) {
        this.runTotalTime = runTotalTime;
    }

    public Long getUpTotalTime() {
        return upTotalTime;
    }

    public void setUpTotalTime(Long upTotalTime) {
        this.upTotalTime = upTotalTime;
    }

    public String getEcuStatus() {
        return ecuStatus;
    }

    public void setEcuStatus(String ecuStatus) {
        this.ecuStatus = ecuStatus;
    }

    public String getDataGenerateTime() {
        return dataGenerateTime;
    }

    public void setDataGenerateTime(String dataGenerateTime) {
        this.dataGenerateTime = dataGenerateTime;
    }

    public String getVersionNum() {
        return versionNum;
    }

    public void setVersionNum(String versionNum) {
        this.versionNum = versionNum;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    @Override
    public String toString() {
        return  licenseId +
                "\t" + machineType +
                "\t" + machineStatus +
                "\t" + workDuration +
                "\t" + totalDuration +
                "\t" + fenceStatus +
                "\t" + warningTime +
                "\t" + latestAlarmInfo +
                "\t" + locateStatus +
                "\t" + builtInVoltage +
                "\t" + locateDuration +
                "\t" + latitudeNum +
                "\t" + longitudeNum +
                "\t" + address +
                "\t" + deviceNum +
                "\t" + isBind +
                "\t" + gpssignalStrength +
                "\t" + gprssignalStrength +
                "\t" + lockerStatus +
                "\t" + gpsSoftVersion +
                "\t" + gpsHardVersion +
                "\t" + phoneNumber +
                "\t" + locateDateTime +
                "\t" + recordTime +
                "\t" + commStatus +
                "\t" + wireStatus +
                "\t" + gprsSignal +
                "\t" + gpsLocateFeatures +
                "\t" + agpsFeatures +
                "\t" + warningCode +
                "\t" + hostHeight +
                "\t" + loadWeight +
                "\t" + overloadAlarm +
                "\t" + gsmRxl +
                "\t" + gpsLocalDate +
                "\t" + chassisUp +
                "\t" + chassisDown +
                "\t" + pothole +
                "\t" + key +
                "\t" + upLimit +
                "\t" + downLimit +
                "\t" + fetForward +
                "\t" + fetReverse +
                "\t" + fetLeft +
                "\t" + fetRigth +
                "\t" + fetUp +
                "\t" + fetDown +
                "\t" + fetHorn +
                "\t" + fetAlarm +
                "\t" + gpsPowerStatus +
                "\t" + tilt +
                "\t" + highSpeedPercent +
                "\t" + lowSpeedPercent +
                "\t" + maxUpSpeedPercent +
                "\t" + maxStandSpeedPercent +
                "\t" + calibrationStatus +
                "\t" + fetMCE +
                "\t" + engineRPM +
                "\t" + fetParallel +
                "\t" + oilPressure +
                "\t" + lockState +
                "\t" + limitUpStatus +
                "\t" + ecuSearchingStatus +
                "\t" + pcuStatus +
                "\t" + handleAnalog +
                "\t" + pcuStatusDesc +
                "\t" + lbsFeatures +
                "\t" + ecuID +
                "\t" + ecuSoftVersion +
                "\t" + pcuSoftVersion +
                "\t" + runTotalTime +
                "\t" + upTotalTime +
                "\t" + ecuStatus +
                "\t" + dataGenerateTime +
                "\t" + versionNum +
                "\t" + functionCode;
    }
}
