package com.znlh;

import com.znlh.dto.BGDZWorkInfoDto;
import com.znlh.dto.HLTAlarmInfoDto;
import com.znlh.util.GenerateRowKeyUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class Test01 {

    private static final DateFormat DF = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    private static final SimpleDateFormat DF1 = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.UK);

    private static final DateFormat DF2 = new SimpleDateFormat("yyyyMMdd");

    public static void main(String[] args) throws Exception {
//        BGDZWorkInfoDto workInfo = new BGDZWorkInfoDto();
//        workInfo.setDeviceNum("B21092983");
//        workInfo.setDataGenerateTime("2020-07-24T00:40:20.000+0000");
//        System.out.println(generateRowKey(workInfo));
        System.out.println(DF2.format(DF1.parse(DF.parse("2020-07-24T00:40:20.000+0000").toString())));
    }

    private static String generateRowKey(BGDZWorkInfoDto workInfo) {
        String rowkey = null;
        String dataGenerateTime = workInfo.getDataGenerateTime();
        try {
            rowkey = GenerateRowKeyUtil.generateRowKey(workInfo.getDeviceNum(), Long.toString(DF1.parse(DF.parse(dataGenerateTime).toString()).getTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return rowkey;
    }

}
