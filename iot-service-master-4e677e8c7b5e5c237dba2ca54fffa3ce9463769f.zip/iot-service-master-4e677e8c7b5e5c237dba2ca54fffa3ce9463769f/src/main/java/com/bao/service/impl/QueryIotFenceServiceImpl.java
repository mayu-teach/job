package com.bao.service.impl;

import com.bao.common.Result;
import com.bao.dao.QueryIotFenceDao;
import com.bao.dto.IotFenceDto;
import com.bao.dto.IotVoltageDto;
import com.bao.model.IotFenceRequest;
import com.bao.service.QueryIotFenceService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("queryIotFenceService")
public class QueryIotFenceServiceImpl implements QueryIotFenceService {

    @Resource
    QueryIotFenceDao queryIotFenceDao;

    @Override
    public Result<IotFenceDto> queryIotFenceList(IotFenceRequest req) {

        Result result = new Result();

        try {
            List<IotFenceDto> iotFenceList = queryIotFenceDao.queryIotFenceList(req);

            result.setData(iotFenceList);
            result.setErrcode(100000);
            result.setErrmsg("查询成功");

        } catch (Exception e) {
            result.setErrcode(111111);
            result.setErrmsg("查询异常");
        }
        return result;
    }

    @Override
    public Result<IotVoltageDto> queryVoltageTrend(String gpsCode, String startDate, String endDate) {

        Result result = new Result();

        try {
            List<IotVoltageDto> iotVoltageList = queryIotFenceDao.queryVoltageTrend(gpsCode, startDate, endDate);

            result.setData(iotVoltageList);
            result.setErrcode(100000);
            result.setErrmsg("查询成功");
        } catch (Exception e) {
            result.setErrcode(111111);
            result.setErrmsg("查询异常");
        }
        return result;
    }
}
