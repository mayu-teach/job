package com.bao.service;

import com.bao.common.Result;
import com.bao.dto.IotFenceDto;
import com.bao.dto.IotVoltageDto;
import com.bao.model.IotFenceRequest;

public interface QueryIotFenceService {

    Result<IotFenceDto> queryIotFenceList(IotFenceRequest req);

    Result<IotVoltageDto> queryVoltageTrend(String gpsCode, String startDate, String endDate);

}
