package com.bao.model;

public class IotFenceRequest {

    private String gpsCode;
    private String startTime;
    private String endTime;
    private String gpsType;

    public String getGpsCode() {
        return gpsCode;
    }

    public void setGpsCode(String gpsCode) {
        this.gpsCode = gpsCode;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getGpsType() {
        return gpsType;
    }

    public void setGpsType(String gpsType) {
        this.gpsType = gpsType;
    }

    @Override
    public String toString() {
        return "IotFenceRequest{" +
                "gpsCode='" + gpsCode + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", gpsType='" + gpsType + '\'' +
                '}';
    }
}
