package com.bao.util;

import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.net.InetAddress;
import java.util.List;
import java.util.Map;

/**
 * ES工具类
 */
@Service("elasticSearch")
public class ElasticSearchUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(ElasticSearchUtils.class);

    private TransportClient client;

    public TransportClient getClient() {
        return client;
    }

    public void setClient(TransportClient client) {
        this.client = client;
    }
//    static {
//        Settings settings = Settings.builder().put("cluster.name", "iot").build();
//        try {
//            client = new PreBuiltTransportClient(settings).addTransportAddresses(
//                    new TransportAddress(InetAddress.getByName("192.168.2.132"), 9400)
//                    ,new TransportAddress(InetAddress.getByName("192.168.2.133"), 9400)
//                    ,new TransportAddress(InetAddress.getByName("192.168.2.134"), 9400)
//            );
//            LOGGER.error("ES连接建立成功......");
//        } catch (UnknownHostException e) {
//            LOGGER.error("ES连接建立失败......");
//        }
//    }

    /**
     * 创建ES client
     * @return
     */
    @PostConstruct
    public TransportClient open () {
        Settings settings = Settings.builder().put("cluster.name", "iot").build();
        try {
            client = new PreBuiltTransportClient(settings).addTransportAddresses(
                    new TransportAddress(InetAddress.getByName("192.168.2.132"), 9400)
                    ,new TransportAddress(InetAddress.getByName("192.168.2.133"), 9400)
                    ,new TransportAddress(InetAddress.getByName("192.168.2.134"), 9400)
            );
            LOGGER.error(client + "====");
        } catch (Exception e) {
            LOGGER.error("ES connection error......");
        }

        return client;
    }

    /**
     * 批量插入
     * @param lst  iot_datang_fence_202005
     * @param client
     */
    public void batchInsert (List<Map> lst, TransportClient client, String indexName) {

        BulkRequestBuilder bulkRequestBuilder = client.prepareBulk();
        for (Map m : lst) {
            bulkRequestBuilder.add(client.prepareIndex(indexName, "_doc").setSource(m));
        }
        BulkResponse bulkItemResponses = bulkRequestBuilder.execute().actionGet();
        if (null == bulkItemResponses || bulkItemResponses.hasFailures()) {
            LOGGER.error("batch error..............");
        }

    }

    /**
     * 关闭ES client
     */
    @PreDestroy
    public void close () {
        if (null != client) {
            client.close();
            LOGGER.error("TransportClient is closed..............");
        }
    }

}
