package com.bao.util;

import com.alibaba.fastjson.JSONObject;
import com.bao.common.Result;
import com.bao.model.IotFenceRequest;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 时间工具类
 */
public class DateUtils {

    private static final String DATE_FORMATTER = "yyyy-MM-dd HH:mm:ss";

    /**
     * 获取某一个日期的下一天
     * @param str
     * @return
     */
    public static String getNextDateStr (String str) {

        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMATTER);
        long addTime=1;   //以1为乘以的基数
        addTime*=1;   //1天以后   （如果是30天以后，则这里是30）
        addTime*=24;   //1天24小时
        addTime*=60;   //1小时60分钟
        addTime*=60;   //1分钟60秒
        addTime*=1000;   //1秒=1000毫秒

        Date date = null;
        try {
            date = sdf.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return sdf.format(new Date(date.getTime()+addTime));
    }

    /**
     * 比较两个日期大小
     * @param date1
     * @param date2
     * @return
     */
    public static boolean compareDate (String date1, String date2) {

        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMATTER);
        Date d1 = null;
        Date d2 = null;
        try {
            d1 = sdf.parse(date1);
            d2 = sdf.parse(date2);
        } catch (ParseException e) {
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "结束时间和开始时间必须为(yyyy-MM-dd HH:mm:ss)格式", null)));
        }
        return d1.getTime() > d2.getTime();
    }

    /**
     * 比较两个日期是否大于7天
     * @param date1
     * @param date2
     * @return
     */
    public static boolean compareDateWithDays (String date1, String date2) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d1 = null;
        Date d2 = null;
        try {
            d1 = sdf.parse(date1);
            d2 = sdf.parse(date2);
        } catch (ParseException e) {
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "结束时间和开始时间必须为(yyyy-MM-dd HH:mm:ss)格式", null)));
        }
        long betweenDate = (d1.getTime() - d2.getTime()) / (60*60*24*1000);
        System.out.println(betweenDate);
        return betweenDate - 3 > 0 ? false : true;
    }

    /**
     * 比较两个日期是否大于1天
     * @param date1
     * @param date2
     * @return
     */
    public static boolean compareDateWithOneDays (String date1, String date2) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d1 = null;
        Date d2 = null;
        try {
            d1 = sdf.parse(date1);
            d2 = sdf.parse(date2);
        } catch (ParseException e) {
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "结束时间和开始时间必须为(yyyy-MM-dd HH:mm:ss)格式", null)));
        }
        long betweenDate = (d1.getTime() - d2.getTime()) / (60*60*24*1000);
        return betweenDate - 1 > 0 ? false : true;
    }

    public static void main(String[] args) {

        if (!compareDateWithDays("2020-08-05 00:00:00", "2020-08-01 00:00:00")) {
            System.out.println("大于3天");
        } else {
            System.out.println("3天内");
        }
    }

}
