package com.bao.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Presto工具类
 */
@Service("presto")
public class PrestoUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(PrestoUtils.class);

    private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    @PostConstruct
    public Connection open () {
        try {
            Class.forName("com.facebook.presto.jdbc.PrestoDriver");
            connection = DriverManager.getConnection("jdbc:presto://192.168.2.131:8086/hive/ods", "dw", "");
        } catch (Exception e) {
            LOGGER.error("Presto connection error......");
        }

        return connection;
    }

    @PreDestroy
    public void close () {
        if (null != connection) {
            try {
                connection.close();
                LOGGER.error("connection is closed..............");
            } catch (SQLException e) {
                LOGGER.error("TransportClient close error......");
            }
        }
    }

}
