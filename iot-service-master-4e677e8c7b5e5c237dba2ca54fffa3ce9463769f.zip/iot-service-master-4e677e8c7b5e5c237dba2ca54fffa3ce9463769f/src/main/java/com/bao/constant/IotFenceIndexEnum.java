package com.bao.constant;

/**
 * ES-index映射关系
 */
public enum IotFenceIndexEnum {
    DATANG("1", "iot_datang_fence_202005"),
    HAULOTT("2", "iot_haulott_fence_data"),
    LINGONG("3", "iot_lingong_fence_data"),
    ZNLH("4", "iot_znlh_fence_data");

    private String type;
    private String index;

    IotFenceIndexEnum (String type, String index) {
        this.type = type;
        this.index = index;
    }

    public static String getIndexName(String type) {
        if (DATANG.getType().equals(type)) {
            return DATANG.getIndex();
        } else if (HAULOTT.getType().equals(type)) {
            return HAULOTT.getIndex();
        } else if (LINGONG.getType().equals(type)) {
            return LINGONG.getIndex();
        } else if (ZNLH.getType().equals(type)) {
            return ZNLH.getIndex();
        } else {
            return "";
        }
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }
}
