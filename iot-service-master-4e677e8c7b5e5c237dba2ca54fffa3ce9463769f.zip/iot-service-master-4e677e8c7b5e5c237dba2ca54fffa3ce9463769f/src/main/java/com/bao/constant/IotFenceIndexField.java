package com.bao.constant;

/**
 * ES-index与field对应关系
 */
public class IotFenceIndexField {

    /**
     * 定位时间
     */
    public enum IndexLocationTime {
        DATANG("1", "lastLocationTime"),
        HAULOTT("2", "PstnTime"),
        LINGONG("3", "locateDateTime"),
        ZNLH("4", "report_time");

        private String type;
        private String value;

        IndexLocationTime (String type, String value) {
            this.type = type;
            this.value = value;
        }

        public static String getFieldName(String type) {
            if (DATANG.getType().equals(type)) {
                return DATANG.getValue();
            } else if (HAULOTT.getType().equals(type)) {
                return HAULOTT.getValue();
            } else if (LINGONG.getType().equals(type)) {
                return LINGONG.getValue();
            } else if (ZNLH.getType().equals(type)) {
                return ZNLH.getValue();
            } else {
                return "";
            }
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    /**
     * 终端号
     */
    public enum IndexGpsCode {
        DATANG("1", "deviceName"),
        HAULOTT("2", "DeviceID"),
        LINGONG("3", "deviceNum"),
        ZNLH("4", "sn_id");

        private String type;
        private String value;

        IndexGpsCode (String type, String value) {
            this.type = type;
            this.value = value;
        }

        public static String getFieldName(String type) {
            if (DATANG.getType().equals(type)) {
                return DATANG.getValue();
            } else if (HAULOTT.getType().equals(type)) {
                return HAULOTT.getValue();
            } else if (LINGONG.getType().equals(type)) {
                return LINGONG.getValue();
            } else if (ZNLH.getType().equals(type)) {
                return ZNLH.getValue();
            } else {
                return "";
            }
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    /**
     * 经度
     */
    public enum IndexLongitude {
        DATANG("1", "longitude"),
        HAULOTT("2", "Lo"),
        LINGONG("3", "longitudeNum"),
        ZNLH("4", "longitude");

        private String type;
        private String value;

        IndexLongitude (String type, String value) {
            this.type = type;
            this.value = value;
        }

        public static String getFieldName(String type) {
            if (DATANG.getType().equals(type)) {
                return DATANG.getValue();
            } else if (HAULOTT.getType().equals(type)) {
                return HAULOTT.getValue();
            } else if (LINGONG.getType().equals(type)) {
                return LINGONG.getValue();
            } else if (ZNLH.getType().equals(type)) {
                return ZNLH.getValue();
            } else {
                return "";
            }
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    /**
     * 纬度
     */
    public enum IndexLatitude {
        DATANG("1", "latitude"),
        HAULOTT("2", "La"),
        LINGONG("3", "latitudeNum"),
        ZNLH("4", "latitude");

        private String type;
        private String value;

        IndexLatitude (String type, String value) {
            this.type = type;
            this.value = value;
        }

        public static String getFieldName(String type) {
            if (DATANG.getType().equals(type)) {
                return DATANG.getValue();
            } else if (HAULOTT.getType().equals(type)) {
                return HAULOTT.getValue();
            } else if (LINGONG.getType().equals(type)) {
                return LINGONG.getValue();
            } else if (ZNLH.getType().equals(type)) {
                return ZNLH.getValue();
            } else {
                return "";
            }
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    /**
     * GPS信号强度
     */
    public enum IndexGPSSignalStrength {
        DATANG("1", "gpsCount"),
        HAULOTT("2", "Satellite"),
        // 临工GPS信号强度对应key待定，目前没有
        LINGONG("3", "gpsSignal");

        private String type;
        private String value;

        IndexGPSSignalStrength (String type, String value) {
            this.type = type;
            this.value = value;
        }

        public static String getFieldName(String type) {
            if (DATANG.getType().equals(type)) {
                return DATANG.getValue();
            } else if (HAULOTT.getType().equals(type)) {
                return HAULOTT.getValue();
            } else if (LINGONG.getType().equals(type)) {
                return LINGONG.getValue();
            } else {
                return "";
            }
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

}
