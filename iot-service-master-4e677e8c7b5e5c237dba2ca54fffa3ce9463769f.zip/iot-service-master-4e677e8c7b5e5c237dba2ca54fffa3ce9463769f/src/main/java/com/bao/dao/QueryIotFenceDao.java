package com.bao.dao;

import com.bao.dto.IotFenceDto;
import com.bao.dto.IotVoltageDto;
import com.bao.model.IotFenceRequest;

import java.util.List;

public interface QueryIotFenceDao {

    List<IotFenceDto> queryIotFenceList (IotFenceRequest req);

    List<IotVoltageDto> queryVoltageTrend (String gpsCode, String startDate, String endDate);

}
