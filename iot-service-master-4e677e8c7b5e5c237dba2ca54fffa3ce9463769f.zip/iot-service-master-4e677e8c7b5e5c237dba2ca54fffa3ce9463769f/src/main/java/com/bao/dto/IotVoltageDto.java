package com.bao.dto;

public class IotVoltageDto {

    private String gpsCode;
    private Double barrierVoltage;
    private String reportTime;

    public IotVoltageDto(String gpsCode, Double barrierVoltage, String reportTime) {
        this.gpsCode = gpsCode;
        this.barrierVoltage = barrierVoltage;
        this.reportTime = reportTime;
    }

    public String getGpsCode() {
        return gpsCode;
    }

    public void setGpsCode(String gpsCode) {
        this.gpsCode = gpsCode;
    }

    public Double getBarrierVoltage() {
        return barrierVoltage;
    }

    public void setBarrierVoltage(Double barrierVoltage) {
        this.barrierVoltage = barrierVoltage;
    }

    public String getReportTime() {
        return reportTime;
    }

    public void setReportTime(String reportTime) {
        this.reportTime = reportTime;
    }
}
