package com.bao.dto;

public class IotFenceDto {

    private String gpsCode;
    private String longitude;
    private String latitude;
    private String locateTime;
    // 新增GPS信号强度
    private String gpsSignal;

    public IotFenceDto(String gpsCode, String longitude, String latitude, String locateTime, String gpsSignal) {
        this.gpsCode = gpsCode;
        this.longitude = longitude;
        this.latitude = latitude;
        this.locateTime = locateTime;
        this.gpsSignal = gpsSignal;
    }

    public String getGpsCode() {
        return gpsCode;
    }

    public void setGpsCode(String gpsCode) {
        this.gpsCode = gpsCode;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLocateTime() {
        return locateTime;
    }

    public void setLocateTime(String locateTime) {
        this.locateTime = locateTime;
    }

    public String getGpsSignal() {
        return gpsSignal;
    }

    public void setGpsSignal(String gpsSignal) {
        this.gpsSignal = gpsSignal;
    }
}
