package com.bao.test;

import com.alibaba.fastjson.JSONObject;
import com.bao.dto.IotFenceDto;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.get.MultiGetResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.sort.SortOrder;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main(String[] args) throws Exception {

        testDaTang();

    }

    /**
     * 自研
     */
    private static void testZiYan () {
        // 设置集群名称biehl01,Settings设置es的集群名称,使用的设计模式，链式设计模式、build设计模式。
        Settings settings = Settings.builder().put("cluster.name", "iot").build();
        // 读取es集群中的数据,创建client。
        TransportClient client = null;
        int count = 0;
        List<IotFenceDto> list = new ArrayList<>();

        try {
            long startDate = System.currentTimeMillis();

            client = new PreBuiltTransportClient(settings).addTransportAddresses(
                    new TransportAddress(InetAddress.getByName("192.168.2.133"), 9400)
            );

            // report_time.keyword
            QueryBuilder queryBuilder1 = QueryBuilders.rangeQuery("report_time")
                    .from("20-07-01 00:00:00")
                    .to("20-07-08 00:00:00");
            // ED0120041098
            QueryBuilder queryBuilder2 = QueryBuilders.termQuery("sn_id","ED0119120001");

            // iot_ziyan_fence_new  iot_znlh_fence_data
            SearchResponse scrollResp = client.prepareSearch("iot_znlh_fence_data")
                    .addSort("report_time", SortOrder.DESC)
                    .addSort("sn_id", SortOrder.ASC)
                    .setScroll(new TimeValue(60000))
                    .setQuery(queryBuilder1)
                    .setPostFilter(QueryBuilders.termQuery("sn_id","ED0119120001"))
                    .setSize(10000)
                    .execute()
                    .actionGet();
            do {
                for (SearchHit hit : scrollResp.getHits().getHits()) {
                    count ++;
                    list.add(parseSourceToObject(hit.getSourceAsString()));
                }

                scrollResp = client.prepareSearchScroll(scrollResp.getScrollId())
                        .setScroll(new TimeValue(60000))
                        .execute()
                        .actionGet();
            } while (scrollResp.getHits().getHits().length != 0);

            long endDate = System.currentTimeMillis();

            System.out.println((endDate - startDate) + " ms");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            client.close();
            System.out.println(count);
        }
    }

    /**
     * 大唐
     */
    private static void testDaTang () {
        // 设置集群名称biehl01,Settings设置es的集群名称,使用的设计模式，链式设计模式、build设计模式。
        Settings settings = Settings.builder().put("cluster.name", "iot").build();
        // 读取es集群中的数据,创建client。
        TransportClient client = null;
        int count = 0;
        List<IotFenceDto> list = new ArrayList<>();

        try {
            long startDate = System.currentTimeMillis();

            client = new PreBuiltTransportClient(settings).addTransportAddresses(
                    new TransportAddress(InetAddress.getByName("192.168.2.132"), 9400)
                    ,new TransportAddress(InetAddress.getByName("192.168.2.133"), 9400)
                    ,new TransportAddress(InetAddress.getByName("192.168.2.134"), 9400)
            );

            // report_time.keyword
            QueryBuilder queryBuilder1 = QueryBuilders.rangeQuery("lastLocationTime")
                    .from("2020-08-13 00:00:00")
                    .to("2020-08-13 23:59:59");
            // ED0120041098
//            QueryBuilder queryBuilder2 = QueryBuilders.termQuery("deviceName","23030541");

            // iot_ziyan_fence_new  iot_znlh_fence_data
            SearchResponse scrollResp = client.prepareSearch("iot_datang_fence_202005")
                    .addSort("lastLocationTime", SortOrder.DESC)
//                    .addSort("deviceName", SortOrder.ASC)
                    .setScroll(new TimeValue(60000))
                    .setQuery(queryBuilder1)
//                    .setPostFilter(QueryBuilders.termQuery("deviceName","1120072D"))
                    .setSize(10000)
                    .execute()
                    .actionGet();
            do {
                for (SearchHit hit : scrollResp.getHits().getHits()) {
                    count ++;
                    list.add(parseSourceToObject(hit.getSourceAsString()));
                }

                scrollResp = client.prepareSearchScroll(scrollResp.getScrollId())
                        .setScroll(new TimeValue(60000))
                        .execute()
                        .actionGet();
            } while (scrollResp.getHits().getHits().length != 0);

            long endDate = System.currentTimeMillis();

            System.out.println((endDate - startDate) + " ms");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            client.close();
            System.out.println(count);
        }
    }

    /**
     * json
     * @param client
     * @return
     */
    private static GetResponse getAPI(TransportClient client) {
        return client.prepareGet("iot_ziyan_fence_data", "iot_ziyan_fence_data", "5n1zLXMBy-nSQmQhxbmG").get();
    }

    /**
     *
     * @param client
     * @return
     */
    private static MultiGetResponse multiGetAPI(TransportClient client) {
        return client.prepareMultiGet()
                .add("iot_ziyan_fence_data", "iot_ziyan_fence_data", "5n1zLXMBy-nSQmQhxbmG")
                .add("iot_ziyan_fence_data", "iot_ziyan_fence_data", "bH1zLXMBy-nSQmQhyMuj")
                .get();
    }

    /**
     *
     * @param source
     * @return
     */
    private static IotFenceDto parseSourceToObject (String source) {
        JSONObject json = JSONObject.parseObject(source);
        return new IotFenceDto(json.getString("sn_id"), json.getString("latitude"), json.getString("longitude")
                , json.getString("report_time"), json.getString("gpsSignal"));
    }

}
