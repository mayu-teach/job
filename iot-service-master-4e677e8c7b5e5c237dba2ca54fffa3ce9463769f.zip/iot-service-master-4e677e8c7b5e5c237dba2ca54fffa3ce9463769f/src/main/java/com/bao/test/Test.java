package com.bao.test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Test {

    private static final DateFormat DF = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    private static final SimpleDateFormat DF1 = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.UK);

    private static final DateFormat DF2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private static final DateFormat DF3 = new SimpleDateFormat("yyyy-MM-dd");

    private static final DateFormat DF4 = new SimpleDateFormat("yy-MM-dd HH:mm:ss");

    public static void main(String[] args) throws Exception {
        String oldDateStr = "2020-07-25 00:00:00";
        String newDateStr = "2020-07-26 00:00:00";
        String date1 = "20-07-29 15:21:57";
        System.out.println(DF2.parse(oldDateStr).getTime());
        System.out.println(DF2.parse(newDateStr).getTime());
        System.out.println(DF3.format(DF4.parse(date1)));
    }

    private static void test1 () {
        String oldDateStr = "2020-07-23T01:06:05.000+0000";
        Date date1 = null;
        DateFormat df2 = null;
        try {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            Date date = df.parse(oldDateStr);
            SimpleDateFormat df1 = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.UK);
            date1 = df1.parse(date.toString());
            df2 = new SimpleDateFormat("yyyyMMdd");
            System.out.println(df2.format(date1));
        } catch (ParseException e) {

            e.printStackTrace();
        }
    }

}
