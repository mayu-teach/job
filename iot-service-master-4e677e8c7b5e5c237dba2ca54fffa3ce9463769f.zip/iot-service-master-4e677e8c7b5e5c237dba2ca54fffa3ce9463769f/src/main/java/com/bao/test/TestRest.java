package com.bao.test;

import com.alibaba.fastjson.JSONObject;
import com.bao.common.Result;
import com.bao.dto.IotVoltageDto;
import com.bao.model.IotFenceRequest;
import com.bao.service.QueryIotFenceService;
import com.bao.util.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.Serializable;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/iot")
public class TestRest implements Serializable {

    private static final long serialVersionUID = 828066315764582187L;

    private static final Logger LOGGER = LoggerFactory.getLogger(TestRest.class);

    private String [] ES_INDEX_TYPES = {"1", "2", "3", "4"};

    @Resource
    private QueryIotFenceService queryIotFenceService;

    private static final DateFormat DF = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    private static final DateFormat DF1 = new SimpleDateFormat("yyyyMMdd");

    /**
     * 查询终端电子围栏信息
     * @param req
     * @return
     */
    @RequestMapping(value = "/queryIotFenceList", method = RequestMethod.POST)
    public String queryIotFenceList (@RequestBody String req) {

        LOGGER.info("queryIotFenceList request params：" + req);

        long beginDate = System.currentTimeMillis();

        IotFenceRequest fence = null;
        Result result = null;
        try {
            fence = JSONObject.parseObject(req, IotFenceRequest.class);
        } catch (Exception e) {
            result = new Result(111111, "参数异常", null);
            LOGGER.error("queryIotFenceList:参数异常");
            return JSONObject.toJSONString(result);
        }

        validateParams(fence);

        result = queryIotFenceService.queryIotFenceList(fence);

        long endDate = System.currentTimeMillis();
        LOGGER.info((endDate - beginDate) + " ms");

        return JSONObject.toJSONString(result);
    }

    /**
     * 查询终端车辆电压走势
     * @param req
     * @return
     */
    @RequestMapping(value = "/queryVoltageTrend", method = RequestMethod.POST)
    public String queryVoltageTrend (@RequestBody String req) {

        LOGGER.info("queryIotFenceList request params：" + req);

        JSONObject json = JSONObject.parseObject(req);

        validateParams(json);

        long beginDate = System.currentTimeMillis();

        Result<IotVoltageDto> result = queryIotFenceService.queryVoltageTrend(json.getString("gpsCode"),
                json.getString("startTime"), json.getString("endTime"));

        long endDate = System.currentTimeMillis();
        LOGGER.info((endDate - beginDate) + " ms");

        return JSONObject.toJSONString(result);
    }

    /**
     * 校验入参
     * @param fence
     * @return
     */
    private void validateParams (IotFenceRequest fence) {
        if (null == fence) {
            LOGGER.error("queryIotFenceList:参数异常");
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "参数异常", null)));
        } else if (StringUtils.isEmpty(fence.getGpsCode())) {
            LOGGER.error("queryIotFenceList:gpsCode不能为空");
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "gpsCode不能为空", null)));
        } else if (!Arrays.asList(ES_INDEX_TYPES).contains(fence.getGpsType())) {
            LOGGER.error("queryIotFenceList:gpsType不合法");
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "gpsType不合法", null)));
        } else if (!DateUtils.compareDate(fence.getEndTime(), fence.getStartTime())) {
            LOGGER.error("queryIotFenceList:结束时间必须大于开始时间");
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "结束时间必须大于开始时间", null)));
        }
        if (!DateUtils.compareDateWithDays(fence.getEndTime(), fence.getStartTime())) {
            LOGGER.error("queryIotFenceList:结束时间和开始时间相差不得大于3日");
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "结束时间和开始时间相差不得大于3日", null)));
        }
        // 临工 1595347200000 = 2020-07-22 00:00:00 第三方优化时间格式
        if ("3".equals(fence.getGpsType())) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                if (sdf.parse(fence.getStartTime()).getTime() <= 1595347200000L) {
                    fence.setStartTime(String.valueOf(sdf.parse(fence.getStartTime()).getTime()));
                    fence.setEndTime(String.valueOf(sdf.parse(fence.getEndTime()).getTime()));
                } else {
                    fence.setStartTime(DF.format(sdf.parse(fence.getStartTime())));
                    fence.setEndTime(DF.format(sdf.parse(fence.getEndTime())));
                }
            } catch (Exception e) {
                throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "开始时间或结束时间有误", null)));
            }
        }

    }

    /**
     * 校验入参
     * @param json
     */
    private void validateParams (JSONObject json) {
        if (json.isEmpty()) {
            LOGGER.error("queryVoltageTrend:参数异常");
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "参数异常", null)));
        }
        if (StringUtils.isEmpty(json.getString("gpsCode"))) {
            LOGGER.error("queryVoltageTrend:gpsCode不能为空");
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "gpsCode不能为空", null)));
        }
        if (!DateUtils.compareDateWithOneDays(json.getString("endTime"), json.getString("startTime"))) {
            LOGGER.error("queryVoltageTrend:结束时间和开始时间相差不得大于1日");
            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "结束时间和开始时间相差不得大于1日", null)));
        }
//        try {
//            json.put("startTime", json.getString("startTime").substring(0, 10).replace("-", ""));
//            json.put("endTime", json.getString("endTime").substring(0, 10).replace("-", ""));
//        } catch (Exception e) {
//            throw new RuntimeException(JSONObject.toJSONString(new Result(111111, "时间格式有误", null)));
//        }
    }

}
