#########################################################################################################
#功能描述：自动生成ods表建表脚本及执行脚本
#执行方式：getddl.sh 符合开发规范的库名 带schema的源表名 增量/全量,例:getddl.sh purnm pur_nm.risk_group 全量
#开发时间：2019-09-14
#开发人员：caoyang
#########################################################################################################
#!/bin/bash

#高亮输出
ECHOS()
{
	echo -e " \033[1;33;41m${1}\033[0m"
}

#写日志文件
Write_Log_File()
{
	now_time=`date +"%Y-%m-%d %H:%M:%S"`
	#echo "${now_time} 写日志文件：${1}"
	echo "${now_time} 写日志文件：${1}" >> ${Log_File}
}

#写日志、错误日志
Write_Error_Log_File()
{
	now_time=`date +"%Y-%m-%d %H:%M:%S"`
	ECHOS "${now_time} 写错误日志文件：${1}"
	ECHOS "${now_time} 写错误日志文件：${1}" >> ${Log_File}
	ECHOS "${now_time} 写错误日志文件：${1}" >> ${Error_Log_File}
}


#执行SQL
Mysql_Run_SQL()
{
	Write_Log_File "${1}"
	returnData=`mysql -h"${ip_addr}" -u"${db_user}" -p"${db_passwd}" -P"${db_port}" -e"${1}" 2>&1`

	if [ $? != 0 ]
	then
	        Write_Error_Log_File "SQL:${1},Error Msg: ${returnData}"
	        return_info="SQL ERROR!SQL: ${1};${return_info}"
	        ReturnStr="SQL ERROR"
	        exit -1
	else
	        ReturnStr=`echo "${returnData}"|sed -e '3,/^$/!d;/^$/d'`
	fi
}


##########################################################mian##########################################################
if [ $(echo "${0}" grep "/" ${0} | wc -l) -eq 1 ]
then
	read sh_name <<< $(echo "${0}" | awk -F'/' '{print $NF}' | awk -F'.' '{print $1}')
else
	read sh_name <<< $(echo "${0}" | awk -F'.' '{print $1}')
fi

YYYYMMDD=`date +"%Y%m%d"`

work_dir="/home/dw/shell"
cfg_file="${work_dir}/cfg/mysql_info.cfg"
Log_File="${work_dir}/log/${sh_name}.log"
Error_Log_File="${Log_File}.error"

if [ $# -ne 3 ]
then
	ECHOS "参数错误！必须有3个参数！"
	ECHOS "命令格式:getddl.sh 符合开发规范的库名 带schema的源表名 增量/全量"
	ECHOS "例子:getddl.sh purnm pur_nm.risk_group 全量"
	exit -1
else
	echo "${3}" | egrep "增量|全量" > /dev/null
	if [ $? -ne 0 ]
	then
		ECHOS "抽取类型只能是增量或者全量！"
		exit -1
	else
		dataDase=${1}
		fulltableNname=${2}
		exp_type=${3}
	fi
fi

##记录ods表信息
echo "`date +"%Y-%m-%d %H:%M:%S"`	${USER}	${dataDase}	${fulltableNname}	${exp_type}" >> ${work_dir}/log/${sh_name}_job.list

##拆分表名
read tab_schema tab_name <<< $(echo "${fulltableNname}" | awk -F'.' '{print $1,$2}')

##获取mysql库信息
grep "^${tab_schema}"$'\t' "${cfg_file}" > /dev/null
if [ $? -eq 0 ]
then
    read ip_addr db_user db_passwd db_port <<< $(grep "^${tab_schema}"$'\t' "${cfg_file}" | awk -F'	' '{print $2,$3,$4,$5}')
else
    Write_Error_Log_File "所查询源库信息未维护到配置文件中,请联系管理员添加"
    exit -1
fi

##脚本路径
script_dir="${HOME}/ods/${dataDase}"

mkdir -p ${script_dir}/job
mkdir -p ${script_dir}/createtable

##建表脚本名
ctsh_file="${script_dir}/createtable/ods_${dataDase}_${tab_name}.ctsh"

##执行脚本名
sh_file="${script_dir}/job/ods_${dataDase}_${tab_name}.sh"

#判断表是否存在
sqlstr="select count(0) from information_schema.tables
         where table_name='${tab_name}'
             and table_schema='${tab_schema}';"
Mysql_Run_SQL "${sqlstr}"
if [ ${ReturnStr} -ne 1 ]
then
	ECHOS "表${fulltableNname}不存在，请确认！"
	exit -1
fi

#获取中文表名
sqlstr="select table_comment from information_schema.tables
         where table_name='${tab_name}'
             and table_schema='${tab_schema}';"
Mysql_Run_SQL "${sqlstr}"
tab_chinese_name="${ReturnStr}"

##获取表字段数
sqlstr="select count(0)
        from information_schema.columns a
        where table_name='${tab_name}'
            and table_schema='${tab_schema}'
        order by ordinal_position;"
Mysql_Run_SQL "${sqlstr}"
col_num="${ReturnStr}"

##获取表字段信息sql
sqlstr="select case when ordinal_position=${col_num} then
                   concat(column_name ,' ',
                   case when data_type in ('varchar','char','mediumtext','text','longtext') then 'string'
                        when data_type in ('mediumint') then 'int'
                        when data_type in ('tinyint','bit') then 'smallint'
                        when data_type in ('decimal') then 'double'
                        when data_type in ('int','smallint','bigint') then data_type
                        when data_type in ('datetime') then 'timestamp'
                        when data_type in ('date') then 'date'
                   else data_type end,' comment ','''',replace(column_comment,';',','),'''')
               else
                   concat(column_name ,' ',
                   case when data_type in ('varchar','char','mediumtext','text','longtext') then 'string'
                        when data_type in ('mediumint') then 'int'
                        when data_type in ('tinyint','bit') then 'smallint'
                        when data_type in ('decimal') then 'double'
                        when data_type in ('int','smallint','bigint') then data_type
                        when data_type in ('datetime') then 'timestamp'
                        when data_type in ('date') then 'date'
                   else data_type end,' comment ','''',replace(column_comment,';',','),'''', ',')
               end as Colstr
        from information_schema.columns a
        where table_name='${tab_name}'
            and table_schema='${tab_schema}'
        order by ordinal_position;"
Mysql_Run_SQL "${sqlstr}"
tab_columns_info="${ReturnStr}"

#根据增量/全量生成相应脚本
if [ ${exp_type} = "全量" ]
then

####生成建表脚本####
echo "source /home/dw/.hive_config.sh
file_name=\"ods_${dataDase}_${tab_name}\"
table_name=\"ods.${dataDase}_${tab_name}\"
table_level=\"\${table_name%%\.*}\"

\$HIVE<< EOF
USE \${db_name};
DROP TABLE \${table_name};
CREATE EXTERNAL TABLE \${table_name}
(" > ${ctsh_file}

echo "${tab_columns_info}" >> ${ctsh_file}

echo ")COMMENT '${tab_chinese_name}'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
STORED AS orc
LOCATION '\${HDFS_DIR}/\${table_level}/\${file_name}';
ALTER TABLE \${table_name} SET SERDEPROPERTIES('serialization.null.format'='');

EOF" >> ${ctsh_file}

########生成执行脚本########
	echo "#!/bin/sh
source /home/dw/.hive_config.sh
#############################################
process_start
#############################################
hadoop fs -rm '/hive/ods/ods_${dataDase}_${tab_name}/*';
write_cgr \" 模块一：\"
write_log \" ${exp_type}导入ods_${dataDase}_${tab_name}\"
xdata \"/opt/script/datax/json/${dataDase}/ods_${dataDase}_${tab_name}.json\"

#############################################
process_end" > ${sh_file}

else  #如果是增量

	####生成建表脚本####
	echo "source /home/dw/.hive_config.sh
file_name=\"ods_${dataDase}_${tab_name}\"
table_name=\"ods.${dataDase}_${tab_name}\"
table_level=\"\${table_name%%\.*}\"

file_name_1=\"ods_${dataDase}_${tab_name}_cre\"
table_name_1=\"ods.${dataDase}_${tab_name}_cre\"
table_level_1=\"\${table_name%%\.*}\"

\$HIVE<< EOF
USE \${db_name};
DROP TABLE \${table_name};
CREATE EXTERNAL TABLE \${table_name}
(" > ${ctsh_file}

echo "${tab_columns_info}" >> ${ctsh_file}

echo ")COMMENT '${tab_chinese_name}'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
STORED AS orc
LOCATION '\${HDFS_DIR}/\${table_level}/\${file_name}';
ALTER TABLE \${table_name} SET SERDEPROPERTIES('serialization.null.format'='');

DROP TABLE \${table_name_1};
CREATE EXTERNAL TABLE \${table_name_1}
(" >> ${ctsh_file}

echo "${tab_columns_info}" >> ${ctsh_file}

echo ")COMMENT '${tab_chinese_name}(增量抽取临时表)'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
STORED AS orc
LOCATION '\${HDFS_DIR}/\${table_level_1}/\${file_name_1}';
ALTER TABLE \${table_name_1} SET SERDEPROPERTIES('serialization.null.format'='');

EOF" >> ${ctsh_file}

	########生成执行脚本########
	echo "#!/bin/sh
source /home/dw/.hive_config.sh
#############################################
process_start
#############################################
write_cgr \" 模块一：\"
hadoop fs -rm '/hive/ods/ods_${dataDase}_${tab_name}_cre/*'
write_log \" 增量导入ods_${dataDase}_${tab_name}\"
xdata \"/opt/script/datax/json/${dataDase}/ods_${dataDase}_${tab_name}.json\" \"-p-Djob_date='\${date_hor_2}' -Djob_end_date='\${current_date_hor}'\"

write_cgr \" 模块二: 数据合并\"
write_log \" 合并增量数据\"
sql_1=\"
set hive.auto.convert.join=false;
use \${db_name};
drop table if exists \${db_temp}.tmp_${dataDase}_${tab_name};
create table 
  \${db_temp}.tmp_${dataDase}_${tab_name}
as
select t.*
from
(
select * from ods.${dataDase}_${tab_name}_cre
union all
select a.*
from ods.${dataDase}_${tab_name} a
    left outer join ods.${dataDase}_${tab_name}_cre b
    on a.id=b.id
where b.id is null
)t;
insert overwrite table ods.${dataDase}_${tab_name}
select * from \${db_temp}.tmp_${dataDase}_${tab_name}
;

\"

spark_sql_txt \"\$sql_1\"
#############################################
process_end" > ${sh_file}

fi #if end

echo -e "已生成脚本：\n${ctsh_file}\n${sh_file}"
