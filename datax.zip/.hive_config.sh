source /etc/profile
#生成日志文件路径:截取文件名及扩展名
filename="${0##*/}"
tablename="${filename%%.*}"
LOG_FILE="/tmp/logs/${filename}_$date_`date "+%Y%m%d_%H%M%S"`_${RANDOM}.log"

#用于 hive 里面获得当前执行的是哪个表
export tablename=$tablename

write_log()
{
	str=$1
	f_color=$2

	v_str=""
	if [ "x$str" == "x" ];then
		v_str=""
	else
		cstr="`date "+%Y-%m-%d %H:%M:%S"` $str"
		v_str="${cstr}"
	fi

	#如果指定了颜色
	if [ "x${f_color}" != "x" ];then
		if [ "${f_color}" == "green" ];then
			v_str="\n\033[32m${cstr}\033[0m"
		fi

		if [ "${f_color}" == "yellow" ];then
			v_str="\033[33m${cstr}\033[0m"
		fi

		if [ "${f_color}" == "red" ];then
			v_str="\033[1;33;41m${cstr}\033[0m"
		fi
	fi

	echo -e "${v_str}"
	echo -e "${v_str}" >> $LOG_FILE 2>&1
}

write_cgr()
{
	write_log "$1" "green"
}

#→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→

#主机名
v_hostname=$(hostname)
#当前账户
SCRIPT_USER=$(whoami)

#元数据数据库 modify
#META_HOST="hx-hive_stats-master.db.org"
#META_PORT="3308"
#META_USER="hive"
#META_PAWD="123456"
#META_DB="mark"

#hive调用命令
HIVE=$(which hive 2> /dev/null)
if [ $? -ne 0 ];then
    write_log "没有安装或配置HIVE环境！" "yellow"
fi

YARN=$(which yarn)

#HBASE=$(which hbase)
#HBASE_SHELL="${HBASE} shell"

USER_HOME="/home/${SCRIPT_USER}"

SVN_HOME="/home/${SCRIPT_USER}/svn"
if [ "x$SCRIPT_USER" == "xdw_order" ];then
	SVN_HOME="/home/dw/svn"
fi

TMP_DIR="/var/tmp/${SCRIPT_USER}"

db_temp="default"
db_name="default"
HDFS_DIR="/user/${SCRIPT_USER}/warehouse"
if [ "x$SCRIPT_USER" == "xdw" ] || [ "x$SCRIPT_USER" == "xdw_order" ] ||  [ "x$SCRIPT_USER" == "xdwtest" ] || [ "x$SCRIPT_USER" == "xdwtest_order" ];then
	HDFS_DIR="/hive"
	db_name="dw"
fi

maxDateTime="9999-12-31 23:59:59.999"

MYSQL="mysql -h $META_HOST --port=$META_PORT -u $META_USER -p$META_PAWD -D $META_DB -s"


#bi_exchange modify

MS="mysql -h $MS_HOST --port=$MS_PORT -u $MS_USER -p$MS_PAWD -D $MS_DB -s"


#PG 数据库modify
export PGPASSWORD=d123w123
pgHost="10.40.188.102"
pgUser="dw"
pgDb="dw"
#→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→
#检查的对比时间点
checkHourThresholdHive=8

#休眠分钟
sleepMinuteHive="1m"
#→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→

#执行任务时日期,以下变量值不变，永远为今天
v_time=`date "+%Y-%m-%d %H:%M:%S"`

v_date=`date --date="$v_time" +%Y%m%d`
v_date_dir=`date --date="$v_time" +%Y/%m/%d`
v_date_hor=`date --date="$v_time" +%Y-%m-%d`

v_date_yes=`date --date="$v_time1 day ago" +%Y%m%d`
v_date_yes_dir=`date --date="$v_time1 day ago" +%Y/%m/%d`
v_date_yes_hor=`date --date="$v_time1 day ago" +%Y-%m-%d`

v_date_hour=`date --date="$v_time" +%H`
v_date_hour_1=`date --date="$v_time1 1 hour ago" +%H`
v_date_hour_2=`date --date="$v_time1 2 hour ago" +%H`

v_date_minute=`date --date="$v_time" +%M`

v_dm5_date=`date --date='5 minute ago' +%Y%m%d`
v_dm5_hour=`date --date='5 minute ago' +%H`

v_date_last_hour=$(date --date="40 minute ago" +%Y%m%d)
v_date_last_hour_hor=$(date --date="40 minute ago" +%Y-%m-%d)

#上一个5分钟，如现在56分，则值为50
v_dm5_minute_cj=`expr $v_date_minute % 5 + 5`
v_dm5_minute=`date --date="$v_time $v_dm5_minute_cj minute ago" +%M`

#上一个10分钟，如现在56分，则值为45
v_dm10_minute_cj=`expr $v_date_minute % 5 + 10`
v_dm10_minute=`date --date="$v_time $v_dm10_minute_cj minute ago" +%M`

v_dm10_hour=`date --date='10 minute ago' +%H`

#当前时间，毫秒置为0
currentTimestamp=$(date "+%Y-%m-%d %H:%M:%S.000")
#→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→↓↓↓↓↓↓以下为函数定义

#检测是否包含自定义参数
function f_getarg()
{
	date=$1

	current_day=`date --date="$date 1 day" +%d`
	current_date=`date --date="$date 1 day" +%Y%m%d`
	current_date_dir=`date --date="$date 1 day" +%Y/%m/%d`
	current_date_hor=`date --date="$date 1 day" +%Y-%m-%d`
	current_hor_3m=`date --date="$date 3 months ago" +%Y-%m-%d`
    current_month_short=`date --date="$date 1 day" +%Y%m`
	day_of_year=`date --date=$date +%j`

	date_future_1=`date --date="$date 1 day" +%Y%m%d`
	date_future_2=`date --date="$date 2 day" +%Y%m%d`
	date_future_3=`date --date="$date 3 day" +%Y%m%d`
	date_future_4=`date --date="$date 4 day" +%Y%m%d`
	date_future_5=`date --date="$date 5 day" +%Y%m%d`
	date_future_6=`date --date="$date 6 day" +%Y%m%d`
	date_future_7=`date --date="$date 7 day" +%Y%m%d`
    date_future_60=`date --date="$date 2 months" +%Y%m%d`

	date_future_hor_1=`date --date="$date 1 day" +%Y-%m-%d`
	date_future_hor_2=`date --date="$date 2 day" +%Y-%m-%d`
	date_future_hor_3=`date --date="$date 3 day" +%Y-%m-%d`
	date_future_hor_4=`date --date="$date 4 day" +%Y-%m-%d`
	date_future_hor_5=`date --date="$date 5 day" +%Y-%m-%d`
	date_future_hor_6=`date --date="$date 6 day" +%Y-%m-%d`
	date_future_hor_7=`date --date="$date 7 day" +%Y-%m-%d`
	date_future_hor_14=`date --date="$date 14 day" +%Y-%m-%d`
	date_future_hor_30=`date --date="$date 1 months" +%Y-%m-%d`
	date_future_hor_90=`date --date="$date 3 months" +%Y-%m-%d`
	date_future_hor_180=`date --date="$date 6 months" +%Y-%m-%d`
	date_future_hor_365=`date --date="$date 1 years" +%Y-%m-%d`

	date_1=`date --date="$date 1 day ago" +%Y%m%d`
	date_2=`date --date="$date 2 day ago" +%Y%m%d`
	date_3=`date --date="$date 3 day ago" +%Y%m%d`
	date_4=`date --date="$date 4 day ago" +%Y%m%d`
	date_5=`date --date="$date 5 day ago" +%Y%m%d`
	date_6=`date --date="$date 6 day ago" +%Y%m%d`
	date_7=`date --date="$date 7 day ago" +%Y%m%d`
	date_14=`date --date="$date 14 day ago" +%Y%m%d`
	date_30=`date --date="$date 1 months ago" +%Y%m%d`
	date_90=`date --date="$date 3 months ago" +%Y%m%d`
	date_180=`date --date="$date 6 months ago" +%Y%m%d`
	date_365=`date --date="$date 12 months ago" +%Y%m%d`

	date_hor=`date --date=$date +%Y-%m-%d`
	date_hor_1_=`date --date=$date +%Y%m%d`
	date_hor_1=`date --date="$date 1 day ago" +%Y-%m-%d`
	date_hor_2=`date --date="$date 2 day ago" +%Y-%m-%d`
	date_hor_3=`date --date="$date 3 day ago" +%Y-%m-%d`
	date_hor_4=`date --date="$date 4 day ago" +%Y-%m-%d`
	date_hor_5=`date --date="$date 5 day ago" +%Y-%m-%d`
	date_hor_6=`date --date="$date 6 day ago" +%Y-%m-%d`
	date_hor_7=`date --date="$date 7 day ago" +%Y-%m-%d`
	date_hor_14=`date --date="$date 14 day ago" +%Y-%m-%d`
	date_hor_30=`date --date="$date 1 months ago" +%Y-%m-%d`
	date_hor_3m=`date --date="$date 3 months ago" +%Y-%m-%d`
	date_hor_6m=`date --date="$date 6 months ago" +%Y-%m-%d`
	date_hor_9m=`date --date="$date 9 months ago" +%Y-%m-%d`
	date_hor_1y=`date --date="$date 12 months ago" +%Y-%m-%d`

	date_dir=`date --date=$date +%Y/%m/%d`
	date_dir_1=`date --date="$date 1 day ago" +%Y/%m/%d`
	date_dir_2=`date --date="$date 2 day ago" +%Y/%m/%d`
	date_dir_3=`date --date="$date 3 day ago" +%Y/%m/%d`
	date_dir_4=`date --date="$date 4 day ago" +%Y/%m/%d`
	date_dir_5=`date --date="$date 5 day ago" +%Y/%m/%d`
	date_dir_6=`date --date="$date 6 day ago" +%Y/%m/%d`
	date_dir_7=`date --date="$date 7 day ago" +%Y/%m/%d`
	date_dir_14=`date --date="$date 14 day ago" +%Y/%m/%d`
	date_dir_30=`date --date="$date 1 months ago" +%Y/%m/%d`

#周相关
    whichday=`date -d $date +%w`
	if [ $whichday -eq 0 ]; then
		whichday=7
	fi
    mon_date=`date -d "$date -$[${whichday}-1] days" +%Y%m%d`
    tue_date=`date -d "$mon_date+1 days" +%Y%m%d`
    wed_date=`date -d "$mon_date+2 days" +%Y%m%d`
	thu_date=`date -d "$mon_date+3 days" +%Y%m%d`
	fri_date=`date -d "$mon_date+4 days" +%Y%m%d`
	sat_date=`date -d "$mon_date+5 days" +%Y%m%d`
	sun_date=`date -d "$mon_date+6 days" +%Y%m%d`

	mon_date_hor=`date -d "$date -$[${whichday}-1] days" +%Y-%m-%d`
    tue_date_hor=`date -d "$mon_date+1 days" +%Y-%m-%d`
    wed_date_hor=`date -d "$mon_date+2 days" +%Y-%m-%d`
	thu_date_hor=`date -d "$mon_date+3 days" +%Y-%m-%d`
	fri_date_hor=`date -d "$mon_date+4 days" +%Y-%m-%d`
	sat_date_hor=`date -d "$mon_date+5 days" +%Y-%m-%d`
	sun_date_hor=`date -d "$mon_date+6 days" +%Y-%m-%d`

	#周汇总的时候 上周日汇总不到
    real_mon_date=`date -d "$date -$[${whichday}-1] days" +%Y%m%d`
    real_sun_date=`date -d "$mon_date+6 days" +%Y%m%d`
 
    real_mon_date_hor=`date -d "$date -$[${whichday}-1] days" +%Y-%m-%d`
    real_sun_date_hor=`date -d "$mon_date+6 days" +%Y-%m-%d`

	#如果date是周日 则将real_mon_date改为下周一
    if [ $whichday -eq 7 ]; then
        real_mon_date=`date --date="$date+1 days" +%Y%m%d`
        real_sun_date=`date --date="$date+7 days" +%Y%m%d`
		real_mon_date_hor=`date --date="$date+1 days" +%Y-%m-%d`
        real_sun_date_hor=`date --date="$date+7 days" +%Y-%m-%d`
    fi
	

#下面这些变量服务于月报，只有每月一号的时候，这些变量才有意义
#有的月份可能不到31天，但是过滤分区的时候，不影响数据及语法
	date_m_01=`date --date=$date +%Y%m`01
	date_m_02=`date --date=$date +%Y%m`02
	date_m_03=`date --date=$date +%Y%m`03
	date_m_04=`date --date=$date +%Y%m`04
	date_m_05=`date --date=$date +%Y%m`05
	date_m_06=`date --date=$date +%Y%m`06
	date_m_07=`date --date=$date +%Y%m`07
	date_m_08=`date --date=$date +%Y%m`08
	date_m_09=`date --date=$date +%Y%m`09
	date_m_10=`date --date=$date +%Y%m`10
	date_m_11=`date --date=$date +%Y%m`11
	date_m_12=`date --date=$date +%Y%m`12
	date_m_13=`date --date=$date +%Y%m`13
	date_m_14=`date --date=$date +%Y%m`14
	date_m_15=`date --date=$date +%Y%m`15
	date_m_16=`date --date=$date +%Y%m`16
	date_m_17=`date --date=$date +%Y%m`17
	date_m_18=`date --date=$date +%Y%m`18
	date_m_19=`date --date=$date +%Y%m`19
	date_m_20=`date --date=$date +%Y%m`20
	date_m_21=`date --date=$date +%Y%m`21
	date_m_22=`date --date=$date +%Y%m`22
	date_m_23=`date --date=$date +%Y%m`23
	date_m_24=`date --date=$date +%Y%m`24
	date_m_25=`date --date=$date +%Y%m`25
	date_m_26=`date --date=$date +%Y%m`26
	date_m_27=`date --date=$date +%Y%m`27
	date_m_28=`date --date=$date +%Y%m`28
	date_m_29=`date --date=$date +%Y%m`29
	date_m_30=`date --date=$date +%Y%m`30
	date_m_31=`date --date=$date +%Y%m`31

	date_m_01_hor=`date --date=$date +%Y-%m-`01
	month_next_start_2=`date --date="$date_m_01_hor 1 months" +%Y%m`01 
    date_m_31_hor=`date -d "$month_next_start_2 1 day ago" +%Y-%m-%d`
	
	month_start=`date --date=$date +%Y%m`01
	month_start_1=`date --date="$month_start 1 months ago" +%Y%m`01
	month_start_2=`date --date="$month_start 2 months ago" +%Y%m`01
	month_start_3=`date --date="$month_start 3 months ago" +%Y%m`01
	month_start_4=`date --date="$month_start 4 months ago" +%Y%m`01
	month_start_5=`date --date="$month_start 5 months ago" +%Y%m`01
	month_start_6=`date --date="$month_start 6 months ago" +%Y%m`01
	month_start_9=`date --date="$month_start 9 months ago" +%Y%m`01
	month_start_12=`date --date="$month_start 12 months ago" +%Y%m`01

	month_next_start_1=`date --date="$month_start 1 months" +%Y%m`01

	month_1=`date --date="$month_start 1 months ago" +%Y%m%d`
	month_2=`date --date="$month_start 2 months ago" +%Y%m%d`
	month_3=`date --date="$month_start 3 months ago" +%Y%m%d`
	month_4=`date --date="$month_start 4 months ago" +%Y%m%d`
	month_5=`date --date="$month_start 5 months ago" +%Y%m%d`
	month_6=`date --date="$month_start 6 months ago" +%Y%m%d`
	month_9=`date --date="$month_start 9 months ago" +%Y%m%d`
	month_12=`date --date="$month_start 12 months ago" +%Y%m%d`

	month_short=`date --date=$date +%Y%m`
	month_short_1=`date --date="$month_start 1 months ago" +%Y%m`
	month_short_2=`date --date="$month_start 2 months ago" +%Y%m`
	month_short_3=`date --date="$month_start 3 months ago" +%Y%m`
	month_short_4=`date --date="$month_start 4 months ago" +%Y%m`
	month_short_5=`date --date="$month_start 5 months ago" +%Y%m`
	month_short_6=`date --date="$month_start 6 months ago" +%Y%m`
	month_short_9=`date --date="$month_start 9 months ago" +%Y%m`
	month_short_12=`date --date="$month_start 12 months ago" +%Y%m`

	month_num=$(date --date=$date +%m)
	month_num_1=$(date --date="$month_start 1 months ago" +%m)
	month_num_2=$(date --date="$month_start 2 months ago" +%m)
	month_num_3=$(date --date="$month_start 3 months ago" +%m)
	month_num_4=$(date --date="$month_start 4 months ago" +%m)
	month_num_5=$(date --date="$month_start 5 months ago" +%m)
	month_num_6=$(date --date="$month_start 6 months ago" +%m)
	month_num_9=$(date --date="$month_start 9 months ago" +%m)
	month_num_12=$(date --date="$month_start 12 months ago" +%m)

	month_hor_1=`date --date="$month_start 1 months ago" +%Y-%m-%d`
	month_hor_2=`date --date="$month_start 2 months ago" +%Y-%m-%d`
	month_hor_3=`date --date="$month_start 3 months ago" +%Y-%m-%d`
	month_hor_4=`date --date="$month_start 4 months ago" +%Y-%m-%d`
	month_hor_5=`date --date="$month_start 5 months ago" +%Y-%m-%d`
	month_hor_6=`date --date="$month_start 6 months ago" +%Y-%m-%d`
	month_hor_9=`date --date="$month_start 9 months ago" +%Y-%m-%d`
	month_hor_12=`date --date="$month_start 12 months ago" +%Y-%m-%d`

	month_hor_short=`date --date=$date +%Y-%m`
	month_hor_short_1=`date --date="$month_start 1 months ago" +%Y-%m`
	month_hor_short_2=`date --date="$month_start 2 months ago" +%Y-%m`
	month_hor_short_3=`date --date="$month_start 3 months ago" +%Y-%m`
	month_hor_short_4=`date --date="$month_start 4 months ago" +%Y-%m`
	month_hor_short_5=`date --date="$month_start 5 months ago" +%Y-%m`
	month_hor_short_6=`date --date="$month_start 6 months ago" +%Y-%m`
	month_hor_short_9=`date --date="$month_start 9 months ago" +%Y-%m`
	month_hor_short_12=`date --date="$month_start 12 months ago" +%Y-%m`
	month_hor_start=`date --date=$date +%Y-%m-`01
	month_hor_start_1=`date --date="$month_start 1 months ago" +%Y-%m-`01
	month_hor_start_2=`date --date="$month_start 2 months ago" +%Y-%m-`01
	month_hor_start_3=`date --date="$month_start 3 months ago" +%Y-%m-`01
	month_hor_start_4=`date --date="$month_start 4 months ago" +%Y-%m-`01
	month_hor_start_5=`date --date="$month_start 5 months ago" +%Y-%m-`01
	month_hor_start_6=`date --date="$month_start 6 months ago" +%Y-%m-`01
	month_hor_start_9=`date --date="$month_start 9 months ago" +%Y-%m-`01
	month_hor_start_12=`date --date="$month_start 12 months ago" +%Y-%m-`01

	month_dir_1=`date --date="$month_start 1 months ago" +%Y/%m/%d`
	month_dir_2=`date --date="$month_start 2 months ago" +%Y/%m/%d`
	month_dir_3=`date --date="$month_start 3 months ago" +%Y/%m/%d`
	month_dir_4=`date --date="$month_start 4 months ago" +%Y/%m/%d`
	month_dir_5=`date --date="$month_start 5 months ago" +%Y/%m/%d`
	month_dir_6=`date --date="$month_start 6 months ago" +%Y/%m/%d`
	month_dir_9=`date --date="$month_start 9 months ago" +%Y/%m/%d`
	month_dir_12=`date --date="$month_start 12 months ago" +%Y/%m/%d`
	month_dir_short=`date --date=$date +%Y/%m`
	month_dir_short_1=`date --date="$month_start 1 months ago" +%Y/%m`
	month_dir_short_2=`date --date="$month_start 2 months ago" +%Y/%m`
	month_dir_short_3=`date --date="$month_start 3 months ago" +%Y/%m`
	month_dir_short_4=`date --date="$month_start 4 months ago" +%Y/%m`
	month_dir_short_5=`date --date="$month_start 5 months ago" +%Y/%m`
	month_dir_short_6=`date --date="$month_start 6 months ago" +%Y/%m`
	month_dir_short_9=`date --date="$month_start 9 months ago" +%Y/%m`
	month_dir_short_12=`date --date="$month_start 12 months ago" +%Y/%m`
	month_dir_start=`date --date=$date +%Y/%m/`01
	month_dir_start_1=`date --date="$month_start 1 months ago" +%Y/%m/`01
	month_dir_start_2=`date --date="$month_start 2 months ago" +%Y/%m/`01
	month_dir_start_3=`date --date="$month_start 3 months ago" +%Y/%m/`01
	month_dir_start_4=`date --date="$month_start 4 months ago" +%Y/%m/`01
	month_dir_start_5=`date --date="$month_start 5 months ago" +%Y/%m/`01
	month_dir_start_6=`date --date="$month_start 6 months ago" +%Y/%m/`01
	month_dir_start_9=`date --date="$month_start 9 months ago" +%Y/%m/`01
	month_dir_start_12=`date --date="$month_start 12 months ago" +%Y/%m/`01

	#年：年（4位）、当年1月1号
	year=$(date --date=$date +%Y)
	year_start=$(date --date=$date +%Y)0101

	#年：明年（4位）、明年1月1号
	year_next_1=$(date --date="${year}1231 1 day" +%Y)
	year_next_start_1=$(date --date="${year}1231 1 day" +%Y)0101

	#年：上一年（4位）、上一年1月1号
	year_1=$(date --date="${year}0101 1 day ago" +%Y)
	year_1_strat=$(date --date="${year}0101 1 day ago" +%Y)

	#年：上一年今天、上两年今天、上三年今天
	year_1_ago=`date --date="$date 1 years ago" +%Y%m%d`
	year_2_ago=`date --date="$date 2 years ago" +%Y%m%d`
	year_3_ago=`date --date="$date 3 years ago" +%Y%m%d`

	#季度
	if [ "$month_num" == "01" ] || [ "$month_num" == "02" ] || [ "$month_num" == "03" ];then
		quarter_num="Q1"
		quarter_start="${year}0101"
		quarter_hor_start="${year}-01-01"
		quarter_dir_start="${year}/01/01"
		quarter_next_start_1="${year}0401"
		quarter_next_hor_start_1="${year}-04-01"
		quarter_next_dir_start_1="${year}/04/01"
	elif [ "$month_num" == "04" ] || [ "$month_num" == "05" ] || [ "$month_num" == "06" ];then
		quarter_num="Q2"
		quarter_start="${year}0401"
		quarter_hor_start="${year}-04-01"
		quarter_dir_start="${year}/04/01"
		quarter_next_start_1="${year}0701"
		quarter_next_hor_start_1="${year}-07-01"
		quarter_next_dir_start_1="${year}/07/01"
	elif [ "$month_num" == "07" ] || [ "$month_num" == "08" ] || [ "$month_num" == "09" ];then
		quarter_num="Q3"
		quarter_start="${year}0701"
		quarter_hor_start="${year}-07-01"
		quarter_dir_start="${year}/07/01"
		quarter_next_start_1="${year}1001"
		quarter_next_hor_start_1="${year}-10-01"
		quarter_next_dir_start_1="${year}/10/01"
	else
		quarter_num="Q4"
		quarter_start="${year}1001"
		quarter_hor_start="${year}-10-01"
		quarter_dir_start="${year}/10/01"
		quarter_next_start_1="${year_next_1}0101"
		quarter_next_hor_start_1="${year_next_1}-01-01"
		quarter_next_dir_start_1="${year_next_1}/01/01"
	fi

	#所在年的第一天是周几，0为周日，1为周一，以此类推
	week_year_start=`date --date=$year_start +%w`
	#一周的开始是周一，周一是1，周日是7
	week_start_name=7
	#所在年的第一周有几天
	week_first_length=$(expr $week_start_name - $week_year_start)
	#当天日期，和所在年的第一周的最后一天的日期间隔
	week_interval_day=$(expr $day_of_year + 6 - $week_first_length)
	#间隔的天数对7求余数
	week_interval_modulo=$(expr $week_interval_day % 7)
	#
	if [ "x$week_interval_modulo" == "x0" ]; then
		week_num=$(expr 1 + $week_interval_day / 7)
	else
		week_num=$(expr 1 + $week_interval_day / 7 + 1)
	fi
	week_num=$(expr 1 + $week_interval_day / 7)
	#如果小于10，则补齐两位
	if [ $week_num -lt 10 ]; then
		week_num="0$week_num"
	fi

	#当天日期，在所在第几周的第几天
	week_index=$(expr \( 7 + $day_of_year - $week_first_length \) % 7 )
	if [ $week_index -eq 0 ]; then
		week_index=7
	fi
	week_start=$(date --date="$date $(expr $week_index - 1) day ago" +%Y%m%d)
	week_end=$(date --date="$date $(expr 7 - $week_index) day" +%Y%m%d)
	week_start_hor=$(date --date="$date $(expr $week_index - 1) day ago" +%Y-%m-%d)
	week_end_hor=$(date --date="$date $(expr 7 - $week_index) day" +%Y-%m-%d)
	#检测是否跨年
	week_start_year=`date --date=$week_start +%Y`
	week_end_year=`date --date=$week_end +%Y`
	if [ $year -ne $week_start_year ]; then
		week_start=${year}0101
	fi
	if [ $year -ne $week_end_year ]; then
		week_end=${year}1231
	fi

	#0代表周日，1代表周一，以此类推
	week=`date --date=$date +%w`
	week_1=`date --date="$date 1 day ago" +%w`
	week_2=`date --date="$date 2 day ago" +%w`
	week_3=`date --date="$date 3 day ago" +%w`
	week_4=`date --date="$date 4 day ago" +%w`
	week_5=`date --date="$date 5 day ago" +%w`
	week_6=`date --date="$date 6 day ago" +%w`
	week_7=`date --date="$date 7 day ago" +%w`

	#在所在年，是第几周，linux第一周是0
	week_year_1="10#`date --date="$date 1 day ago" +%W`"
	week_year_1=$((week_year_1+1))
	week_year_2="10#`date --date="$date 2 day ago" +%W`"
	week_year_2=$((week_year_2+1))
	week_year_3="10#`date --date="$date 3 day ago" +%W`"
	week_year_3=$((week_year_3+1))
	week_year_4="10#`date --date="$date 4 day ago" +%W`"
	week_year_4=$((week_year_4+1))
	week_year_5="10#`date --date="$date 5 day ago" +%W`"
	week_year_5=$((week_year_5+1))
	week_year_6="10#`date --date="$date 6 day ago" +%W`"
	week_year_6=$((week_year_6+1))
	week_year_7="10#`date --date="$date 7 day ago" +%W`"
	week_year_7=$((week_year_7+1))
}

function process_start()
{
	write_log "代码开始执行。"
	write_log "[INFO] 日志文件::$LOG_FILE"
	write_log "[INFO] 业务日期::$date"
	filesdtetime=$(date +%s)
}

function process_end()
{
	fileedtetime=$(date +%s)
	fileelapsedmin=$(expr \( $fileedtetime - $filesdtetime \) / 60)
	fileelapsedsec=$(expr \( $fileedtetime - $filesdtetime \) % 60)
	write_log ""
	write_log "执行总时长： ${fileelapsedmin} 分 ${fileelapsedsec} 秒"
	write_log "代码执行结束。"
	exit 0
}

#→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→

#检查是否月初
#月的：dt>=${month_start} and dt<=${date}
check_month_begaining()
{
	write_log "执行函数 ${FUNCNAME}"
	write_log "检查是否月初"

	if [ "${current_day}" != "01" ];then
		write_log "非月初，不运行月表！"
		process_end
	else
		write_log "业务日期为月初，开始运行月表！"
	fi
}

#检查是否周初
#周的：dt>=${date_6} and dt<=${date}
check_week_begaining()
{
	write_log "执行函数 ${FUNCNAME}"
	write_log "检查是否周初"

	if [ "${week}" != "6" ];then
		write_log "非周初，不运行周表！"
		process_end
	else
		write_log "业务日期为周初，开始运行周表！"
	fi
}

#删除目录、文件
rm_file()
{
	file_path=$1
	file_type=$2
	f_name="rm_file"
	write_log "执行函数 ${FUNCNAME}"
	write_log "删除目录类型 ${file_type}"
	write_log "删除目录 ${file_path}"
	
	#如果目录为hdfs目录
	if [ "x${file_type}" == "xhdfs" ];then
		#检查文件是否存在
		hdfs dfs -test -e ${file_path}
		if [ $? -eq 0 ];then
			hdfs dfs -rm -r ${file_path}
			if [ $? -ne 0 ];then
				write_log "删除文件错误！" "red"
			exit 255
			fi
		else
			write_log "文件不存在，无需删除！"
		fi
	else
		rm -rf ${file_path}
		if [ $? -ne 0 ];then
			write_log "删除文件错误！" "red"
			exit 255
		fi
	fi

	write_log "函数执行成功"
}

#创建目录
mkdir_file()
{
	file_path=$1
	file_type=$2
	write_log "执行函数 ${FUNCNAME}"
	write_log "创建目录类型 ${file_type}"
	write_log "创建目录 ${file_path}"

	#如果目录为hdfs目录
	if [ "x${file_type}" == "xhdfs" ];then
		#检查文件是否存在
		hdfs dfs -test -e ${file_path}
		if [ $? -eq 0 ];then
			#write_log "文件存在，请先删除！" "red"
			#exit 255
			write_log "注意：文件或目录存在！"
		else
			hdfs dfs -mkdir -p ${file_path}
			if [ $? -ne 0 ];then
				write_log "创建目录错误！" "red"
				exit 255
			fi
		fi
	else
		if [ -d "${file_path}" ];then
			write_log "文件存在，请先删除！" "red"
		else
			mkdir -p ${file_path}
			if [ $? -ne 0 ];then
				write_log "创建目录错误！" "red"
				exit 255
			fi
		fi
	fi

	write_log "函数执行成功"
}

#复制目录
cp_file()
{
	file_src=$1
	file_trg=$2
	file_type=$3
	write_log "执行函数 ${FUNCNAME}"
	write_log "复制源 ${file_src}"
	write_log "复制目的 ${file_trg}"
	write_log "复制目录类型 ${file_type}"
	
	#如果源目录为hdfs目录
	if [ "x${file_type}" == "xhdfs" ];then
		#检查源目录是否存在
		hdfs dfs -test -e ${file_src}
		if [ $? -ne 0 ];then
			write_log "源目录不存在！" "red"
			exit 255
		fi

		#检查目的目录是否存在
		#hdfs dfs -test -e ${file_trg}
		#if [ $? -ne 0 ];then
		#write_log "目的目录不存在！" "red"
		#exit 255
		#fi

		hdfs dfs -cp -r ${file_src} ${file_trg}
		if [ $? -ne 0 ];then
			write_log "复制目录错误！" "red"
			exit 255
		fi
	else
		if [ ! -e "${file_src}" ];then
			write_log "源目录不存在！" "red"
			exit 255
		fi

		#if [ ! -e "${file_trg}" ];then
		#write_log "目的目录不存在！" "red"
		#exit 255
		#fi

		hdfs dfs -put ${file_src} ${file_trg}
		if [ $? -ne 0 ];then
			write_log "复制目录错误！" "red"
			exit 255
		fi
	fi

	write_log "函数执行成功"
}

#异构数据库、文件系统数据移动
xdata()
{
	job_id=$1
	job_pars=$2
	f_name="xdata"
	write_log "执行函数 ${FUNCNAME}"
	if [ "x$job_id" = "x" ];then
		write_log "作业id不能为空，至少有一个参数!"
		exit 1
	fi
	
	write_log "作业:$job_id"
	
	job_args="$job_id"
	if [ "x$job_date" != "x" ];then
		write_log "日期:$job_date"
		job_args="${job_args} job_date=$job_date"
	fi

	if [ "x$job_hour" != "x" ];then
		write_log "小时:$job_hour"
		job_args="${job_args} job_hour=$job_hour"
	fi

	if [ "x$job_pars" != "x" ];then
		job_pars="${job_pars} -DHDFS_DIR=${HDFS_DIR}"
	else
		job_pars="-p-DHDFS_DIR=${HDFS_DIR}"
	fi
	write_log "变量:$job_pars"

	python /opt/datax/bin/datax.py $job_args "$job_pars" >> $LOG_FILE 2>&1
	if [ $? -ne 0 ];then
		write_log "出现错误！" "red"
		exit 2
	fi
	write_log "函数执行成功"
}

#循环执行 xdata 函数
for_xdata()
{
	idFx=$1
	dateFx=$2
	hourFx=$3
	typeFx=$4
	startFx=$5
	endFx=$6
	durFx=$7
	extFx=$8
	write_log "执行函数 ${FUNCNAME}"
	write_log "执行ID ${idFx}"
	write_log "执行日期 ${dateFx}"
	write_log "执行小时 ${hourFx}"
	write_log "执行类型 ${typeFx}"
	write_log "执行开始 ${startFx}"
	write_log "执行结束 ${endFx}"
	write_log "执行间隔 ${durFx}"
	write_log "扩展参数 ${extFx}"

	iFx=1
	curFx="$startFx"
	if [ "x$typeFx" == "xdate" ];then
		while [[ $curFx < $endFx ]];do
			curFx=$(date --date="${startFx} ${durFx} day" +%Y-%m-%d)
			if [ $curFx -ge $endFx ];then
				xdata "$idFx" "$dateFx" "$hourFx" "-p-Dstart=$startFx -Dend=$endFx -Di=$iFx $extFx"
			else
				xdata "$idFx" "$dateFx" "$hourFx" "-p-Dstart=$startFx -Dend=$curFx -Di=$iFx $extFx"
			fi

			startFx="$curFx"
			iFx=$[$iFx+1]
		done
	elif [ "x$typeFx" == "xnumber" ];then
		while [ $curFx -lt $endFx ];do
			curFx=$[ $startFx + $durFx ]
			if [ $curFx -ge $endFx ];then
				xdata "$idFx" "$dateFx" "$hourFx" "-p-Dstart=$startFx -Dend=$endFx -Di=$iFx $extFx"
			else
				xdata "$idFx" "$dateFx" "$hourFx" "-p-Dstart=$startFx -Dend=$curFx -Di=$iFx $extFx"
			fi

			startFx="$curFx"
			iFx=$[$iFx+1]
		done
	else
		write_log "类型参数错误！只允许'date'和'number'！" "red"
		exit 255
	fi
}

#为目录加lzo索引 modify
add_lzo_index()
{
	hdfs_path=$1
	f_name="add_lzo_index"
	write_log "执行函数 ${FUNCNAME}"
	write_log "加LZO索引HDFS目录 ${hdfs_path}"

	$YARN jar ${HADOOP_HOME}/share/hadoop/common/hadoop-lzo-0.4.20-SNAPSHOT.jar com.hadoop.compression.lzo.DistributedLzoIndexer ${hdfs_path} >> $LOG_FILE 2>&1
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi
	write_log "函数执行成功"
}

check_mark_sqlserver()
{
	f_tbl=$1
	f_date=$2
	f_wait_max=$3

	write_log "开始检查标记"
	write_log "标记表：CRM__MIDDLE.dbo.Hadoop_Mark"
	write_log "检查 Sqlserver 标记:${f_tbl}"
	write_log "检查业务日期:${f_date}"

	#最多等待多少次
	if [ "x$f_wait_max" == "x" ];then
		v_wait_max=192
	fi
	#每次等待几分钟
	v_wait_minute="5m"

	for((i=1;i<=${v_wait_max};i++));do
		write_log "第 ${i} 次检测"
		java -jar ${SVN_HOME}/init/job/jar/check_mark_sqlserver.jar "${f_tbl}" "${f_date}"
		f_status=$?
		if [ $f_status -ne 0 ]; then
			write_log "未检查到标记"
		else
			write_log "成功检查到标记"
			break
		fi

		sleep "${v_wait_minute}"
	done

	if [ $f_status -ne 0 ]; then
		write_log "到达最后一次检查，仍未检查到标记！" "red"
		exit 255
	fi

	write_log "函数执行成功"
}

write_mark_sqlserver()
{
	f_tbl=$1
	f_date=$2
	f_hour=$3

	write_log "插入标记，标记表：CRM__MIDDLE.dbo.Hadoop_Mark"
	write_log "插入 Sqlserver 标记:${f_tbl}"
	write_log "插入业务日期:${f_date}"

	java -jar ${SVN_HOME}/init/job/jar/write_mark_sqlserver.jar "${f_tbl}" "${f_date}" "${f_hour}"
	if [ $? -ne 0 ]; then
		write_log "插入SqlServer标记错误！"
		exit 101
	fi

	write_log "函数执行成功"
}

#获得 key 的值
get_mark_key()
{
	f_key=$1
	f_date=$2
	f_time=$3
	write_log "执行函数 ${FUNCNAME}"
	write_log "key:${f_key}"
	write_log "业务日期:${f_date}"
	write_log "业务时间:${f_time}"

	mark_value=$($MYSQL -e "SELECT value FROM mark WHERE \`key\`='${f_key}' AND date='${f_date}' AND time='${f_time}'")
	if [ $? -ne 0 ]; then
		write_log "获取 key 错误！"
		exit 255
	fi

	write_log "函数执行成功"
}

#设置 key 的值
set_mark_key()
{
	f_key=$1
	f_date=$2
	f_time=$3
	f_value=$4
	write_log "执行函数 ${FUNCNAME}"
	write_log "key:${f_key}"
	write_log "业务日期:${f_date}"
	write_log "业务时间:${f_time}"

	value=$($MYSQL -e "REPLACE INTO mark(\`key\`,date,time,value) VALUES('${f_key}','${f_date}','${f_time}','${f_value}')")
	if [ $? -ne 0 ]; then
		write_log "设置 key 错误！"
		exit 255
	fi

	write_log "函数执行成功"
}

check_scheduler_job_status()
{
	f_pn=$1
	f_fn=$2
	f_jn=$3
	f_ed=$4
	write_log "执行函数 ${FUNCNAME}"
	write_log "检查项目：${f_pn}"
	write_log "检查工作流：${f_fn}"
	write_log "检查作业：${f_jn}"
	write_log "检查日期：${f_ed}"

	#最多等待多少次
	v_wait_max=100
	#每次等待一分钟
	v_wait_minute="5m"

	for((i=1;i<=${v_wait_max};i++));do
		write_log "第 ${i} 次检测"
		java -jar ${USER_HOME}/jar/MonitorSchedulerJobStatus.jar "${f_pn}" "${f_fn}" "${f_jn}" "${f_ed}"
		if [ $? -ne 0 ]; then
			write_log "未检查到作业成功标志！"
		else
			write_log "成功检查到作业成功标志！"
			return
		fi

		sleep "${v_wait_minute}"
	done
	
	write_log "到达最后一次检查，仍未检查到作业成功标志！" "red"
	exit 255

	write_log "函数执行成功"
}

workflow_dependencies()
{
	f_date=$1
	f_project_wfs=$2
	f_name="workflow_dependencies"
	write_log "执行函数 ${FUNCNAME}"
	write_log "依赖的项目.工作流:${f_project_wfs}"
	
	#最多等待多少次
	v_wait_max=240
	#每次等待一分钟
	v_wait_minute="1m"

	#按照逗号拆分为数组
	arr_pwf=(${f_project_wfs//,/ })
	for v_pwf in ${arr_pwf[@]};do
		write_log "检测项目.工作流:${v_pwf}"
		for((i=1;i<=${v_wait_max};i++));do
			write_log "第 ${i} 次检测"
			
			sleep "${v_wait_minute}"
		done
	done

	write_log "函数执行成功"
}

jar_run()
{
	f_jar=$1
	f_cmd=$2
	f_bc=$3
	write_log "执行函数 ${FUNCNAME}"

	write_log "执行JAR包："
	write_log "${f_jar}"
	f_jarcmd="$f_jar"

	if [ "x$f_bc" != "x" ];then
		write_log "引入JAR包："
		write_log "${f_bc}"
		f_jarbc="-Xbootclasspath/a:$f_bc"
	fi

	if [ "x$f_cmd" != "x" ];then
		write_log "执行参数："
		write_log "${f_cmd}"
		f_jarcmd="$f_jarcmd $f_cmd"
	fi

	#write_log "开始执行："
	#write_log "java $f_jarbc -jar ${f_jarcmd}"
	java $f_jarbc -jar ${f_jarcmd} >> $LOG_FILE 2>&1
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi
	write_log "函数执行成功"
}

get_hive_value()
{
	f_sql=$1
	write_log "执行函数 ${FUNCNAME}"
	write_log "执行HIVE SQL:"
	write_log "${f_sql}"
	
	sdtetime=$(date +%s)
	hive_value=$($HIVE -S -hiveconf hive.cli.print.header=false -e "$f_sql") >> $LOG_FILE 2>&1
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi
	edtetime=$(date +%s)
	elapsed=$(expr \( $edtetime - $sdtetime \) / 60)
	write_log "执行时长： ${elapsed} 分钟"
	
	write_log "函数执行成功"
}

hive_txt()
{
	f_sql=$1
	write_log "执行函数 ${FUNCNAME}"
	write_log "执行HIVE SQL:"
	write_log "${f_sql}"

	#checkHiveExec

	sdtetime=$(date +%s)
	$HIVE -e "set mapreduce.job.name=${tablename};set tez.job.name=${tablename};set spark.app.name=${tablename};$f_sql" >> $LOG_FILE 2>&1
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi
	edtetime=$(date +%s)
	elapsed=$(expr \( $edtetime - $sdtetime \) / 60)
	write_log "执行时长： ${elapsed} 分钟"

	write_log "函数执行成功"
}
spark_sql_txt_gc()
{
        f_sql=$1
        num_executors=${2:-2} #默认启动10个executor
        write_log "执行函数 spark_sql_txt_gc"
        write_log "执行SPARK SQL:"
        write_log "${f_sql}"


        sdtetime=$(date +%s)
                spark-sql -e -v --num-executors 10 --executor-cores 4  --driver-memory 10G  --executor-memory 6G   --conf  spark.sql.adaptive.enabled=true --conf spark.driver.maxResultSize=2048M   --conf 'spark.driver.extraJavaOptions=-XX:+UseCompressedOops -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps' --conf 'spark.executor.extraJavaOptions=-XX:+UseCompressedOops -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintHeapAtGC  '  --name ${tablename} "$f_sql" >> $LOG_FILE 2>&1
        # sh /usr/local/model/run_spark_sql.sh "$f_sql" $num_executors ${tablename} $LOG_FILE
        if [ $? -ne 0 ]; then
                write_log "出现错误！" "red"
                exit 3
        fi
        edtetime=$(date +%s)
        elapsed=$(expr \( $edtetime - $sdtetime \) / 60)
        write_log "执行时长： ${elapsed} 分钟"

        write_log "函数执行成功"
}

# modify
spark_sql_txt()
{
        f_sql=$1
        num_executors=${2:-2} #默认启动10个executor
        write_log "执行函数 ${FUNCNAME}"
        write_log "执行SPARK SQL:"
        write_log "${f_sql}"


        sdtetime=$(date +%s)
		spark-sql -e -v --num-executors $num_executors --driver-memory 4g --executor-memory 2G --executor-cores 2 --conf spark.sql.shuffle.partitions=50  --conf spark.sql.adaptive.enabled=true --conf spark.driver.maxResultSize=2048M --conf spark.storage.memoryFraction=0.4  --conf spark.yarn.executor.memoryOverhead=1024M  --conf spark.yarn.driver.memoryOverhead=2048M --name ${tablename} "$f_sql" >> $LOG_FILE 2>&1
        # sh /usr/local/model/run_spark_sql.sh "$f_sql" $num_executors ${tablename} $LOG_FILE
        if [ $? -ne 0 ]; then
                write_log "出现错误！" "red"
                exit 3
        fi
        edtetime=$(date +%s)
        elapsed=$(expr \( $edtetime - $sdtetime \) / 60)
        write_log "执行时长： ${elapsed} 分钟"

        write_log "函数执行成功"
}

spark_sql_txt_mult()
{
        f_sql=$1
        num_executors=${2:-5} #默认启动5个executor
        write_log "执行函数 ${FUNCNAME}"
        write_log "执行SPARK SQL:"
        write_log "${f_sql}"


        sdtetime=$(date +%s)
		spark-sql -e -v --num-executors $num_executors --driver-memory 4g --conf spark.sql.adaptive.enabled=true --jars hdfs://znlhhdfs/jars/myudf.jar,hdfs://znlhhdfs/jars/lib/* --name ${tablename} "$f_sql" >> $LOG_FILE 2>&1
        # sh /usr/local/model/run_spark_sql.sh "$f_sql" $num_executors ${tablename} $LOG_FILE
        if [ $? -ne 0 ]; then
                write_log "出现错误！" "red"
                exit 3
        fi
        edtetime=$(date +%s)
        elapsed=$(expr \( $edtetime - $sdtetime \) / 60)
        write_log "执行时长： ${elapsed} 分钟"

        write_log "函数执行成功"
}

hive_lzo()
{
	f_sql=$1
	write_log "执行函数 ${FUNCNAME}"
	write_log "设置输出压缩为LZO格式"
	write_log "执行HIVE SQL:"
	write_log "${f_sql}"

	#checkHiveExec

	f_hive_conf=" -hiveconf hive.root.logger=INFO -hiveconf hive.exec.compress.output=true"
	f_hive_conf="${f_hive_conf} -hiveconf mapred.output.compression.codec=com.hadoop.compression.lzo.LzopCodec "
	
	$HIVE -v ${f_hive_conf} -e "set mapreduce.job.name=${tablename};set tez.job.name=${tablename};$f_sql" >> $LOG_FILE 2>&1
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi

	write_log "函数执行成功"
}

# modify
hjar_run()
{
	f_hjar=$1
	f_hcmd=$2
	write_log "执行函数 ${FUNCNAME}"
	
	write_log "执行HADOOP JAR包："
	write_log "${f_hjar}"
	f_hjarcmd="$f_hjar"
	if [ "x$f_hcmd" != "x" ];then
		write_log "执行参数："
		write_log "${f_hcmd}"
		f_hjarcmd="$f_hjar -libjars=${HIVE_HOME}/auxlib/hive_udf.jar,${HIVE_HOME}/lib/hive-exec-${HIVE_VERSION}.jar,${HIVE_HOME}/lib/fastjson-1.1.32.jar $f_hcmd"
	fi

	sdtetime=$(date +%s)
	$YARN jar ${f_hjarcmd} >> $LOG_FILE 2>&1
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi
	edtetime=$(date +%s)
	elapsed=$(expr \( $edtetime - $sdtetime \) / 60)
	write_log "执行时长： ${elapsed} 分钟"

	write_log "函数执行成功"
}

hbase_exec()
{
	f_sql=$1
	write_log "执行函数 ${FUNCNAME}"
	write_log "执行HBASE SQL:"
	write_log "${f_sql}"

	hbase shell << EOF >> $LOG_FILE 2>&1
	${f_sql}
EOF
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi
	write_log "函数执行成功"
}

pg_exec()
{
	f_sql=$1
	f_mode=$2
	write_log "执行函数 ${FUNCNAME}"

	if [ -e $f_mode ];then
		f_mode=1
	fi
	write_log "执行PG SQL 模式（1，普通；2，结果集）: $f_mode"
	write_log "执行PG SQL:"
	write_log "${f_sql}"

	if [ $f_mode -eq 1 ];then
		psql -h $pgHost -U $pgUser -d $pgDb --command="$f_sql" >> $LOG_FILE 2>&1
		if [ $? -ne 0 ]; then
			write_log "执行PG SQL错误！" "red"
			exit 255
		fi
	elif [ $f_mode -eq 2 ];then
		pgresult=$(psql -h $pgHost -U $pgUser -d $pgDb -A -t --field-separator="	" --command="$f_sql")
		if [ $? -ne 0 ]; then
			write_log "出现错误！" "red"
			exit 255
		fi
	else
		write_log "模式错误！" "red"
		exit 255
	fi

	write_log "函数执行成功"
}

#检查提交作业的表是否满足执行SQL的集群资源条件
checkHiveExec()
{
	#提交时间（小时）
	currentHourHive=$(date +%H)
	if [ $currentHourHive -lt $checkHourThresholdHive ]
	then
		write_log "在紧缩时间内，开始检查优先级是否足够" "green"
		checkToRunHive="0"
		for((i=1;i<=100;i++))
		do
			checkToRunHive=$(curl -s http://hadoop.org:8080/ds/queue/hadoop/priority.htm?tablename=$tablename)
			if [ "x$checkToRunHive" != "x0" ];then
				#currentTimeHive=$(date "+%Y-%m-%d %H:%M:%S")
				write_log "状态 $checkToRunHive 休眠 $sleepMinuteHive" "yellow"
				sleep ${sleepMinuteHive}
			else
				i=101
			fi
		done
		
		if [ "x$checkToRunHive" == "x0" ];then
			write_log "满足条件，开始执行 SQL" "green"
		else
			write_log "超时退出！超过最大休眠时间！" "red"
			exit 255
		fi
	else
		write_log "允许提交 SQL" "green"
	fi
}

# 2016-09-28 资源调度长占
submit_schedulor()
{
	java -cp /usr/local/lib/SchedulorRealTime.jar com.bi.schedulor.client.Client 10.40.188.116 8800 "$1"
	if [ $? -ne 0 ];then
		write_log "出现错误！" "red"
	    exit 1
	fi
}

#2016-11-11
#查询配置表，根据配置表配置信息执行校验，若校验失败将发送短信至配置表中负责人

do_data_check()
{
        write_log "执行函数 ${FUNCNAME}"
        #检查入参个数
        if [ $# -lt 2 ];
        then
                write_log "必须输入日期和需校验表名！" "red"
                exit 3
        fi

        date=$1
        table=$2
        write_log "表名：${table}"
        write_log "日期：${date}"

        sdtetime=$(date +%s)
        #查询配置表SQL
        query_conf_sql="use ${db_name};
                        select concat(min, '#', 
                                      max, '#', 
                                      sql, '#', 
                                      phones, '#', 
                                      remark, '#', 
                                      nvl(send_hour, "-1"), '#', 
                                      phone_group)
                                 from ods_conf_data_monitor
                                where table = '$table'"

        while read line
        do
                #最小阈值
                min=`echo $line | cut -d'#' -f1`
                #最大阈值
                max=`echo $line | cut -d'#' -f2`
                #校验SQL, 不能出现#与换行符
                sql=`echo ${line} | cut -d'#' -f3`
                #替换${date}为输入日期
                sql_rep_date=${sql/$\{date\}/$date}
                #负责人手机号列表，多个号码时需以英文逗号分隔。如13813867128,13813912123
                phones=`echo $line | cut -d'#' -f4`
                #校验失败发送短信内容
                remark=`echo $line | cut -d'#' -f5`
                
                #发送小时
                send_hour=`echo $line | cut -d'#' -f6`
                
                is_right_hour=`echo $send_hour | grep "[0-2][0-9]" | wc -l`
                if [ "$is_right_hour" -eq "1" ];
                then
                	  send_time="$(date +%Y-%m-%d) $send_hour:00:00"
                else
                    #立刻发送短信
                    send_hour="-1"
                fi

                #电话组
                phone_group=`echo $line | cut -d'#' -f7`
                result=$($HIVE -S -hiveconf hive.cli.print.header=false -e "$sql_rep_date")

                if [ $? -ne 0 ];
                then
                        write_log "$remark校验失败！原因：校验SQL配置有误" "red"
                        sendSmss $phones "数据校验失败警告：$table，原因：校验SQL配置有误。备注：$remark" >> $LOG_FILE 2>&1
                        exit 3
                fi

                #检查校验结果是否在阀值内
                if [ $(echo "$result <= $max"|bc) -eq 1 -a $(echo "$result >= $min"|bc) -eq 1 ];
                then
                        write_log "$remark校验成功！最小阀值：$min，最大阀值：$max，校验结果：$result"
                else
                        #如果不在阀值内，则插入数据到短信配置表
                        write_log "$remark校验失败！最小阀值：$min，最大阀值：$max，校验结果：$result" "red"
                        warn_msg="数据校验失败警告：$table，原因：超出预设阀值。最小阀值：$min，最大阀值：$max，校验结果：$result。备注：$remark"
                        if [ "$send_hour" == "-1" ];
                        then
                        	   sendSmss $phones $warn_msg >> $LOG_FILE 2>&1
                        else
                             insert_conf_sql="use ${db_name};
                                              insert overwrite table ol_sms_data_monitor
                                              partition(dt='${date}', table = '$table')
                                              select '$warn_msg',
                                                     '$send_time',
                                                     '$phone_group',
                                                     from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')
                                                from dual"
                             $HIVE -S -hiveconf hive.cli.print.header=false -e "$insert_conf_sql"
                             xdata "ol_sms_data_monitor" "" "" "-p-Ddate=$date -Dtable=$table"
                        fi
                        exit 3
                fi
        done <<< "$($HIVE -S -hiveconf hive.cli.print.header=false -e "$query_conf_sql")"
        write_log "函数${FUNCNAME}执行成功"
}

#发送邮件
sendEmails()
{
	f_to=$1
	f_subject=$2
	f_content=$3
	f_file=$4
	write_log "执行函数 ${FUNCNAME}"
	write_log "收件人：${f_to}"
	write_log "主题：${f_subject}"
	write_log "正文：${f_content}"
	write_log "附件：${f_file}"

	sendEmail -xu bi.services -xp g_bi_serve -f "dw<bi.services.com>" -t "${f_to}" -s mail.com -u "${f_subject}"  -m "${f_content}" -a ${f_file}
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi
	write_log "函数执行成功"
}

#发送短信 modify
sendSmss()
{
	f_phones=$1
	f_content=$2
	write_log "执行函数 ${FUNCNAME}"
	write_log "收件人：${f_phones}"
	write_log "正文：${f_content}"

	curl -X POST -H "content-type: application/x-www-form-urlencoded;charset=UTF-8" --data "{\"templateId\":1461,\"mobileNum\":[\"${f_phones}\"],\"clientIp\":\"10.40.188.116\",\"systemId\":1038,\"smsTemplateParams\":[{\"paramKey\":\"content\",\"paramValue\":\"${f_content}\"}]}"  "http://public-api.nj.pla.org/sms-web/sms/send"
	if [ $? -ne 0 ]; then
		write_log "出现错误！" "red"
		exit 3
	fi
	write_log "函数执行成功"
}

updateProject()
{
	projectName=$1
	write_log "执行函数 ${FUNCNAME}"
	write_log "更新工程 ${projectName}"	
	out=`curl --insecure "https://10.40.188.123:8443/manager?project=${projectName}&updateProject&user=dw&token=1234567890"`
	echo $out
	if [ ! "x$out" == "x" ];then
		write_log "出现错误！" "red"
		exit 3
	fi
	write_log "函数执行成功"
}

#→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→→↑↑↑↑↑↑函数定义结束

#如果没有传入参数，则为变量${date}赋值为昨天，如果传入了，则把第一个参数值赋值给变量${date}
if [ "x$1" != "x" ]
then
	date --date=$1 +%F > /dev/null
	if [ $? -ne 0 ]; then
		write_log "错误：第一个参数必须是8位数字的日期!" "red"
		exit 254
	fi
	#第一个参数:以1或2开头、后面为7个数字、不包含非数字字符
	date=`echo $1 | grep '^[12]\{1\}[0-9]\{7\}$' | grep '^[1-9]'`
	if [ "x$date" == "x" ];then
		write_log "错误：第一个参数必须是8位数字的日期!" "red"
		exit 254
	fi
else
	date=`date --date='1 day ago' +%Y%m%d`
fi
#如果没有传入参数，则为变量${hour}赋值为上一小时，如果传入了，则把第二个参数值赋值给变量${hour}
if [ "x$2" != "x" ]
then
	hour="$2"
else
	hour=`date --date='1 hour ago' +%H`
        if [ "23" == ${hour} ]
        then
             date=`date --date='2 day ago' +%Y%m%d`
        fi
fi

#根据变量${date}处理其他变量
f_getarg $date

write_log "父进程ID: $PPID"
write_log "进程ID:   $BASHPID"
