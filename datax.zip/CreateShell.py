import sys
from utils.CreateShellsUtils  import CreateShellsUtils
if __name__ == '__main__':
    if(len(sys.argv) != 4 and len(sys.argv) != 5):
        print("请输入正确个数的参数！")
        sys.exit(1)

    cfg = sys.argv[1] #配置数据源
    funType = sys.argv[2]
    csu = CreateShellsUtils(cfg)
    if funType == 'db':
        db = sys.argv[3]
        csu.createDataxShellForDB(db)
    elif funType == 'table':
        db = sys.argv[3]
        table = sys.argv[4]
        csu.createDataxShellForTable(db,table)
    else:
        print("请输入正确参数！")
        sys.exit(1)