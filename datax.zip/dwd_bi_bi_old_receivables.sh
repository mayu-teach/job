#!/bin/sh
source /home/dw/.hive_config.sh

###@job name: dwd_bi_bi_old_receivables
###@author:mayu
###@modify:
###@Create Date:2019-10-12
###@Modefy Date:2019-10-12
###@Description:zms老应收
###@Target: dwd_bi_bi_old_receivables
###@Source: 
###@Processing step: 
###1.统一字段
###2.
###3.



#################################################################
process_start
##################################################################

write_cgr "模块一"
write_log "zms老应收"
sql_1="
insert overwrite table
dwd.dwd_bi_bi_old_receivables partition (dt='${date}')
select
    bor.sum_date,
    dep.dept_name ,
    o.create_name ,
    o.payer_name ,
    awp.project_name ,
    bor.order_id ,
    case
        when o.law_status = 0 then '非法务'
        when o.law_status = 1 then '协催'
        else '转法'
    end as law_status,
    bor.dev_enter_id ,
    '#' ,
    bor.balance_type_name ,
    bor.settlement_scope_name ,
    bor.payment_ratio ,
    '#' ,
    '#' ,
    bor.dev_id ,
    bor.rec_rent_sum ,
    bor.rec_freight_sum ,
    bor.rec_claim_sum ,
    bor.rec_increase_sum ,
    bor.rec_decrease_sum ,
    bor.rec_all_sum ,
    bor.money_in_claim ,
    bor.money_in_rent ,
    bor.money_in_freight ,
    bor.money_sum ,
    bor.coupon_in_claim ,
    bor.coupon_in_rent ,
    bor.coupon_in_freight ,
    bor.coupon_sum ,
    bor.rent_integral ,
    bor.freight_integral ,
    bor.claim_integral ,
    bor.integral_sum ,
 bor.refund_out_rent ,
    bor.refund_out_freight ,
    bor.refund_out_claim ,
    bor.refund_sum ,
    bor.remain_claim_sum ,
    bor.remain_rent_sum ,
    bor.remain_freight_sum ,
    bor.remain_all_sum ,
    bor.overdue_in_thirty_sum ,
    bor.overdue_btn_sixty_sum ,
    bor.overdue_btn_ninety_sum ,
    bor.overdue_byd_ninety_sum ,
    bor.unearned_all_sum ,
    enm.rent_date ,
    exm.exit_rent_date,
    tttt.rk,
    from_unixtime(unix_timestamp(),'YYYY-MM-dd HH:mm:ss') as etl_time
from
    ods.bi_bi_order_dev_receivable_sum_exit bor
left join ods.vip_oms_order o on
    o.order_code = bor.order_id
left join ods.vip_vip_department dep on
    dep.dept_code = bor.city_id
left join ods.vip_oms_order_awp awp on
    awp.order_code = bor.order_id
left join ods.vip_ser_order_dev_relation re on
    bor.dev_enter_id = re.dev_enter_code
    and bor.dev_id = re.dev_code
left join ods.vip_ser_dev_enter_match enm on
    re.dev_enter_code = enm.dev_enter_code
    and re.dev_code = enm.dev_code
left join ods.vip_ser_dev_exit_match exm on
    re.dev_exit_code = exm.dev_exit_code
    and re.dev_code = exm.dev_code
left join (
    select
        t.dev_code,
        t.order_code,
        t.dev_enter_code,
        concat_ws(',',
        collect_set(t.rk)) as rk
    from
        (
        select
            d.dev_code,
            s.order_code,
            d.dev_enter_code,
            concat( d.stop_begin_time,
            '#',
            d.open_begin_time ) as rk
        from
            ods.vip_ser_dev_stop_dev d
        left join ods.vip_ser_dev_stop s on
            d.stop_code = s.stop_code
        where
            d.STATUS = 3
            and s.status in ( 20,
            30 )
            and s.del_flag = 0) t
    group by
        t.dev_code,
        t.order_code,
        t.dev_enter_code) tttt on
    tttt.dev_code = bor.dev_id
    and tttt.dev_enter_code = bor.dev_enter_id
    and tttt.order_code = bor.order_id
where
    date_format(bor.sum_date,'yyyyMMdd') = '${date}'
    and bor.city_id != 'DEP1804000084'
;
"
spark_sql_txt "$sql_1" 

###################################################################
process_end
###################################################################