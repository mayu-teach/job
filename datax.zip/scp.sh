#########################################################################################################
#功能描述：scp到指定主机
#执行方式: sh scp.sh vip ods_vip_vip_user
#开发时间：2019-10-09
#开发人员：lisubo
#########################################################################################################
#!/bin/bash
form_dir="/root/ods"
tar_dir="/home/dw/ods"
target_host="hdp131"
target_user="root"
if [ $# -ne 2 ]
then
        echo "参数错误！必须有2个参数！"
        exit -1
fi

scp ${form_dir}/${1}/createtable/${2}.ctsh ${target_user}@${target_host}:/${tar_dir}/${1}/createtable
scp ${form_dir}/${1}/job/${2}.sh ${target_user}@${target_host}:/${tar_dir}/${1}/job
