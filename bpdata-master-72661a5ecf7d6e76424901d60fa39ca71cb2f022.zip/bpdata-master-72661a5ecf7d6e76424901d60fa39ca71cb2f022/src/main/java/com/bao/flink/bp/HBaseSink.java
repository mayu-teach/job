package com.bao.flink.bp;

import com.alibaba.fastjson.JSONObject;
import com.bao.flink.util.GenerateRowKeyUtil;
import com.bao.flink.util.HBaseUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * hbase sink
 */
public class HBaseSink<T> extends RichSinkFunction<T> {

    private static final Logger LOGGER = LoggerFactory.getLogger(HBaseSink.class);

    private String tableFullName;

    private String columnFamily;

    private static final String DATE_FORMAT_PATTERN_MODE_ONE = "yy-MM-dd HH:mm:ss";

    private static SimpleDateFormat sdfFrom = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    private static SimpleDateFormat sdfTraget = new SimpleDateFormat("yyyy-MM-dd");

    public HBaseSink(String tableFullName, String columnFamily) {
        this.tableFullName = tableFullName;
        this.columnFamily = columnFamily;
    }

    public void invoke(T value, Context context) throws Exception {
        // 插入hbase
        putToHBase(tableFullName, columnFamily, value);

    }

    /**
     * 插入hbase
     * @param tableFullName
     * @param columnFamily
     * @param obj
     */
    private void putToHBase(String tableFullName, String columnFamily, T obj) {
        String rowkey = generateBpRowKey(obj, tableFullName);
        HBaseUtils.putbp(tableFullName, rowkey, columnFamily, obj);
    }



    public static void main(String[] args) throws ParseException {

        String time = "1592282178736";

        if(time.endsWith("Z")){
            time = sdfTraget.format(sdfFrom.parse(time));
        }else{
            time = sdfTraget.format(new Date(Long.valueOf(time)));
        }
        System.out.println(time);
    }

    /**
     * 生成埋点数据rowkey
     * @param obj
     * @param tableFullName
     * @return
     *
     *
     */
    private  String generateBpRowKey(T obj, String tableFullName){
        String rowkey = new String();

        try {
            JSONObject bpMessage =  (JSONObject) obj;

            String snId = bpMessage.getString("uid");

            String time = bpMessage.getString("ts");

            if(time.endsWith("Z")){
                time = DateSyncUtil.formatDate(DateSyncUtil.parse(time));
            }else{
                time = DateSyncUtil.formatDate(new Date(Long.valueOf(time)));
            }
            rowkey = GenerateRowKeyUtil.generateRowKey(snId==null?"":snId, time==null?"":time);
            rowkey = rowkey+"-"+bpMessage.getString("ts");
        }catch (Exception e){
            e.printStackTrace();
        }

        return rowkey;
    }
    /**
     * 生成rowkey
     * @param obj
     * @param tableFullName
     * @return
     */


    /**
     * 测试插入hbase
     * @param tableFullName
     * @param columnFamily
     * @param obj
     */

    /**
     * 打开连接
     * @param parameters
     * @throws Exception
     */
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        HBaseUtils.getHBaseConnection();
    }

    /**
     * 关闭连接
     * @throws Exception
     */
    @Override
    public void close() throws Exception {
        super.close();
        HBaseUtils.closeHBaseConnection();
    }
}
