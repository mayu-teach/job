package com.bao.flink.util;

import com.bao.flink.constant.Constants;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * hbase工具类
 */
public class HBaseUtil {

    static Configuration conf = null;

    static Connection conn = null;

    static {
        conf = HBaseConfiguration.create();
        conf.set("hbase.zookeeper.quorum", PropertiesUtil.getPropertyValue(Constants.HBASE_ZOOKEEPER_QUORUM_TEST));
        conf.set("hbase.zookeeper.clientPort", PropertiesUtil.getPropertyValue(Constants.HBASE_ZOOKEEPER_CLIENTPORT));
        conf.set("zookeeper.znode.parent", PropertiesUtil.getPropertyValue(Constants.ZOOKEEPER_ZNODE_PARENT));
        System.setProperty("HADOOP_USER_NAME", PropertiesUtil.getPropertyValue(Constants.HADOOP_USER_NAME));

        try {
            conn = ConnectionFactory.createConnection(conf);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 插入hbase
     * @param tableFullName：命名空间 + 表名
     * @param columnFamily
     */
    private static void put(String tableFullName, String columnFamily, Object obj) {

        Table table = null;

        TableName tableName = TableName.valueOf(tableFullName);
        try {
            // 获取表对象
            table = conn.getTable(tableName);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(null != conn) {
                try {
                    conn.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * get
     * @param rowkey
     */
    private static void get(String rowkey) {
        Table table = null;

        TableName tableName = TableName.valueOf("iot:iot_log_iot_request_normal_message");
        try {
            table = conn.getTable(tableName);

            Get get = new Get(Bytes.toBytes(rowkey));
            get.addFamily(Bytes.toBytes("normalInfo"));
            get.addColumn(Bytes.toBytes("normalInfo"), Bytes.toBytes("direction"));
            get.setMaxVersions(2);

            Result result = table.get(get);
            if(!result.isEmpty()) {
                for(Cell cell : result.listCells()) {
                    System.out.println(Bytes.toString(cell.getFamilyArray(), cell.getFamilyOffset(), cell.getFamilyLength())
                                + ":" + Bytes.toString(cell.getQualifierArray(), cell.getQualifierOffset(), cell.getQualifierLength())
                                + ":" + Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(null != conn) {
                try {
                    conn.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * scan
     */
    private static void scan() {
        long start = System.currentTimeMillis();
        Table table = null;
        ResultScanner resultScanner = null;

        TableName tableName = TableName.valueOf("iot:iot_log_iot_request_normal_message");
        try {
            table = conn.getTable(tableName);

            Scan scan = new Scan();
            scan.addFamily(Bytes.toBytes("normalInfo"));
            scan.setCaching(100);
            scan.setBatch(100);
            scan.setStartRow(Bytes.toBytes("TE0119120025"));
            scan.setStopRow(Bytes.toBytes("TE0119120026"));

            resultScanner = table.getScanner(scan);
            if(null != resultScanner) {
                int count = 0;
                Iterator<Result> iterator = resultScanner.iterator();
                while(iterator.hasNext()) {
                    Result result = iterator.next();
                    for(Cell cell : result.listCells()) {
                        System.out.print(Bytes.toString(cell.getFamilyArray(), cell.getFamilyOffset(), cell.getFamilyLength())
                                + ":" + Bytes.toString(cell.getQualifierArray(), cell.getQualifierOffset(), cell.getQualifierLength())
                                + ":" + Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength()));
                    }
                    System.out.println();
                    count ++;
                }

                System.out.println(count);
            }

            long end = System.currentTimeMillis();

            System.out.println(end - start);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(null != resultScanner) {
                resultScanner.close();
            }
            if(null != table) {
                try {
                    table.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(null != conn) {
                try {
                    conn.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 根据时间戳范围Scan
     * @param minStamp  前一天00:00:00
     * @param maxStamp  当天00:00:00
     */
    private static void ScanByTimeRange(long minStamp, long maxStamp) {
        Table table = null;
        TableName tableName = TableName.valueOf("iot:iot_log_iot_request_normal_message");
        try {
            table = conn.getTable(tableName);
            Scan scan = new Scan();
            scan.addFamily(Bytes.toBytes("normalInfo"));
            scan.setTimeRange(minStamp, maxStamp);

            ResultScanner resultScanner = table.getScanner(scan);
            int count = 0;
            if(null != resultScanner) {
                Iterator<Result> its = resultScanner.iterator();
                while(its.hasNext()) {
                    Result result = its.next();
                    if(null != result) {
                        count++;
                        for(Cell cell : result.listCells()) {
                            System.out.println(Bytes.toString(cell.getRowArray(), cell.getRowOffset(), cell.getRowLength()));
                        }
                    }
                }
            }
            System.out.println(count);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(null != conn) {
                try {
                    conn.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {

    }

}
