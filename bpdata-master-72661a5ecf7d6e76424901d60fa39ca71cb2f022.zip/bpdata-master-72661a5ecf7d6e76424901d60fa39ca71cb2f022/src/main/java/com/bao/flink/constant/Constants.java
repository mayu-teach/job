package com.bao.flink.constant;

/**
 * 常量类
 */
public class Constants {

    // kafka broker配置
    public static final String BOOTSTRAP_SERVERS = "bootstrap.servers";
    public static final String BOOTSTRAP_SERVERS_TEST = "bootstrap.servers.test";

    public static final String BOOTSTRAP_SERVERS_ELK = "bootstrap.servers.elk";
    // kafka外网映射配置
    public static final String BOOTSTRAP_SERVERS_MAPPING = "bootstrap.servers.mapping";
    // kafka topic
    public static final String TEST_KAFKA_TOPICS = "test.kafka.topics";
    public static final String LOGIN_KAFKA_TOPICS = "login.kafka.topics";
    public static final String BUS_KAFKA_TOPICS = "bus.kafka.topics";
    public static final String NORMAL_KAFKA_TOPICS = "normal.kafka.topics";
    // kafka consumer
    public static final String TEST_GROUP_ID = "test.group.id";
    public static final String LOGIN_GROUP_ID = "login.group.id";
    public static final String BUS_GROUP_ID = "bus.group.id";
    public static final String NORMAL_GROUP_ID = "normal.group.id";
    // zookeeper
    public static final String ZOOKEEPER_SERVERS = "zookeeper.servers";
    // auto.offset.reset
    public static final String AUTO_OFFSET_RESET = "auto.offset.reset";
    // hbase.zookeeper.quorum
    public static final String HBASE_ZOOKEEPER_QUORUM = "hbase.zookeeper.quorum";
    public static final String HBASE_ZOOKEEPER_QUORUM_TEST = "hbase.zookeeper.quorum.test";
    // hbase.zookeeper.clientPort
    public static final String HBASE_ZOOKEEPER_CLIENTPORT = "hbase.zookeeper.clientPort";
    // zookeeper.znode.parent
    public static final String ZOOKEEPER_ZNODE_PARENT = "zookeeper.znode.parent";
    // hadoop.user.name
    public static final String HADOOP_USER_NAME = "hadoop.user.name";
    // hbase table & cf
    public static final String HBASE_IOT_LOGIN_TABLE_TEST = "hbase.iot.login.table.test";
    public static final String HBASE_IOT_LOGIN_SIMPLE_TABLE_TEST = "hbase.iot.login.simple.table.test";
    public static final String HBASE_IOT_LOGIN_COLUMNFAMILY_TEST = "hbase.iot.login.columnfamily.test";
    public static final String HBASE_IOT_BUS_TABLE_TEST = "hbase.iot.bus.table.test";
    public static final String HBASE_B_P_BUS_TABLE= "hbase.b.p.table";
    public static final String HBASE_B_P_BUS_COLUMNFAMILY = "hbase.b.p.columnfamily";
    public static final String HBASE_IOT_BUS_SIMPLE_TABLE_TEST = "hbase.iot.bus.simple.table.test";
    public static final String HBASE_IOT_BUS_COLUMNFAMILY_TEST = "hbase.iot.bus.columnfamily.test";
    public static final String HBASE_IOT_NORMAL_TABLE_TEST = "hbase.iot.normal.table.test";
    public static final String HBASE_IOT_NORMAL_ALL_TABLE_TEST = "hbase.iot.normal.all.table.test";
    public static final String HBASE_IOT_NORMAL_SIMPLE_TABLE_TEST = "hbase.iot.normal.simple.table.test";
    public static final String HBASE_IOT_NORMAL_COLUMNFAMILY_TEST = "hbase.iot.normal.columnfamily.test";
    public static final String HBASE_IOT_NORMAL_ALL_COLUMNFAMILY_TEST = "hbase.iot.normal.all.columnfamily.test";
    public static final String HBASE_IOT_TRANSFER_STATUS_TABLE = "hbase.iot.transfer.status.table";
    public static final String HBASE_IOT_TRANSFER_STATUS_COLUMNFAMILY = "hbase.iot.transfer.status.columnfamily";

    public static final String IOT_SYNC_IN_PROGRESS_STATUS = "0";
    public static final String IOT_SYNC_SUCCESS_STATUS = "1";
    public static final String IOT_SYNC_FAIL_STATUS = "2";


    //流量数据
    public static final String USERLOG_KAFKA_TOPIC = "userLog.kafka.topic";
    public static final String USERLOG_GROUP_ID = "userLog.group.id";
    public static final String GEO_DISTANCE = "geodistance.group.id";
    //public static final String ZOOKEEPER_SERVERS_TEST = "zookeeper.servers.test";

}
