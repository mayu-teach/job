package com.bao.flink.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.bao.flink.constant.Constants;
import com.bao.flink.bp.DateSyncUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * hbase Java-API
 */
public class HBaseUtils {

    private static Configuration conf = null;

    private static Connection conn = null;

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private static SimpleDateFormat sdfFrom = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    private static SimpleDateFormat sdfTraget = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static SimpleDateFormat dtsdfTraget = new SimpleDateFormat("yyyy-MM-dd");
    /**
     * 获取hbase连接
     */
    public static void getHBaseConnection() {
        conf = HBaseConfiguration.create();
        conf.set("hbase.zookeeper.quorum", PropertiesUtil.getPropertyValue(Constants.HBASE_ZOOKEEPER_QUORUM));
        conf.set("hbase.zookeeper.clientPort", PropertiesUtil.getPropertyValue(Constants.HBASE_ZOOKEEPER_CLIENTPORT));
        conf.set("zookeeper.znode.parent", PropertiesUtil.getPropertyValue(Constants.ZOOKEEPER_ZNODE_PARENT));
        System.setProperty("HADOOP_USER_NAME", PropertiesUtil.getPropertyValue(Constants.HADOOP_USER_NAME));

        try {
            conn = ConnectionFactory.createConnection(conf);
        } catch (IOException e) {
            throw new RuntimeException("HBaseUtils getHBaseConnection error......");
        }
    }

    /**
     * 获取table
     * @param tableFullName
     * @return
     */
    public static Table getTable(String tableFullName) {
        Table table = null;
        TableName tableName = TableName.valueOf(tableFullName);

        try {
            table = conn.getTable(tableName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return table;
    }

    /**
     * 关闭hbase连接
     */
    public static void closeHBaseConnection() {
        if(null != conn) {
            try {
                conn.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void putbp(String tableFullName, String rowkey, String columnFamily, Object obj) {

        Table table = null;
        try {
            table = getTable(tableFullName);

            Put put = new Put(Bytes.toBytes(rowkey));
            JSONObject bpdata = (JSONObject) obj;
            for(String key :bpdata.keySet()){
                String value = bpdata.get(key)==null?"":bpdata.get(key).toString();
                if(key.equals("terminal_type")){
                    if(value.equals("android")){
                        value="1";
                    }
                    else if(value.equals("ios")){
                        value = "2";
                    }

                    else if(value.equals("weixin")){
                        value="3";
                    }else{
                        value="0";
                    }
                }

                if(key.equals("params")){
                    JSONObject json = JSON.parseObject(value);
                    if(!value.isEmpty()){
                       String page_path = json.containsKey("page_path") ? json.getString("page_path") : "";
                       String page_title = json.containsKey("page_title") ? json.getString("page_title") : "";
                       String page_browse_time = json.containsKey("duration") ? json.getString("duration") : "";
                       put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("page_path"),Bytes.toBytes(page_path));
                       put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("page_title"),Bytes.toBytes(page_title));
                       put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("page_browse_time"),Bytes.toBytes(page_browse_time));
                    }

                }
                if(key.equals("ts")){
                    String point_time = "";

                    if(value.endsWith("Z")){
                        point_time = DateSyncUtil.formatDate(DateSyncUtil.parse(value));
                    }else{
                        point_time = DateSyncUtil.formatDate(new Date(Long.valueOf(value)));
                    }
                    put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("point_time"),Bytes.toBytes(point_time));
                    put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("dt"),Bytes.toBytes(point_time.substring(0,10)));
                }
                put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes(key),Bytes.toBytes(value));
            }
            String create_time = DateSyncUtil.formatDate(new Date());
            put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("create_time"),Bytes.toBytes(create_time));
            put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("content"),Bytes.toBytes(bpdata.toJSONString()));
            table.put(put);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

    }
    /**
     * 单个插入
     * @param tableFullName
     * @param rowkey
     * @param columnFamily
     * @param obj
     */
    public static void put(String tableFullName, String rowkey, String columnFamily, Object obj) {
        Table table = null;
        try {
            table = getTable(tableFullName);

            Put put = new Put(Bytes.toBytes(rowkey));
            List<Field> fields = getDeclaredAndNotStaticFields(obj.getClass());
            for(Field field : fields) {
                field.setAccessible(true);
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(obj) == null ? "" : field.get(obj).toString()));
            }

            table.put(put);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 批量put
     * @param tableFullName
     * @param puts
     */
    public static void puts(String tableFullName, List<Put> puts) {
        Table table = null;
        try {
            table = getTable(tableFullName);
            table.put(puts);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 批量插入
     * @param tableFullName
     * @param columnFamily
     * @param rowObj
     */
    public static void batchPut(String tableFullName, String columnFamily, Map<String, Object> rowObj) {
        Table table = null;
        try {
            table = getTable(tableFullName);

            List<Put> puts = new ArrayList<Put>();
            Put put = null;
            for(Map.Entry<String, Object> entry : rowObj.entrySet()) {
                put = new Put(Bytes.toBytes(entry.getKey()));

                Object obj = entry.getValue();
                List<Field> fields = getDeclaredAndNotStaticFields(obj.getClass());
                for(Field field : fields) {
                    field.setAccessible(true);
                    put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(field.getName()), Bytes.toBytes(field.get(obj) == null ? "" : field.get(obj).toString()));
                }

                puts.add(put);
            }

            table.put(puts);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * get
     * @param tableFullName
     * @param columnFamily
     * @param rowkey
     * @return
     */
    public static Result get(String tableFullName, String columnFamily, String rowkey) {
        Table table = null;
        Result result = null;

        try {
            table = getTable(tableFullName);

            Get get = new Get(Bytes.toBytes(rowkey));
            get.addFamily(Bytes.toBytes(columnFamily));

            result = table.get(get);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return result;
    }

    /**
     * 根据rowkey范围scan
     * @param tableFullName
     * @param columnFamily
     * @param startRow
     * @param stopRow
     * @return
     */
    public static ResultScanner scan(String tableFullName, String columnFamily, String startRow, String stopRow) {
        Table table = null;
        ResultScanner resultScanner = null;

        try {
            table = getTable(tableFullName);

            Scan scan = new Scan();

            scan.addFamily(Bytes.toBytes(columnFamily));
            scan.setCaching(100);
            scan.setBatch(100);
            scan.setStartRow(Bytes.toBytes(startRow));
            scan.setStopRow(Bytes.toBytes(stopRow));

            resultScanner = table.getScanner(scan);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return resultScanner;
    }

    /**
     * 根据时间范围scan
     * @param tableFullName
     * @param columnFamily
     * @param minStamp
     * @param maxStamp
     * @return
     */
    public static ResultScanner scanByTimeRange(String tableFullName, String columnFamily, long minStamp, long maxStamp) {
        Table table = null;
        ResultScanner resultScanner = null;

        try {
            table = getTable(tableFullName);

            Scan scan = new Scan();
            scan.setCaching(100);
            scan.setBatch(100);
            scan.addFamily(Bytes.toBytes(columnFamily));
            scan.setTimeRange(minStamp, maxStamp);

            resultScanner = table.getScanner(scan);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(null != table) {
                try {
                    table.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return resultScanner;
    }

    /**
     * 获取对象有效属性
     * @param clazz
     * @return
     */
    public static List<Field> getDeclaredAndNotStaticFields(Class clazz) {
        List<Field> fieldList = new ArrayList<Field>();
        Field[] fields = clazz.getDeclaredFields();
        for(Field field : fields) {
            if(!Modifier.isStatic(field.getModifiers())) {
                fieldList.add(field);
            }
        }

        return fieldList;
    }

}
