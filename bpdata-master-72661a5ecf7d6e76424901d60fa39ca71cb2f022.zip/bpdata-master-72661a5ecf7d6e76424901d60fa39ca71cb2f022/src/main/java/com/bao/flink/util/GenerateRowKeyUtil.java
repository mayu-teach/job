package com.bao.flink.util;

/**
 * 生成hbase rowkey
 */
public class GenerateRowKeyUtil {

    public static String generateRowKey(String snId, String time) {

        return time + "-" + snId;
    }

}
