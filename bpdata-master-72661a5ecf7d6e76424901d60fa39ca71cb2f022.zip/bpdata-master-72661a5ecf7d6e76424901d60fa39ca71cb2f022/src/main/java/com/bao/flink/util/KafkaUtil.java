package com.bao.flink.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.bao.flink.constant.Constants;
import com.google.gson.JsonObject;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.util.Properties;

/**
 * kafka工具类
 */
public class KafkaUtil {
    public static final String broker_list = "192.168.2.130:6667,192.168.2.131:6667,192.168.2.132:6667,192.168.2.133:6667,192.168.2.134:6667";
    public static final String topic = "topic.znlh.buried.point.log";  //kafka topic 需要和 flink 程序用同一个 topic

    /**
     * //        props.setProperty("group.id", "bulk");
     * @param groupId
     * @return
     */
    public static Properties getKafkaConfig(String groupId) {
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", PropertiesUtil.getPropertyValue(Constants.BOOTSTRAP_SERVERS_ELK));
        props.setProperty("group.id", groupId);//hbase-hive geodistance
        props.setProperty("auto.offset.reset", PropertiesUtil.getPropertyValue(Constants.AUTO_OFFSET_RESET));

        return props;
    }



    public static void writeToKafka() throws InterruptedException {
        Properties props = new Properties();
        props.put("bootstrap.servers", broker_list);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        KafkaProducer producer = new KafkaProducer<String, String>(props);

        int i=0;
        while (true){
            //for (int i = 1; i <= 100; i++) {
            JSONObject json1 = new JSONObject();
            JSONObject json2 = new JSONObject();
            JSONObject params_json = new JSONObject();

            params_json.put("page_path","page_path111");
            params_json.put("page_title","page_title111");
            params_json.put("duration","1111");

            json2.put("terminal_type","11");
            json2.put("dev","dev11");
            json2.put("la","la11");
            json2.put("lo","lo11");
            json2.put("mac","mac11");
            json2.put("os","os11");
            json2.put("event_id","event_id11");
            json2.put("sid","uid");
            json2.put("params",params_json);

            JSONArray arr = new JSONArray();
            arr.add(json2);

            json1.put("source",0);
            json1.put("body",arr);

            ProducerRecord record = new ProducerRecord<String, String>(topic, null, null, json1.toString());
            producer.send(record);
            Thread.sleep(1 * 1000);
            /*Student student = new Student(i, "zhisheng" + i, "password" + i, 18 + i);
            ProducerRecord record = new ProducerRecord<String, String>(topic, null, null, GsonUtil.toJson(student));
            producer.send(record);
            System.out.println("发送数据: " + GsonUtil.toJson(student));
            Thread.sleep(10 * 1000); //发送一条数据 sleep 10s，相当于 1 分钟 6 条*/
            // }
            if(i%30 ==0){
                producer.flush();
            }
            
            i++;
        }

    }

    public static void main(String[] args) throws InterruptedException{
        writeToKafka();
    }
}
