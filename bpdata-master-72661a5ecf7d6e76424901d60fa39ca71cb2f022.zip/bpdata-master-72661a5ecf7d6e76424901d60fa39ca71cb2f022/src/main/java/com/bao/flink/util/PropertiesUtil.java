package com.bao.flink.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

/**
 * 读取配置文件信息
 */
public class PropertiesUtil {

    private static Properties prop = null;

    private static String CONFIG_PROPERTIES = "conf.properties";

    static{
        // 获取配置
        prop = new Properties();
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        // 获取输入流
        InputStream is = loader.getResourceAsStream(CONFIG_PROPERTIES);
        try {
            prop.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 根据key获取value
     * @param key
     * @param defaultValue
     * @return
     */
    public static String getPropertyValue(String key, String defaultValue){
        if(StringUtils.isEmpty(key)){
            return null;
        }
        String value = prop.getProperty(key);
        if(null == value){
            return defaultValue;
        }
        return value;
    }

    /**
     * 根据key获取value
     * @param key
     * @return
     */
    public static String getPropertyValue(String key){
        if(StringUtils.isEmpty(key)){
            return null;
        }
        String value = prop.getProperty(key);
        return value;
    }

    public static double distance(double lat1, double lon1, double lat2, double lon2, char unit) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        if (unit == 'K') {
            dist = dist * 1.609344;
        } else if (unit == 'N') {
            dist = dist * 0.8684;
        }
        return (dist);
    }
    /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
    /*::  This function converts decimal degrees to radians             :*/
    /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
    private static double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }
    /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
    /*::  This function converts radians to decimal degrees             :*/
    /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
    private static double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }
    //211.410
    public static void main(String[] args) {

//        System.out.println(new Date());
//        System.out.println(new Date(1592784000000L));
         long start = TimeWindow.getWindowStartWithOffset(1592322531438L, 0, 86400000L);
         System.out.println(start);
         System.out.println(new Date(1592393024048L));//1592361628323L

        System.out.println(distance(31.709913, 120.810359, 31.681868, 120.7497, 'K') + " Kilometers\n");

    }


}
