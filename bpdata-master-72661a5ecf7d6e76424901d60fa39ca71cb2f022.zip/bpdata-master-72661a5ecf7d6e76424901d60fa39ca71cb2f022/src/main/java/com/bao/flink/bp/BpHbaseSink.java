package com.bao.flink.bp;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.bao.flink.constant.Constants;
import com.bao.flink.util.KafkaUtil;
import com.bao.flink.util.PropertiesUtil;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.util.serialization.JSONKeyValueDeserializationSchema;
import org.apache.flink.util.Collector;
import java.util.ArrayList;
import java.util.List;

public class BpHbaseSink {

    public static void main(String[] args) {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.enableCheckpointing(5000);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        FlinkKafkaConsumer011<ObjectNode> source =
                new FlinkKafkaConsumer011<ObjectNode>(PropertiesUtil.getPropertyValue(Constants.USERLOG_KAFKA_TOPIC),
                        new JSONKeyValueDeserializationSchema
                                (true), KafkaUtil.getKafkaConfig(PropertiesUtil.getPropertyValue(Constants.USERLOG_GROUP_ID)));
        source.setStartFromTimestamp(1592323199215L);
        SingleOutputStreamOperator<JSONObject> transction = env.addSource(source).setParallelism(1).flatMap(new FlatMapFunction<ObjectNode, JSONObject>() {
            @Override
            public void flatMap(ObjectNode value, Collector<JSONObject> out) throws Exception {
                List<JSONObject> jsonArr = new ArrayList<JSONObject>();
                try {
                    String str = value.get("value").toString();
                    JSONObject valueJson = JSONObject.parseObject(str);
                    String source = valueJson.getString("source");
                    String data = valueJson.getString("body");
                    JSONArray jsonArray = JSONArray.parseArray(data);

                    for (int i = 0; i < jsonArray.size(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        jsonObject.put("source", source);
                        out.collect(jsonObject);
                    }
                } catch (Exception e) {
                    out.collect(new JSONObject());
                    e.printStackTrace();
                }
            }
        }).setParallelism(1).filter(new FilterFunction<JSONObject>() {
            @Override
            public boolean filter(JSONObject value) throws Exception {
                return !value.isEmpty();
            }
        }).setParallelism(1);
        transction.addSink(new HBaseSink(PropertiesUtil.getPropertyValue(Constants.HBASE_B_P_BUS_TABLE),
                PropertiesUtil.getPropertyValue(Constants.HBASE_B_P_BUS_COLUMNFAMILY))).setParallelism(5);
        try {
            env.execute(BpHbaseSink.class.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
