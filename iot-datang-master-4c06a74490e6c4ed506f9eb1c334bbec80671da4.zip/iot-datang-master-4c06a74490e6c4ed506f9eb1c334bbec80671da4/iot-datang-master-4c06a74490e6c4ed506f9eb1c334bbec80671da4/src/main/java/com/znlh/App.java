package com.znlh;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println("null".equalsIgnoreCase("null"));
        System.out.println("NULL".equalsIgnoreCase("null"));
        System.out.println("null".equals("NULL"));
    }
}
