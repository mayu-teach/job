package com.znlh.dto;

/**
 * 设备生命周期实体类
 */
public class GpsLifeCycleDto {

    private String gpsCode;
    private String reportTime;
    private Double accDuration;
    private Double upDownDuration;
    private Double walkDuration;
    private Double workDuration;

    public String getGpsCode() {
        return gpsCode;
    }

    public void setGpsCode(String gpsCode) {
        this.gpsCode = gpsCode;
    }

    public String getReportTime() {
        return reportTime;
    }

    public void setReportTime(String reportTime) {
        this.reportTime = reportTime;
    }

    public Double getAccDuration() {
        return accDuration;
    }

    public void setAccDuration(Double accDuration) {
        this.accDuration = accDuration;
    }

    public Double getUpDownDuration() {
        return upDownDuration;
    }

    public void setUpDownDuration(Double upDownDuration) {
        this.upDownDuration = upDownDuration;
    }

    public Double getWalkDuration() {
        return walkDuration;
    }

    public void setWalkDuration(Double walkDuration) {
        this.walkDuration = walkDuration;
    }

    public Double getWorkDuration() {
        return workDuration;
    }

    public void setWorkDuration(Double workDuration) {
        this.workDuration = workDuration;
    }

    @Override
    public String toString() {
        return "GpsLifeCycleDto{" +
                "gpsCode='" + gpsCode + '\'' +
                ", reportTime='" + reportTime + '\'' +
                ", accDuration=" + accDuration +
                ", upDownDuration=" + upDownDuration +
                ", walkDuration=" + walkDuration +
                ", workDuration=" + workDuration +
                '}';
    }
}
