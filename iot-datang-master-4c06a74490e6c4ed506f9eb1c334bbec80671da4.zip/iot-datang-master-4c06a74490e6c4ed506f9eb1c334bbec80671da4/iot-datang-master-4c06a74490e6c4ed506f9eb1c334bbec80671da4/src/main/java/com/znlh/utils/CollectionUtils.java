package com.znlh.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * 集合工具类
 */
public class CollectionUtils {

    /**
     * 将list拆分成多个子list
     * @param list
     * @param toIndex
     * @return
     */
    public static List<List<String>> groupList(List<String> list, int toIndex) {
        List<List<String>> listGroup = new ArrayList<>();
        int listSize = list.size();

        for (int i = 0; i < list.size(); i += toIndex) {
            if (i + toIndex > listSize) {
                toIndex = listSize - i;
            }
            List<String> newList = list.subList(i, i + toIndex);
            listGroup.add(newList);
        }
        return listGroup;
    }

}
