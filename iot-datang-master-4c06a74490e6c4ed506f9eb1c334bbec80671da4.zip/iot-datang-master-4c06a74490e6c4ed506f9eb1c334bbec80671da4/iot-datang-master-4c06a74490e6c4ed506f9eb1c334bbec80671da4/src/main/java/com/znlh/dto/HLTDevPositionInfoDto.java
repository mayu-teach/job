package com.znlh.dto;

import java.io.Serializable;

/**
 * Haulott设备位置信息表
 */
public class HLTDevPositionInfoDto implements Serializable {
    private static final long serialVersionUID = -8701564654702228755L;

    private String devCode;
    private Integer type;
    private String lat;
    private String lng;
    private Integer speed;
    private Integer direction;
    private Integer satellite;
    private String locationTime;
    private Integer gpsIsLast;
    private Long offset;
    private String dataGenerateTime;

    public String getDevCode() {
        return devCode;
    }

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Integer getDirection() {
        return direction;
    }

    public void setDirection(Integer direction) {
        this.direction = direction;
    }

    public Integer getSatellite() {
        return satellite;
    }

    public void setSatellite(Integer satellite) {
        this.satellite = satellite;
    }

    public String getLocationTime() {
        return locationTime;
    }

    public void setLocationTime(String locationTime) {
        this.locationTime = locationTime;
    }

    public Integer getGpsIsLast() {
        return gpsIsLast;
    }

    public void setGpsIsLast(Integer gpsIsLast) {
        this.gpsIsLast = gpsIsLast;
    }

    public Long getOffset() {
        return offset;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }

    public String getDataGenerateTime() {
        return dataGenerateTime;
    }

    public void setDataGenerateTime(String dataGenerateTime) {
        this.dataGenerateTime = dataGenerateTime;
    }

    @Override
    public String toString() {
        return devCode +
                "\t" + type +
                "\t" + lat +
                "\t" + lng +
                "\t" + speed +
                "\t" + direction +
                "\t" + satellite +
                "\t" + locationTime +
                "\t" + gpsIsLast +
                "\t" + offset +
                "\t" + dataGenerateTime;
    }
}
