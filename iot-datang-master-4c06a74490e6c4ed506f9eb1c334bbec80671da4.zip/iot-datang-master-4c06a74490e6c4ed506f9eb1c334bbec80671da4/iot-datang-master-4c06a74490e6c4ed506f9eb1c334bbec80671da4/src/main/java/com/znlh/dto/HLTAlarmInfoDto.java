package com.znlh.dto;

import java.io.Serializable;

/**
 * Haulott报警信息
 */
public class HLTAlarmInfoDto implements Serializable {
    private static final long serialVersionUID = 1391372884271272526L;

    private String devCode;
    private Integer alarmType;
    private String alarmTypeValue;
    private Integer alarmState;
    private String alarmTime;
    private String key;
    private Long offset;
    private String dataGenerateTime;

    public String getDevCode() {
        return devCode;
    }

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public Integer getAlarmType() {
        return alarmType;
    }

    public void setAlarmType(Integer alarmType) {
        this.alarmType = alarmType;
    }

    public String getAlarmTypeValue() {
        return alarmTypeValue;
    }

    public void setAlarmTypeValue(String alarmTypeValue) {
        this.alarmTypeValue = alarmTypeValue;
    }

    public Integer getAlarmState() {
        return alarmState;
    }

    public void setAlarmState(Integer alarmState) {
        this.alarmState = alarmState;
    }

    public String getAlarmTime() {
        return alarmTime;
    }

    public void setAlarmTime(String alarmTime) {
        this.alarmTime = alarmTime;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Long getOffset() {
        return offset;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }

    public String getDataGenerateTime() {
        return dataGenerateTime;
    }

    public void setDataGenerateTime(String dataGenerateTime) {
        this.dataGenerateTime = dataGenerateTime;
    }

    @Override
    public String toString() {
        return devCode +
                "\t" + alarmType +
                "\t" + alarmTypeValue +
                "\t" + alarmState +
                "\t" + alarmTime +
                "\t" + key +
                "\t" + offset +
                "\t" + dataGenerateTime;
    }
}
