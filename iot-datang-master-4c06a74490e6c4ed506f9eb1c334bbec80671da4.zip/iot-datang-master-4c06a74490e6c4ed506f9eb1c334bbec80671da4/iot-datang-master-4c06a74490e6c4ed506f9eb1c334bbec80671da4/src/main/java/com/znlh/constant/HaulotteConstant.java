package com.znlh.constant;

/**
 * Haulott-kafka之key信息
 */
public class HaulotteConstant {

    /** 位置信息 */
    public static final String[] HAULOTTE_GPS_ARRAY = {"TC_0001_00_5"};
    /** 其他信息 */
    public static final String[] HAULOTTE_EXT_ARRAY = {"TC_0002_02_47", "HLT_0002_00_03", "HLT_0002_00_04", "HLT_0002_00_05", "TC_0001_00_02"};
    /** 电池相关信息 */
    public static final String[] HAULOTTE_BATTERY_ARRAY = {"HLT_0002_00_01", "HLT_0002_00_02", "HLT_0002_00_06", "HLT_0002_00_07", "HLT_0002_00_50"};
    /** 报警信息 */
    public static final String[] HAULOTTE_ALARM_ARRAY = {"HLT_0002_00_08", "HLT_0002_00_09", "HLT_0002_00_10", "HLT_0002_00_51"};
    /** 故障信息 */
    public static final String[] HAULOTTE_FAULT_ARRAY = {"HLT_0002_00_12", "HLT_0002_00_11"};
    /** 平台动作信息 */
    public static final String[] HAULOTTE_PLATFORMINSTRUCTION_ARRAY = {"HLT_0002_00_17"};
    /** 操作日志信息 */
    public static final String[] HAULOTTE_OPERATELOG_ARRAY = {"HLT_0002_00_18", "HLT_0002_00_19", "HLT_0002_00_20", "HLT_0002_00_21", "HLT_0002_00_22", "HLT_0002_00_23", "HLT_0002_00_24", "HLT_0002_00_25", "HLT_0002_00_26", "HLT_0002_00_27", "HLT_0002_00_28", "HLT_0002_00_29", "HLT_0002_00_30", "HLT_0002_00_31", "HLT_0002_00_32", "HLT_0002_00_33", "HLT_0002_00_34"};
    /** 操作时间信息 */
    public static final String[] HAULOTTE_OPERATEHOURS_ARRAY = {"HLT_0002_00_35", "HLT_0002_00_36", "HLT_0002_00_37", "HLT_0002_00_38", "HLT_0002_00_39", "HLT_0002_00_40", "HLT_0002_00_41", "HLT_0002_00_42", "HLT_0002_00_43", "HLT_0002_00_44", "HLT_0002_00_45", "HLT_0002_00_46", "HLT_0002_00_47", "HLT_0002_00_48", "HLT_0002_00_49"};


}
