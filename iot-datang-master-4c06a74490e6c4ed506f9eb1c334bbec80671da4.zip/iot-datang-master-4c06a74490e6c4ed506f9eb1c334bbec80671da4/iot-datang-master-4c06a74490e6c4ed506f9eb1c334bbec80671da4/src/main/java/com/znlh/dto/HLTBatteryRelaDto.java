package com.znlh.dto;

import java.io.Serializable;

/**
 * Haulott电池信息
 */
public class HLTBatteryRelaDto implements Serializable {
    private static final long serialVersionUID = -3045546244829625846L;

    private String devCode;
    private Integer bussType;
    private String bussTypeValue;
    private Integer bussValue;
    private String key;
    private Long offset;
    private String dataGenerateTime;

    public String getDevCode() {
        return devCode;
    }

    public void setDevCode(String devCode) {
        this.devCode = devCode;
    }

    public Integer getBussType() {
        return bussType;
    }

    public void setBussType(Integer bussType) {
        this.bussType = bussType;
    }

    public String getBussTypeValue() {
        return bussTypeValue;
    }

    public void setBussTypeValue(String bussTypeValue) {
        this.bussTypeValue = bussTypeValue;
    }

    public Integer getBussValue() {
        return bussValue;
    }

    public void setBussValue(Integer bussValue) {
        this.bussValue = bussValue;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Long getOffset() {
        return offset;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }

    public String getDataGenerateTime() {
        return dataGenerateTime;
    }

    public void setDataGenerateTime(String dataGenerateTime) {
        this.dataGenerateTime = dataGenerateTime;
    }

    @Override
    public String toString() {
        return devCode +
                "\t" + bussType +
                "\t" + bussTypeValue +
                "\t" + bussValue +
                "\t" + key +
                "\t" + offset +
                "\t" + dataGenerateTime;
    }
}
