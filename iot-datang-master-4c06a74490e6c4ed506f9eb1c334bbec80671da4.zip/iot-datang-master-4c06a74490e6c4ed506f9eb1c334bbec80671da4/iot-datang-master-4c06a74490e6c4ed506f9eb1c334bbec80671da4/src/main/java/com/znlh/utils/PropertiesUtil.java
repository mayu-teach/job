package com.znlh.utils;

import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * 读取配置文件key-value
 */
public class PropertiesUtil {

    private static Properties prop = null;

    private static String CONFIG_PROPERTIES = "conf.properties";

    static{
        // 获取配置
        prop = new Properties();
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        // 获取输入流
        InputStream is = loader.getResourceAsStream(CONFIG_PROPERTIES);
        try {
            prop.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 根据key获取value
     * @param key
     * @param defaultValue
     * @return
     */
    public static String getPropertyValue(String key, String defaultValue){
        if(StringUtils.isEmpty(key)){
            return null;
        }
        String value = prop.getProperty(key);
        if(null == value){
            return defaultValue;
        }
        return value;
    }

    /**
     * 根据key获取value
     * @param key
     * @return
     */
    public static String getPropertyValue(String key){
        if(StringUtils.isEmpty(key)){
            return null;
        }
        String value = prop.getProperty(key);
        return value;
    }
}
