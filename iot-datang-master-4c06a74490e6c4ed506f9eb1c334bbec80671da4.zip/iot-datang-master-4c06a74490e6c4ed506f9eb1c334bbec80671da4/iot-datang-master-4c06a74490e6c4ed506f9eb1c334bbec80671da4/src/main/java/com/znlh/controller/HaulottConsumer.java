package com.znlh.controller;

import com.znlh.constant.Constants;
import com.znlh.utils.PropertiesUtil;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Properties;

/**
 * Haulott-kafka报文落hdfs
 */
public class HaulottConsumer implements Serializable {
    private static final long serialVersionUID = -1848333774689528637L;

    private static final Logger LOGGER = LoggerFactory.getLogger(HaulottConsumer.class);

    public static void main(String[] args) {

        LOGGER.error("HaulottConsumer is starting......");
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//        env.enableCheckpointing(1000 * 5);
//        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
//        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(1000);
//        env.getCheckpointConfig().setCheckpointTimeout(60000);
//        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
//
//        env.setStateBackend(new MemoryStateBackend());
//        env.setStateBackend(new FsStateBackend("hdfs:///flink/checkpoints"));

        Properties prop = new Properties();
        prop.put("bootstrap.servers", PropertiesUtil.getPropertyValue(Constants.BOOTSTRAP_SERVERS_HAULOTT_PRD));
        prop.put("group.id", PropertiesUtil.getPropertyValue(Constants.KAFKA_GROUP_ID_HAULOTT_HDFS));
        prop.put("auto.offset.reset", PropertiesUtil.getPropertyValue(Constants.AUTO_OFFSET_RESET));

        FlinkKafkaConsumer011<String> kafkaConsumer011 =
                new FlinkKafkaConsumer011<>(PropertiesUtil.getPropertyValue(Constants.KAFKA_TOPICS_HAULOTT),
                        new SimpleStringSchema(), prop);

        kafkaConsumer011.setStartFromGroupOffsets();

//        Map<KafkaTopicPartition, Long> offsets = new HashMap<>();
//        offsets.put(new KafkaTopicPartition(PropertiesUtil.getPropertyValue(Constants.KAFKA_TOPICS_HAULOTT), 0), 650465500L);
//
//        kafkaConsumer011.setStartFromSpecificOffsets(offsets);

        DataStream<String> text = env.addSource(kafkaConsumer011);
//        text.print().setParallelism(1);
        


        try {
            env.execute(HaulottConsumer.class.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
