package com.znlh.constant;

/**
 * 常量类
 */
public class Constants {

    // kafka broker
    public static final String BOOTSTRAP_SERVERS_LINGONG_TEST = "bootstrap.servers.lingong.test";
    public static final String BOOTSTRAP_SERVERS_LINGONG_PRD = "bootstrap.servers.lingong.prd";
    public static final String BOOTSTRAP_SERVERS_HAULOTT_PRD = "bootstrap.servers.haulott.prd";
    // kafka topic
    public static final String KAFKA_TOPICS_LINGONG = "kafka.topics.lingong";
    public static final String KAFKA_TOPICS_HAULOTT = "kafka.topics.haulott";
    // kafka groupid
    public static final String KAFKA_GROUP_ID_LINGONG = "kafka.group.id.lingong";
    public static final String KAFKA_GROUP_ID_HAULOTT = "kafka.group.id.haulott";
    public static final String KAFKA_GROUP_ID_HAULOTT_HDFS = "kafka.group.id.haulott.hdfs";
    public static final String KAFKA_GROUP_ID_LINGONG_HDFS = "kafka.group.id.lingong.hdfs";
    public static final String AUTO_OFFSET_RESET = "auto.offset.reset";
    // es hostname
    public static final String ES_HOSTNAME_132 = "es.hostname.132";
    public static final String ES_HOSTNAME_133 = "es.hostname.133";
    public static final String ES_HOSTNAME_134 = "es.hostname.134";
    // es port
    public static final String ES_PORT = "es.port";
    // es schema
    public static final String ES_SCHEMA = "es.schema";
    // es index
    public static final String ES_INDEX_LINGONG = "es.index.lingong";
    public static final String ES_INDEX_HAULOTT = "es.index.haulott";
    // es index type
    public static final String ES_INDEX_TYPE_LINGONG = "es.index.type.lingong";
    public static final String ES_INDEX_TYPE_HAULOTT = "es.index.type.haulott";

    public static final String IS_STRING_NULL = "null";

}
