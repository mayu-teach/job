package com.znlh.controller;

import com.alibaba.fastjson.JSONObject;
import com.znlh.dto.GpsLifeCycleDto;
import com.znlh.utils.HttpClientUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 设备生命周期数据同步平台
 */
public class IotGpsLifeCycleController {

    private static final Logger LOGGER = LoggerFactory.getLogger(IotGpsLifeCycleController.class);

    private static final String URL = "";

    /**
     *
     * @param args
     * 参数一：dt=20200809（同步前一天数据）
     */
    public static void main(String[] args) {

        LOGGER.info("IotGpsLifeCycleController sync start......");

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            Class.forName("com.facebook.presto.jdbc.PrestoDriver");
            connection = DriverManager.getConnection("jdbc:presto://192.168.2.131:8086/hive/dws", "dw", "");

            statement = connection.createStatement();

            String sql = "select gps_code,report_time,acc_duration,up_down_duration,walk_duration,work_duration from hive.dws.dws_iot_gps_life_cycle where dt = '" + args[0] + "'";
            resultSet = statement.executeQuery(sql);

            List<GpsLifeCycleDto> gpsLifeCycleList = new ArrayList<>();
            GpsLifeCycleDto gpsLifeCycleDto  = null;

            while (resultSet.next()) {
                gpsLifeCycleDto = new GpsLifeCycleDto();

                gpsLifeCycleDto.setGpsCode(resultSet.getString("gps_code"));
                gpsLifeCycleDto.setReportTime(resultSet.getString("report_time"));
                gpsLifeCycleDto.setAccDuration(resultSet.getDouble("acc_duration"));
                gpsLifeCycleDto.setUpDownDuration(resultSet.getDouble("up_down_duration"));
                gpsLifeCycleDto.setWalkDuration(resultSet.getDouble("walk_duration"));
                gpsLifeCycleDto.setWorkDuration(resultSet.getDouble("work_duration"));

                gpsLifeCycleList.add(gpsLifeCycleDto);
            }

            String httpResult = HttpClientUtil.doPost(URL, null, null, JSONObject.toJSONString(gpsLifeCycleList));

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        } finally {
            if (null != resultSet) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    LOGGER.error("IotGpsLifeCycleController ResultSet close is error......");
                }
            }
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    LOGGER.error("IotGpsLifeCycleController Statement close is error......");
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    LOGGER.error("IotGpsLifeCycleController Connection close is error......");
                }
            }
        }

    }

}
