package com.znlh.controller;

import com.alibaba.fastjson.JSONObject;
import com.znlh.utils.ElasticSearchUtils;
import com.znlh.utils.HttpClientUtil;
import com.znlh.utils.MD5Utils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.client.transport.TransportClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Rest-接入大唐数据
 */
public class DaTangConsumer implements Serializable {
    private static final long serialVersionUID = -2186619550941089827L;
    private static final Logger LOGGER = LoggerFactory.getLogger(DaTangConsumer.class);

    private static final int THREAD_SIZE = 5;
    // 0-百度，1-高德
    private static final int MAP_TYPE = 0;
    // 0-自编号 1-IMEI号
    private static final int NUM_TYPE = 1;
    private static final String KEY = "DA1A8CD9558799122632A8BA73F02BE7";
    private static final String HTTP = "http://";
    private static final String TEST_API = "/api/CanDevice/getOneDeviceHistoryData";

    /**
     * 0:前一天时间：2020-07-15
     * 1:es indexName：iot_datang_fence_202005
     * 2:url:221.130.28.39:8081      后期可能要修改为：cmt.idtet.com:8081
     * @param args
     */
    public static void main(String[] args) {

        LOGGER.error("DaTangConsumer is starting......");

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        TransportClient client = null;

        String startTime = args[0] + " 00:00:00";
        String endTime = args[0] + " 23:59:59";

        try {

            Class.forName("com.facebook.presto.jdbc.PrestoDriver");
            connection = DriverManager.getConnection("jdbc:presto://192.168.2.131:8086/hive/ods", "dw", "");

            statement = connection.createStatement();

            String sql = "select gps_code from hive.ods.iot_iot_gps_self_check_source where gps_model in('CM-T4-CAN', 'GV-T3D-2')";

            resultSet = statement.executeQuery(sql);

            List<String> gpsCodeList = new ArrayList<>();

            while (resultSet.next()) {
                gpsCodeList.add(resultSet.getString("gps_code"));
            }

            if (null != resultSet) {
                resultSet.close();
            }
            if (null != connection) {
                connection.close();
            }

            client = ElasticSearchUtils.open();

            if (CollectionUtils.isNotEmpty(gpsCodeList)) {
                threadDeal(gpsCodeList, startTime, endTime, client, args[1], HTTP + args[2] + TEST_API);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ElasticSearchUtils.close(client);
        }

    }

    /**
     * 多线程处理list
     * @param gpsCodeList
     * @param startTime
     * @param endTime
     * @param client
     * @param indexName
     * @param url
     */
    private static void threadDeal (List<String> gpsCodeList, String startTime, String endTime, TransportClient client, String indexName, String url) {
        List<List<String>> lst = com.znlh.utils.CollectionUtils.groupList(gpsCodeList, gpsCodeList.size() / THREAD_SIZE);
        ExecutorService executorService = Executors.newFixedThreadPool(lst.size());
        List<Future<String>> futures = new ArrayList<>(lst.size());

        for (List<String> l : lst) {
            Callable<String> task = new Callable<String>() {
                public String call() throws Exception {
                    for (String gpsCode : l) {
                        getOneDeviceHistoryData(gpsCode, startTime, endTime, client, indexName, url);
                    }
                    return null;
                }
            };
            futures.add(executorService.submit(task));
//                Thread.sleep(5 * 1000);
        }
        for (Future<String> future : futures) {
            try {
                future.get();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        executorService.shutdown();
    }

    /**
     * 大唐接口3.21 单个
     * @param gpsCode
     * @param startTime
     * @param endTime
     * @param client
     * @param indexName
     * @param url
     */
    private static void getOneDeviceHistoryData(String gpsCode, String startTime, String endTime, TransportClient client, String indexName, String url) {
        try {
            List<Map> params = new ArrayList<>();

            Map<String, Object> map = new HashMap<>();
            map.put("mapType", MAP_TYPE);
            map.put("numType", NUM_TYPE);
            map.put("name", gpsCode);
            map.put("startTime", startTime);
            map.put("endTime", endTime);

            startTime = startTime.substring(0, 4)
                    + startTime.substring(5, 7)
                    + startTime.substring(8, 10)
                    + startTime.substring(11, 13)
                    + startTime.substring(14, 16)
                    + startTime.substring(17);

            endTime = endTime.substring(0, 4)
                    + endTime.substring(5, 7)
                    + endTime.substring(8, 10)
                    + endTime.substring(11, 13)
                    + endTime.substring(14, 16)
                    + endTime.substring(17);


            map.put("checkStr", MD5Utils.md5Digest(startTime + endTime + MAP_TYPE + KEY));

            String body = JSONObject.toJSONString(map);

            String httpResult = HttpClientUtil.doPost(url, null, null, body);
            if (StringUtils.isNotEmpty(httpResult)) {
                JSONObject json = JSONObject.parseObject(httpResult);
                String deviceName = json.getString("deviceName");
                List<Map> list = json.getObject("oneDeviceHistoryDataList", List.class);
                if (!CollectionUtils.isEmpty(list)) {
                    for (Map m : list) {
                        Map<String, String> param = new HashMap<>();
                        param.put("deviceName", deviceName);
                        param.put("lastLocationTime", MapUtils.getString(m, "lastLocationTime"));
                        param.put("latitude", MapUtils.getString(m, "latitude"));
                        param.put("longitude", MapUtils.getString(m, "longitude"));
                        params.add(param);
                    }
                    ElasticSearchUtils.batchInsert(params, client, indexName);
                }
            }

        } catch (Exception e) {
            LOGGER.error("======" + gpsCode + "======" + startTime + "======" + e.toString());
        }
    }

}
