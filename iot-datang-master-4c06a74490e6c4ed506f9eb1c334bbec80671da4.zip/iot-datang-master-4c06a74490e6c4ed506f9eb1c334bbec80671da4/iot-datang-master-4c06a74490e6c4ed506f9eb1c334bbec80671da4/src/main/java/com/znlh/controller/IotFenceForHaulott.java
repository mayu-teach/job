package com.znlh.controller;

import com.alibaba.fastjson.JSONObject;
import com.znlh.constant.Constants;
import com.znlh.utils.PropertiesUtil;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch7.ElasticsearchSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.internals.KafkaTopicPartition;
import org.apache.http.HttpHost;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.*;

/**
 * Haulott-电子围栏信息
 */
public class IotFenceForHaulott implements Serializable {

    private static final long serialVersionUID = -2265916902510652178L;
    private static final Logger LOGGER = LoggerFactory.getLogger(IotFenceForHaulott.class);
    private static final String [] fenceArr = {"DeviceID", "Lo", "La", "PstnTime"};

    public static void main(String[] args) {

        LOGGER.error("IotFenceForHaulott is starting......");

        List<String> fenceList = Arrays.asList(fenceArr);

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//        env.enableCheckpointing(1000 * 5);
//        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
//        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(1000);
//        env.getCheckpointConfig().setCheckpointTimeout(60000);
//        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
//
//        env.setStateBackend(new MemoryStateBackend());
//        env.setStateBackend(new FsStateBackend("hdfs:///flink/checkpoints"));

        env.enableCheckpointing(1 * 60 * 1000);
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);

        Properties prop = new Properties();
        prop.put("bootstrap.servers", PropertiesUtil.getPropertyValue(Constants.BOOTSTRAP_SERVERS_HAULOTT_PRD));
        prop.put("group.id", PropertiesUtil.getPropertyValue(Constants.KAFKA_GROUP_ID_HAULOTT));
        prop.put("auto.offset.reset", PropertiesUtil.getPropertyValue(Constants.AUTO_OFFSET_RESET));

        FlinkKafkaConsumer011<String> kafkaConsumer011 =
                new FlinkKafkaConsumer011<>(PropertiesUtil.getPropertyValue(Constants.KAFKA_TOPICS_HAULOTT),
                        new SimpleStringSchema(), prop);

        kafkaConsumer011.setStartFromGroupOffsets();
//        Map<KafkaTopicPartition, Long> offsets = new HashMap<>();
//        offsets.put(new KafkaTopicPartition(PropertiesUtil.getPropertyValue(Constants.KAFKA_TOPICS_HAULOTT), 0), 650465500L);
//
//        kafkaConsumer011.setStartFromSpecificOffsets(offsets);
        // 5-将自定义Kafka Source加入到数据源
        DataStream<String> text = env.addSource(kafkaConsumer011);
        // 6-打印到控制台
//        text.print().setParallelism(1);

        List<HttpHost> esHttpHost = new ArrayList<>();
        esHttpHost.add(new HttpHost(PropertiesUtil.getPropertyValue(Constants.ES_HOSTNAME_132),
                Integer.valueOf(PropertiesUtil.getPropertyValue(Constants.ES_PORT)),
                PropertiesUtil.getPropertyValue(Constants.ES_SCHEMA)));
        esHttpHost.add(new HttpHost(PropertiesUtil.getPropertyValue(Constants.ES_HOSTNAME_133),
                Integer.valueOf(PropertiesUtil.getPropertyValue(Constants.ES_PORT)),
                PropertiesUtil.getPropertyValue(Constants.ES_SCHEMA)));
        esHttpHost.add(new HttpHost(PropertiesUtil.getPropertyValue(Constants.ES_HOSTNAME_134),
                Integer.valueOf(PropertiesUtil.getPropertyValue(Constants.ES_PORT)),
                PropertiesUtil.getPropertyValue(Constants.ES_SCHEMA)));

        DataStream<List<Map>> message = text.filter(new FilterFunction<String>() {
            @Override
            public boolean filter(String s) throws Exception {

                return s.contains("TC_0001_00_5@string");
            }
        }).map(new MapFunction<String, List<Map>>() {
            @Override
            public List<Map> map(String s) throws Exception {
                List<Map> lst = new ArrayList<>();

                String deviceId = JSONObject.parseObject(s).getString("DeviceID");
                List<Map> value = (List<Map>) JSONObject.parseObject(s).getJSONObject("Parameter").get("TC_0001_00_5@string");
                for (Map v : value) {
                    Map<String, Object> map = (Map<String, Object>) v.get("Value");
                    map.put("DeviceID", deviceId);

                    lst.add(map);
                }

                return lst;
            }
        });

        ElasticsearchSink.Builder<List<Map>> esSinkBuilder = new ElasticsearchSink.Builder<>(esHttpHost,
                new ElasticsearchSinkFunction<List<Map>>(){

                    public IndexRequest createIndexRequest(Map element) {

                        Map<String, String> json = new HashMap<>();

                        Set<Map.Entry> set = element.entrySet();
                        for (Map.Entry e : set) {
                            try {
                                if (fenceList.contains(e.getKey()) && null != e.getValue()) {
                                    json.put(e.getKey().toString(), e.getValue().toString());
                                }
                            } catch (Exception e1) {
                                LOGGER.error("IotFenceForLinGong is error......");
                                continue;
                            }
                        }

                        return Requests.indexRequest()
                                .index(PropertiesUtil.getPropertyValue(Constants.ES_INDEX_HAULOTT))
                                .type("_doc")
                                .source(json);
                    }

                    @Override
                    public void process(List<Map> maps, RuntimeContext runtimeContext, RequestIndexer requestIndexer) {
                        for (Map e : maps) {
                            requestIndexer.add(createIndexRequest(e));
                        }
                    }

        });

        esSinkBuilder.setBulkFlushBackoff(true);
        esSinkBuilder.setBulkFlushBackoffRetries(2);
        esSinkBuilder.setBulkFlushBackoffDelay(1000);
        esSinkBuilder.setBulkFlushMaxSizeMb(10);
        esSinkBuilder.setBulkFlushMaxActions(2000);

        message.addSink(esSinkBuilder.build()).setParallelism(2);

        // 7-执行
        try {
            env.execute(IotFenceForHaulott.class.getName());
        } catch (Exception e) {
            LOGGER.error("IotFenceForHaulott submit error......");
            e.printStackTrace();
        }

    }

}
